﻿# thinkphp_multi_sql_leak_6

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /index.php?s=/home/order/complete/id/1%27 HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：^(?=.*?(?:SQL|syntax)).*?$

> 上传文件定位：

> 验证文件来源：thinkphp_multi_sql_leak_6.poc
