﻿# 用友 OA nc 反序列化DeleteServlet

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：用友 OA nc 反序列化漏洞getshell

> 漏洞特征：

> 验证脚本：HTTP

```
GET /servlet/~ufofr/DeleteServlet HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：^(?=.*?java)(?=.*?lang)(?=.*?ObjectInputStream).*?$

> 上传文件定位：

> 验证文件来源：用友 OA nc 反序列化DeleteServlet.poc
