﻿# 红帆 ioffice 医院版 sql注入

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：红帆 ioffice 医院版 sql注入

> 漏洞特征：

> 验证脚本：HTTP

```
GET /iOffice/prg/set/wss/wssRtSyn.asmx?op=SubmitShowMsg HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：^(?=.*?SubmitShowMsg)(?=.*?ServerHost)(?=.*?SubmitShowMsgResponse).*?$

> 上传文件定位：

> 验证文件来源：红帆 OA 医院版 sql注入.poc
