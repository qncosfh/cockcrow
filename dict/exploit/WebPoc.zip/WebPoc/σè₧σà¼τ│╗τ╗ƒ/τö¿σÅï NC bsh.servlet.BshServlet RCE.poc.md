﻿# 用友 NC bsh.servlet.BshServlet RCE

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：用友 NC bsh.servlet.BshServlet 存在远程命令执行漏洞，通过BeanShell 执行远程命令获取服务器权限。

> 漏洞特征：

> 验证脚本：HTTP

```
GET /servlet/~ic/bsh.servlet.BshServlet HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：BeanShell

> 上传文件定位：

> 验证文件来源：用友 NC bsh.servlet.BshServlet RCE.poc
