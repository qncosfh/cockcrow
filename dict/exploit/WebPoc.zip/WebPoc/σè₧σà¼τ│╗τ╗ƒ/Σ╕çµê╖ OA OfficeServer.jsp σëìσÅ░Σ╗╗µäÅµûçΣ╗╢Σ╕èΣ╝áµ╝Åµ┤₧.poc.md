﻿# 万户 OA OfficeServer.jsp 前台任意文件上传漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：万户 OA OfficeServer.jsp 前台任意文件上传漏洞

> 漏洞特征：

> 验证脚本：HTTP

```
GET /defaultroot/public/iWebOfficeSign/OfficeServer.jsp HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：^(?=.*?DBSTEP)(?=.*?Post).*?$

> 上传文件定位：

> 验证文件来源：万户 OA OfficeServer.jsp 前台任意文件上传漏洞.poc
