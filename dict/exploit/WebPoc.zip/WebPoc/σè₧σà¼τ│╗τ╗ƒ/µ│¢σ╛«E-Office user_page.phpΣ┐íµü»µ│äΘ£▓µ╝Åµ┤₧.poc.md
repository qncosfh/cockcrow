﻿# 泛微E-Office user_page.php信息泄露漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /E-mobile/user_page.php HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：泛微E-Office user_page.php信息泄露漏洞.poc
